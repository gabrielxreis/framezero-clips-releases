#!/bin/bash
set -Ee
trap 'RC=$?; if [ "$RC" -ne 0 ]; then echo ""; echo "[ERRO] A instalação encontrou um problema e esta janela vai ficar aberta."; echo "Tire um print desta tela e envie para o suporte."; read -r -p "Pressione ENTER para fechar..." _; fi' EXIT
cd "$(dirname "$0")"

STABLE_DIR="$HOME/Library/Application Support/obs-studio/FrameZero"
ROOT_REAL="$(cd "$(dirname "$0")" && pwd -P)"
if [[ "$ROOT_REAL" == /tmp/* || "$ROOT_REAL" == /private/tmp/* ]]; then
  if [ -f "$STABLE_DIR/INICIAR.command" ]; then
    echo "Redirecionando para a instalação oficial do FrameZero..."
    exec bash "$STABLE_DIR/INICIAR.command"
  fi
fi

ROOT_DIR="$(pwd)"
APP_DIR="$ROOT_DIR/app"
RUNTIME_DIR="$ROOT_DIR/.framezero"
VENV_DIR="$RUNTIME_DIR/venv"
REQ_FILE="$APP_DIR/requirements.txt"
REQ_HASH_FILE="$RUNTIME_DIR/.requirements.sha256"
PIP_UPDATE_STAMP="$RUNTIME_DIR/.pip_update_check"
SMART_UPDATE_TTL_HOURS="${FRAMEZERO_UPDATE_TTL_HOURS:-168}"

# ============================================================
# OBS Studio obrigatório antes de qualquer etapa do FrameZero
# Fonte oficial: https://obsproject.com/download
# ============================================================
detect_obs_app_mac() {
  if [ -d "/Applications/OBS.app" ]; then echo "/Applications/OBS.app"; return 0; fi
  if [ -d "/Applications/OBS Studio.app" ]; then echo "/Applications/OBS Studio.app"; return 0; fi
  return 1
}

obs_version_mac() {
  local APP="$1"
  if [ -n "$APP" ] && [ -f "$APP/Contents/Info.plist" ]; then
    /usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$APP/Contents/Info.plist" 2>/dev/null || true
  fi
}

latest_obs_version_mac() {
  curl -fsSL --connect-timeout 25 --retry 2 'https://obsproject.com/download' 2>/dev/null \
    | tr '\n' ' ' \
    | sed -n 's/.*Version:[[:space:]]*\([0-9][0-9.]*\).*/\1/p' \
    | head -n 1
}

latest_obs_dmg_url_mac() {
  local HTML ARCH_RE URL
  HTML="$(curl -fsSL --connect-timeout 30 --retry 2 'https://obsproject.com/download' 2>/dev/null || true)"
  [ -z "$HTML" ] && return 1
  case "$(uname -m)" in
    arm64|aarch64) ARCH_RE='apple|arm64|silicon' ;;
    *) ARCH_RE='intel|x86_64' ;;
  esac
  URL="$(printf '%s' "$HTML" \
    | tr '\"' '\n' \
    | grep -Eio 'https?://[^ ]+\.dmg[^ <]*' \
    | grep -Ei 'obs|OBS' \
    | grep -Ei 'mac|macos' \
    | grep -Ei "$ARCH_RE" \
    | head -n 1)"
  if [ -z "$URL" ]; then
    URL="$(printf '%s' "$HTML" \
      | tr '\"' '\n' \
      | grep -Eio 'https?://[^ ]+\.dmg[^ <]*' \
      | grep -Ei 'obs|OBS' \
      | grep -Ei 'mac|macos' \
      | head -n 1)"
  fi
  [ -n "$URL" ] && echo "$URL"
}



registrar_obs_path_mac() {
  local OBS_APP="$1"
  [ -z "$OBS_APP" ] && OBS_APP="$(detect_obs_app_mac || true)"
  [ -z "$OBS_APP" ] && return 1
  mkdir -p "$ROOT_DIR/.framezero" "$APP_DIR" 2>/dev/null || true
  echo "$OBS_APP" > "$ROOT_DIR/.framezero/obs_path.txt"
  echo "OBS instalado em: $OBS_APP"
  if command -v python3 >/dev/null 2>&1; then
    python3 - "$APP_DIR/config.json" "$OBS_APP" <<'PYOBS'
import json, pathlib, sys
p=pathlib.Path(sys.argv[1]); obs=sys.argv[2]
try:
    cfg=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
except Exception:
    cfg={}
cfg['obs_app_path']=obs
cfg['obs_bin_path']=obs
cfg['obs_installed']=True
p.parent.mkdir(parents=True, exist_ok=True)
p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding='utf-8')
PYOBS
  fi
}

instalar_ou_atualizar_obs_mac() {
  echo ""
  echo "============================================================"
  echo " VERIFICANDO OBS STUDIO - OBRIGATÓRIO"
  echo "============================================================"
  echo "Fonte oficial: https://obsproject.com/download"

  local OBS_APP CURRENT LATEST NEED_UPDATE JSON DMG URL MOUNT_DIR FOUND_APP
  OBS_APP="$(detect_obs_app_mac || true)"
  CURRENT="$(obs_version_mac "$OBS_APP")"
  LATEST="$(latest_obs_version_mac || true)"

  if [ -n "$OBS_APP" ]; then
    echo "OBS encontrado em: $OBS_APP"
    [ -n "$CURRENT" ] && echo "Versão instalada: $CURRENT"
  else
    echo "OBS não encontrado na pasta Aplicativos. Vou instalar agora."
  fi
  [ -n "$LATEST" ] && echo "Versão mais recente no site oficial: $LATEST"

  NEED_UPDATE=0
  if [ -z "$OBS_APP" ]; then
    NEED_UPDATE=1
  elif [ -n "$LATEST" ] && [ -n "$CURRENT" ] && [ "$CURRENT" != "$LATEST" ]; then
    echo "OBS está diferente da versão mais recente. Vou atualizar antes de continuar."
    NEED_UPDATE=1
  fi

  if [ "$NEED_UPDATE" = "1" ]; then
    JSON="$HOME/Desktop/framezero-obs-latest.json"
    DMG="$HOME/Desktop/FrameZero-OBS-Studio.dmg"
    URL="$(latest_obs_dmg_url_mac)"
    if [ -z "$URL" ]; then
      echo "ERRO: não consegui localizar o instalador oficial do OBS na página de download."
      echo "Fonte usada: https://obsproject.com/download"
      return 1
    fi
    echo "Baixando OBS oficial pelo link encontrado em obsproject.com/download: $URL"
    curl -L --fail --retry 3 --connect-timeout 25 --progress-bar -o "$DMG" "$URL" || { echo "ERRO: falha ao baixar OBS."; return 1; }
    echo "Montando instalador do OBS..."
    MOUNT_DIR="$(hdiutil attach "$DMG" -nobrowse 2>/dev/null | grep -o '/Volumes/.*' | head -n 1 || true)"
    if [ -z "$MOUNT_DIR" ]; then
      echo "ERRO: não consegui montar o DMG do OBS."
      return 1
    fi
    FOUND_APP="$(find "$MOUNT_DIR" -maxdepth 3 -type d \( -name 'OBS.app' -o -name 'OBS Studio.app' \) 2>/dev/null | head -n 1)"
    if [ -z "$FOUND_APP" ]; then
      hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true
      echo "ERRO: DMG do OBS montou, mas não encontrei OBS.app dentro dele."
      return 1
    fi
    echo "Instalando/atualizando OBS em /Applications..."
    rm -rf "/Applications/OBS.app" "/Applications/OBS Studio.app" 2>/dev/null || sudo rm -rf "/Applications/OBS.app" "/Applications/OBS Studio.app" 2>/dev/null || true
    cp -R "$FOUND_APP" "/Applications/" 2>/dev/null || sudo cp -R "$FOUND_APP" "/Applications/" || { hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true; echo "ERRO: falha ao copiar OBS para /Applications."; return 1; }
    hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true
    OBS_APP="$(detect_obs_app_mac || true)"
  fi

  if [ -z "$OBS_APP" ]; then
    echo "ERRO: OBS continua ausente. Não vou iniciar o Core sem OBS instalado."
    return 1
  fi
  registrar_obs_path_mac "$OBS_APP"
  echo "OK: OBS pronto para o FrameZero."
  return 0
}


instalar_ou_atualizar_obs_mac || { echo "ERRO: OBS Studio é obrigatório antes do FrameZero."; read -r -p "Pressione ENTER para sair..." _; exit 1; }

# ============================================================
# GATE PRÉ-INSTALAÇÃO DO FRAMEZERO
# O FrameZero só é copiado/instalado depois que OBS + plugins obrigatórios passarem.
# ============================================================
echo ""
echo "============================================================"
echo " VERIFICAÇÃO ANTES DE INSTALAR O FRAMEZERO"
echo "============================================================"
echo "O FrameZero Clips só será instalado depois de confirmar:"
echo "- OBS Studio instalado/atualizado"
echo "- BlackHole 2ch"
echo "- Aitum Vertical Canvas"
echo "- Aitum Multistream"
echo "- OBS Face Tracker"
echo ""
if [ -x "$ROOT_DIR/FRAMEZERO-INSTALL-OBS-PLUGINS-MAC.command" ]; then
  bash "$ROOT_DIR/FRAMEZERO-INSTALL-OBS-PLUGINS-MAC.command" || { echo "AVISO: algum componente ainda pode precisar de reinicio, continuando instalação."; read -r -p "Pressione ENTER para sair..." _; exit 1; }
else
  echo "ERRO: instalador obrigatório de plugins não encontrado no pacote. O FrameZero ainda NÃO será instalado."
  read -r -p "Pressione ENTER para sair..." _
  exit 1
fi

echo "OK: OBS + plugins obrigatórios confirmados. Agora vou instalar o FrameZero Clips."

# Instala em uma pasta fixa dentro do suporte do OBS.
# Isso evita depender da pasta Downloads e permite o site clips.framezeroai.com.br/obs abrir o launcher sempre no mesmo lugar.
STABLE_INSTALL_DIR="$HOME/Library/Application Support/obs-studio/FrameZero"

limpar_framezero_antigo_mac_pre_copy() {
  echo ""
  echo "Limpando instalações antigas do FrameZero Clips antes de instalar..."
  pkill -f "servidor.py" 2>/dev/null || true
  pkill -f "FrameZero" 2>/dev/null || true
  pkill -f "framezero" 2>/dev/null || true
  for PORTA in 8765 8766 8889; do
    PID=$(lsof -ti tcp:$PORTA 2>/dev/null || true)
    if [ -n "$PID" ]; then
      echo "Encerrando processo antigo na porta $PORTA..."
      kill -9 $PID 2>/dev/null || true
    fi
  done

  # Remove agent/serviços antigos e qualquer sobra do Nations.
  launchctl bootout "gui/$(id -u)" "$HOME/Library/LaunchAgents/br.com.framezero.clips.agent.plist" >/dev/null 2>&1 || true
  rm -f "$HOME/Library/LaunchAgents/br.com.framezero.clips.agent.plist" 2>/dev/null || true
  find "$HOME/Library/LaunchAgents" -iname "*nations*" -delete 2>/dev/null || true

  # Remove apps antigos quebrados da pasta Aplicativos.
  # Isso corrige apps que apontavam para /tmp/framezero-installer-* e davam erro de INICIAR.command ausente.
  for OLD_APP in "/Applications/FrameZero.app" "/Applications/FrameZero Clips.app" "/Applications/FrameZero Launcher.app" "/Applications/Iniciar Instalador FrameZero.app"; do
    if [ -d "$OLD_APP" ]; then
      echo "Removendo app antigo: $OLD_APP"
      rm -rf "$OLD_APP" 2>/dev/null || sudo rm -rf "$OLD_APP" 2>/dev/null || true
    fi
  done

  # Zera completamente a pasta fixa do FrameZero para não carregar arquivo antigo.
  if [ -d "$STABLE_INSTALL_DIR" ]; then
    echo "Apagando instalação antiga: $STABLE_INSTALL_DIR"
    rm -rf "$STABLE_INSTALL_DIR"
  fi

  # Remove sobras conhecidas do Nations dentro do OBS Support, se existirem.
  OBS_SUPPORT="$HOME/Library/Application Support/obs-studio"
  rm -rf "$OBS_SUPPORT/FrameZero Nations" "$OBS_SUPPORT/FrameZeroNations" "$OBS_SUPPORT/Nations" 2>/dev/null || true
  find "$OBS_SUPPORT" -maxdepth 4 \( -iname "*nations*" -o -iname "*Nations*" \) -prune -exec rm -rf {} + 2>/dev/null || true

  # Remove caches antigos sem apagar gravações do usuário.
  find "$HOME/Downloads" -maxdepth 3 \( -iname "*nations*" -o -iname "*framezero*nations*" \) -prune -exec rm -rf {} + 2>/dev/null || true
  echo "Limpeza concluída. Instalando somente FrameZero Clips."
}

if [ "${FRAMEZERO_INSTALLED_RUN:-0}" != "1" ]; then
  ROOT_REAL="$(cd "$ROOT_DIR" && pwd -P)"
  INSTALL_REAL="$STABLE_INSTALL_DIR"
  if [ "$ROOT_REAL" != "$INSTALL_REAL" ]; then
    limpar_framezero_antigo_mac_pre_copy
    echo ""
    echo "Copiando FrameZero Clips limpo para a pasta fixa do OBS:"
    echo "  $STABLE_INSTALL_DIR"
    mkdir -p "$STABLE_INSTALL_DIR"

    if command -v rsync >/dev/null 2>&1; then
      rsync -a \
        --exclude '.DS_Store' \
        --exclude '__pycache__/' \
        --exclude '.pytest_cache/' \
        "$ROOT_DIR/" "$STABLE_INSTALL_DIR/"
    else
      ditto "$ROOT_DIR" "$STABLE_INSTALL_DIR"
    fi

    chmod +x "$STABLE_INSTALL_DIR"/*.command 2>/dev/null || true
    chmod +x "$STABLE_INSTALL_DIR/FrameZero Launcher.app/Contents/MacOS/FrameZeroLauncher" 2>/dev/null || true
    xattr -dr com.apple.quarantine "$STABLE_INSTALL_DIR" 2>/dev/null || true

    export FRAMEZERO_INSTALLED_RUN=1
    exec "$STABLE_INSTALL_DIR/INSTALAR-MAC.command"
  fi
fi

clear
cat <<'MSG'
============================================================
 FRAMEZERO CLIPS 1.1.8 - INSTALADOR MAC v1.0.42
============================================================
@framezeroai                         @gabrielxreis_

Este instalador prepara o Mac e instala a versão atual do FrameZero Clips.
A janela ficará aberta se acontecer algum erro.

MSG

chmod +x *.command 2>/dev/null || true
xattr -dr com.apple.quarantine *.command 2>/dev/null || true

# ============================================================
# OBS Studio obrigatório antes de qualquer etapa do FrameZero
# Fonte oficial: https://obsproject.com/download
# ============================================================
detect_obs_app_mac() {
  if [ -d "/Applications/OBS.app" ]; then echo "/Applications/OBS.app"; return 0; fi
  if [ -d "/Applications/OBS Studio.app" ]; then echo "/Applications/OBS Studio.app"; return 0; fi
  return 1
}

obs_version_mac() {
  local APP="$1"
  if [ -n "$APP" ] && [ -f "$APP/Contents/Info.plist" ]; then
    /usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$APP/Contents/Info.plist" 2>/dev/null || true
  fi
}

latest_obs_version_mac() {
  curl -fsSL --connect-timeout 25 --retry 2 'https://obsproject.com/download' 2>/dev/null \
    | tr '\n' ' ' \
    | sed -n 's/.*Version:[[:space:]]*\([0-9][0-9.]*\).*/\1/p' \
    | head -n 1
}

latest_obs_dmg_url_mac() {
  local HTML ARCH_RE URL
  HTML="$(curl -fsSL --connect-timeout 30 --retry 2 'https://obsproject.com/download' 2>/dev/null || true)"
  [ -z "$HTML" ] && return 1
  case "$(uname -m)" in
    arm64|aarch64) ARCH_RE='apple|arm64|silicon' ;;
    *) ARCH_RE='intel|x86_64' ;;
  esac
  URL="$(printf '%s' "$HTML" \
    | tr '\"' '\n' \
    | grep -Eio 'https?://[^ ]+\.dmg[^ <]*' \
    | grep -Ei 'obs|OBS' \
    | grep -Ei 'mac|macos' \
    | grep -Ei "$ARCH_RE" \
    | head -n 1)"
  if [ -z "$URL" ]; then
    URL="$(printf '%s' "$HTML" \
      | tr '\"' '\n' \
      | grep -Eio 'https?://[^ ]+\.dmg[^ <]*' \
      | grep -Ei 'obs|OBS' \
      | grep -Ei 'mac|macos' \
      | head -n 1)"
  fi
  [ -n "$URL" ] && echo "$URL"
}



registrar_obs_path_mac() {
  local OBS_APP="$1"
  [ -z "$OBS_APP" ] && OBS_APP="$(detect_obs_app_mac || true)"
  [ -z "$OBS_APP" ] && return 1
  mkdir -p "$ROOT_DIR/.framezero" "$APP_DIR" 2>/dev/null || true
  echo "$OBS_APP" > "$ROOT_DIR/.framezero/obs_path.txt"
  echo "OBS instalado em: $OBS_APP"
  if command -v python3 >/dev/null 2>&1; then
    python3 - "$APP_DIR/config.json" "$OBS_APP" <<'PYOBS'
import json, pathlib, sys
p=pathlib.Path(sys.argv[1]); obs=sys.argv[2]
try:
    cfg=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
except Exception:
    cfg={}
cfg['obs_app_path']=obs
cfg['obs_bin_path']=obs
cfg['obs_installed']=True
p.parent.mkdir(parents=True, exist_ok=True)
p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding='utf-8')
PYOBS
  fi
}

instalar_ou_atualizar_obs_mac() {
  echo ""
  echo "============================================================"
  echo " VERIFICANDO OBS STUDIO - OBRIGATÓRIO"
  echo "============================================================"
  echo "Fonte oficial: https://obsproject.com/download"

  local OBS_APP CURRENT LATEST NEED_UPDATE JSON DMG URL MOUNT_DIR FOUND_APP
  OBS_APP="$(detect_obs_app_mac || true)"
  CURRENT="$(obs_version_mac "$OBS_APP")"
  LATEST="$(latest_obs_version_mac || true)"

  if [ -n "$OBS_APP" ]; then
    echo "OBS encontrado em: $OBS_APP"
    [ -n "$CURRENT" ] && echo "Versão instalada: $CURRENT"
  else
    echo "OBS não encontrado na pasta Aplicativos. Vou instalar agora."
  fi
  [ -n "$LATEST" ] && echo "Versão mais recente no site oficial: $LATEST"

  NEED_UPDATE=0
  if [ -z "$OBS_APP" ]; then
    NEED_UPDATE=1
  elif [ -n "$LATEST" ] && [ -n "$CURRENT" ] && [ "$CURRENT" != "$LATEST" ]; then
    echo "OBS está diferente da versão mais recente. Vou atualizar antes de continuar."
    NEED_UPDATE=1
  fi

  if [ "$NEED_UPDATE" = "1" ]; then
    JSON="$HOME/Desktop/framezero-obs-latest.json"
    DMG="$HOME/Desktop/FrameZero-OBS-Studio.dmg"
    URL="$(latest_obs_dmg_url_mac)"
    if [ -z "$URL" ]; then
      echo "ERRO: não consegui localizar o instalador oficial do OBS na página de download."
      echo "Fonte usada: https://obsproject.com/download"
      return 1
    fi
    echo "Baixando OBS oficial pelo link encontrado em obsproject.com/download: $URL"
    curl -L --fail --retry 3 --connect-timeout 25 --progress-bar -o "$DMG" "$URL" || { echo "ERRO: falha ao baixar OBS."; return 1; }
    echo "Montando instalador do OBS..."
    MOUNT_DIR="$(hdiutil attach "$DMG" -nobrowse 2>/dev/null | grep -o '/Volumes/.*' | head -n 1 || true)"
    if [ -z "$MOUNT_DIR" ]; then
      echo "ERRO: não consegui montar o DMG do OBS."
      return 1
    fi
    FOUND_APP="$(find "$MOUNT_DIR" -maxdepth 3 -type d \( -name 'OBS.app' -o -name 'OBS Studio.app' \) 2>/dev/null | head -n 1)"
    if [ -z "$FOUND_APP" ]; then
      hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true
      echo "ERRO: DMG do OBS montou, mas não encontrei OBS.app dentro dele."
      return 1
    fi
    echo "Instalando/atualizando OBS em /Applications..."
    rm -rf "/Applications/OBS.app" "/Applications/OBS Studio.app" 2>/dev/null || sudo rm -rf "/Applications/OBS.app" "/Applications/OBS Studio.app" 2>/dev/null || true
    cp -R "$FOUND_APP" "/Applications/" 2>/dev/null || sudo cp -R "$FOUND_APP" "/Applications/" || { hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true; echo "ERRO: falha ao copiar OBS para /Applications."; return 1; }
    hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true
    OBS_APP="$(detect_obs_app_mac || true)"
  fi

  if [ -z "$OBS_APP" ]; then
    echo "ERRO: OBS continua ausente. Não vou iniciar o Core sem OBS instalado."
    return 1
  fi
  registrar_obs_path_mac "$OBS_APP"
  echo "OK: OBS pronto para o FrameZero."
  return 0
}

precheck_basico_mac() {
  echo ""
  echo "Verificando programas necessários para instalar..."
  ERROS=0
  for CMD in curl unzip xattr shasum; do
    if command -v "$CMD" >/dev/null 2>&1; then
      echo "OK: $CMD encontrado."
    else
      echo "ERRO: $CMD não encontrado no Mac."
      ERROS=$((ERROS+1))
    fi
  done

  if [ "$(uname -m)" = "arm64" ]; then
    echo "OK: Mac Apple Silicon detectado."
  else
    echo "ERRO: esta versão exige Mac Apple Silicon M1/M2/M3/M4."
    ERROS=$((ERROS+1))
  fi

  if instalar_ou_atualizar_obs_mac; then
    echo "OK: OBS instalado/atualizado e caminho registrado."
  else
    echo "ERRO: OBS Studio é obrigatório e não pôde ser instalado/atualizado."
    ERROS=$((ERROS+1))
  fi

  if [ "$ERROS" -gt 0 ]; then
    echo ""
    echo "Não dá para continuar antes de corrigir os itens com ERRO acima."
    read -r -p "Pressione ENTER para sair..." _
    exit 1
  fi
  echo "Pré-verificação concluída."
}

precheck_basico_mac

if [ "$(uname -m)" != "arm64" ]; then
  echo "ERRO: esta versão exige Mac Apple Silicon (M1/M2/M3/M4)."
  echo "Este Mac parece ser: $(uname -m)"
  read -p "Pressione ENTER para sair..."
  exit 1
fi


safe_rm() {
  ALVO="$1"
  if [ -n "$ALVO" ] && [ -e "$ALVO" ]; then
    echo "Removendo antigo: $ALVO"
    rm -rf "$ALVO"
  fi
}

limpar_instalacoes_antigas() {
  echo ""
  echo "Limpando instalação antiga do FrameZero antes de instalar a nova..."

  pkill -f "servidor.py" 2>/dev/null || true
  pkill -f "FrameZero" 2>/dev/null || true
  pkill -f "framezero" 2>/dev/null || true
  for PORTA in 8765 8766 8889; do
    PID=$(lsof -ti tcp:$PORTA 2>/dev/null || true)
    if [ -n "$PID" ]; then
      echo "Encerrando processo antigo na porta $PORTA..."
      kill -9 $PID 2>/dev/null || true
    fi
  done

  # Sempre recria o ambiente Python da versão atual para evitar mistura de pacotes antigos.
  safe_rm "$RUNTIME_DIR"

  # Limpa caches Python da versão atual.
  find "$ROOT_DIR" -type d \( -name "__pycache__" -o -name ".pytest_cache" \) -prune -exec rm -rf {} + 2>/dev/null || true

  # Limpa somente runtimes/venvs de builds antigas em Downloads, sem apagar gravações, arquivos ou projetos.
  for D in "$HOME/Downloads"/framezero_full_integrado_* "$HOME/Downloads"/FrameZero* "$HOME/Downloads"/framezero_*; do
    if [ -d "$D" ] && [ "$D" != "$ROOT_DIR" ]; then
      safe_rm "$D/.framezero"
      find "$D" -maxdepth 4 -type d \( -name "__pycache__" -o -name ".pytest_cache" \) -prune -exec rm -rf {} + 2>/dev/null || true
    fi
  done

  echo "Limpeza concluída. Instalando versão nova limpa."
}

escolher_tipo_instalacao() {
  echo ""
  echo "Preparando instalação do FrameZero Clips..."
  echo ""
  if [ "${FRAMEZERO_AUTO_INSTALL:-}" = "1" ] || [ "${FRAMEZERO_AUTO_INSTALL:-}" = "update" ]; then
    OPCAO_INST="1"
    echo "Instalação iniciada."
  elif [ "${FRAMEZERO_AUTO_INSTALL:-}" = "clean" ]; then
    OPCAO_INST="2"
    echo "Instalação iniciada."
  else
    OPCAO_INST="2"
    echo "Instalação iniciada."
  fi

  pkill -f "servidor.py" 2>/dev/null || true
  pkill -f "FrameZero" 2>/dev/null || true
  pkill -f "framezero" 2>/dev/null || true
  for PORTA in 8765 8766 8889; do
    PID=$(lsof -ti tcp:$PORTA 2>/dev/null || true)
    if [ -n "$PID" ]; then
      echo "Encerrando processo antigo na porta $PORTA..."
      kill -9 $PID 2>/dev/null || true
    fi
  done

  if [ "$OPCAO_INST" = "2" ]; then
    echo ""
    echo "Instalando versão atual..."
    limpar_instalacoes_antigas
  else
    echo ""
    echo "Atualizando instalação existente..."
    find "$ROOT_DIR" -type d \( -name "__pycache__" -o -name ".pytest_cache" \) -prune -exec rm -rf {} + 2>/dev/null || true
  fi
}

escolher_tipo_instalacao

python_ok() {
  "$1" - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if (3,10) <= sys.version_info[:2] <= (3,13) else 1)
PY
}

python_version() {
  "$1" - <<'PY' 2>/dev/null || true
import sys
print(f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
PY
}

requirements_hash() {
  python - "$REQ_FILE" <<'PY' 2>/dev/null || true
import hashlib, pathlib, sys
p = pathlib.Path(sys.argv[1])
print(hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else "")
PY
}

dependencias_prontas() {
  python - <<'PY' >/dev/null 2>&1
import importlib.util, sys
mods = [
  "mlx_whisper",
  "numpy",
  "sounddevice",
  "websockets",
  "obsws_python",
  "requests",
  "openai",
  "scipy",
]
missing = [m for m in mods if importlib.util.find_spec(m) is None]
sys.exit(0 if not missing else 1)
PY
}

precisa_checar_update_pip() {
  if [ "${FRAMEZERO_FORCE_UPDATE:-}" = "1" ]; then
    return 0
  fi
  if [ ! -f "$PIP_UPDATE_STAMP" ]; then
    return 0
  fi
  AGORA="$(date +%s)"
  ULTIMO="$(cat "$PIP_UPDATE_STAMP" 2>/dev/null || echo 0)"
  TTL=$((SMART_UPDATE_TTL_HOURS * 3600))
  if [ $((AGORA - ULTIMO)) -ge "$TTL" ]; then
    return 0
  fi
  return 1
}

remover_motores_antigos_somente_se_existirem() {
  if python - <<'PY' >/tmp/framezero_legacy_pip.txt 2>/dev/null
import sys
from importlib import metadata
instalados = {dist.metadata.get('Name','').lower().replace('_','-') for dist in metadata.distributions()}
legados = ["funasr", "modelscope", "torchaudio", "transformers", "sentencepiece", "librosa", "soundfile", "faster-whisper", "ctranslate2", "tokenizers"]
achados = [p for p in legados if p in instalados]
if achados:
    print(" ".join(achados))
    sys.exit(2)
sys.exit(0)
PY
  then
    echo "Motores antigos: nenhum encontrado."
  else
    LEGADOS="$(cat /tmp/framezero_legacy_pip.txt 2>/dev/null || true)"
    echo "Removendo motores antigos encontrados: ${LEGADOS:-pacotes legados}"
    python -m pip uninstall -y funasr modelscope torchaudio transformers sentencepiece librosa soundfile faster-whisper ctranslate2 tokenizers 2>/dev/null || true
  fi
  rm -f /tmp/framezero_legacy_pip.txt 2>/dev/null || true
}

instalar_dependencias_inteligente() {
  echo ""
  echo "Verificando dependências do FrameZero..."

  HASH_ATUAL="$(requirements_hash)"
  HASH_ANTIGO="$(cat "$REQ_HASH_FILE" 2>/dev/null || true)"

  if dependencias_prontas && [ -n "$HASH_ATUAL" ] && [ "$HASH_ATUAL" = "$HASH_ANTIGO" ]; then
    if precisa_checar_update_pip; then
      echo "Dependências já instaladas. Checando se há versões novas..."
      python -m pip install --upgrade pip wheel
      python -m pip install "setuptools<82"
      python -m pip install --upgrade --upgrade-strategy only-if-needed -r "$REQ_FILE"
      date +%s > "$PIP_UPDATE_STAMP"
      echo "$HASH_ATUAL" > "$REQ_HASH_FILE"
    else
      echo "Dependências já instaladas e conferidas recentemente. Pulando instalação para economizar tempo."
    fi
  else
    echo "Ambiente novo, incompleto ou requirements alterado. Instalando/atualizando somente o necessário..."
    python -m pip install --upgrade pip wheel
    python -m pip install "setuptools<82"
    python -m pip install --upgrade --upgrade-strategy only-if-needed -r "$REQ_FILE"
    date +%s > "$PIP_UPDATE_STAMP"
    echo "$HASH_ATUAL" > "$REQ_HASH_FILE"
  fi

  remover_motores_antigos_somente_se_existirem
}

pick_python() {
  for P in \
    /Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12 \
    /opt/homebrew/bin/python3.12 \
    /opt/homebrew/bin/python3.11 \
    /opt/homebrew/bin/python3.10 \
    /usr/local/bin/python3.12 \
    /usr/local/bin/python3.11 \
    /usr/local/bin/python3.10 \
    python3.12 \
    python3.11 \
    python3.10 \
    python3
  do
    if [ -x "$P" ]; then
      if python_ok "$P"; then echo "$P"; return 0; fi
    elif command -v "$P" >/dev/null 2>&1; then
      BIN="$(command -v "$P")"
      if python_ok "$BIN"; then echo "$BIN"; return 0; fi
    fi
  done
  return 1
}

instalar_python312() {
  echo ""
  echo "Componente necessário não encontrado. Vou instalar automaticamente."
  echo "O Mac pode pedir a senha para autorizar a instalação."
  echo ""

  if command -v brew >/dev/null 2>&1; then
    echo "Homebrew detectado. Tentando: brew install python@3.12"
    brew install python@3.12 || true
    if [ -x "/opt/homebrew/bin/python3.12" ]; then return 0; fi
  fi

  TMP_PKG="/tmp/framezero-python312.pkg"
  URLS=(
    "https://www.python.org/ftp/python/3.12.11/python-3.12.11-macos11.pkg"
    "https://www.python.org/ftp/python/3.12.10/python-3.12.10-macos11.pkg"
    "https://www.python.org/ftp/python/3.12.9/python-3.12.9-macos11.pkg"
    "https://www.python.org/ftp/python/3.12.8/python-3.12.8-macos11.pkg"
    "https://www.python.org/ftp/python/3.12.7/python-3.12.7-macos11.pkg"
  )

  BAIXOU=""
  for URL in "${URLS[@]}"; do
    echo "Baixando Python 3.12..."
    if curl -L --fail --connect-timeout 20 --retry 2 -o "$TMP_PKG" "$URL"; then
      BAIXOU="1"
      break
    fi
  done

  if [ -z "$BAIXOU" ]; then
    echo ""
    echo "ERRO: não consegui baixar Python 3.12 automaticamente."
    echo "Instale manualmente pelo site: https://www.python.org/downloads/macos/"
    echo "Depois rode este INSTALAR-MAC.command de novo."
    return 1
  fi

  echo "Instalando Python 3.12 oficial..."
  sudo installer -pkg "$TMP_PKG" -target /
  rm -f "$TMP_PKG" 2>/dev/null || true
}

PYTHON_BIN="$(pick_python || true)"

if [ -z "$PYTHON_BIN" ]; then
  instalar_python312
  PYTHON_BIN="$(pick_python || true)"
fi

if [ -z "$PYTHON_BIN" ]; then
  echo ""
  echo "ERRO: o componente necessário foi instalado, mas ainda não apareceu no sistema."
  echo "Feche este Terminal, abra de novo e rode o instalador novamente."
  read -p "Pressione ENTER para sair..."
  exit 1
fi

echo "Python compatível: $PYTHON_BIN ($(python_version "$PYTHON_BIN"))"

mkdir -p "$RUNTIME_DIR"

# Se o venv antigo foi criado com Python 3.14, apaga e recria.
RECRIAR="0"
if [ -x "$VENV_DIR/bin/python" ]; then
  VENV_VER="$($VENV_DIR/bin/python - <<'PY' 2>/dev/null || true
import sys
print(f"{sys.version_info.major}.{sys.version_info.minor}")
PY
)"
  case "$VENV_VER" in
    3.10|3.11|3.12|3.13) RECRIAR="0" ;;
    *) RECRIAR="1" ;;
  esac
else
  RECRIAR="1"
fi

if [ "$RECRIAR" = "1" ]; then
  echo "Criando venv limpo em: $VENV_DIR"
  rm -rf "$VENV_DIR"
  "$PYTHON_BIN" -m venv "$VENV_DIR"
fi

source "$VENV_DIR/bin/activate"
instalar_dependencias_inteligente

echo "Testando motor de transcrição local..."
python - <<'PY'
import importlib.util, platform, sys
mods = ["mlx_whisper", "numpy", "sounddevice", "websockets"]
missing = [m for m in mods if importlib.util.find_spec(m) is None]
if platform.machine() != "arm64":
    print("ERRO: não é Apple Silicon/arm64")
    sys.exit(1)
if missing:
    print("ERRO: faltando módulos:", ", ".join(missing))
    sys.exit(1)
print("Motor local OK")
PY




baixar_asset_github_mac() {
  REPO="$1"
  REGEX="$2"
  DEST="$3"
  rm -f "$DEST" 2>/dev/null || true

  URL=$(python - "$REPO" "$REGEX" <<'PYASSET'
import json, re, sys, urllib.request
repo, pattern = sys.argv[1], sys.argv[2]
rx = re.compile(pattern, re.I)
headers={"Accept":"application/vnd.github+json", "User-Agent":"FrameZeroInstaller"}
urls=[
    f"https://api.github.com/repos/{repo}/releases/latest",
    f"https://api.github.com/repos/{repo}/releases?per_page=20",
]
for api in urls:
    try:
        req=urllib.request.Request(api, headers=headers)
        data=json.loads(urllib.request.urlopen(req, timeout=35).read().decode('utf-8','ignore'))
        releases=data if isinstance(data, list) else [data]
        for rel in releases:
            for a in rel.get('assets', []) or []:
                name=a.get('name','')
                url=a.get('browser_download_url','')
                if url and rx.search(name):
                    print(url)
                    raise SystemExit(0)
    except Exception:
        pass
raise SystemExit(1)
PYASSET
)
  if [ -n "$URL" ]; then
    echo "Baixando componente OBS: $(basename "$DEST")"
    curl -L --fail --retry 3 --connect-timeout 20 --progress-bar -o "$DEST" "$URL"
    return $?
  fi
  return 1
}

instalar_pkg_ou_dmg_mac() {
  local arquivo="$1"
  local nome="$2"
  if [ ! -f "$arquivo" ]; then return 1; fi
  case "$arquivo" in
    *.pkg)
      echo "Instalando $nome. O Mac pode pedir senha."
      sudo installer -pkg "$arquivo" -target /
      return $?
      ;;
    *.dmg)
      echo "Montando $nome..."
      local mount_dir="/tmp/framezero_dmg_$RANDOM"
      mkdir -p "$mount_dir"
      hdiutil attach "$arquivo" -mountpoint "$mount_dir" -nobrowse -quiet || return 1
      local pkg
      pkg=$(find "$mount_dir" -type f -iname "*.pkg" 2>/dev/null | head -n 1)
      if [ -n "$pkg" ]; then
        echo "Instalando $nome pelo pacote encontrado no DMG."
        sudo installer -pkg "$pkg" -target /
        local rc=$?
        hdiutil detach "$mount_dir" -quiet || true
        return $rc
      fi
      local obs_plugins="$HOME/Library/Application Support/obs-studio/plugins"
      mkdir -p "$obs_plugins"
      find "$mount_dir" -maxdepth 4 \( -iname "*.plugin" -o -iname "*.so" -o -iname "*.dylib" \) -print0 2>/dev/null | while IFS= read -r -d '' f; do cp -R "$f" "$obs_plugins/" 2>/dev/null || true; done
      hdiutil detach "$mount_dir" -quiet || true
      return 0
      ;;
  esac
  return 1
}



instalar_ffmpeg_obrigatorio_mac() {
  echo ""
  echo "============================================================"
  echo " INSTALANDO FFMPEG - COMPONENTE OBRIGATÓRIO DE CORTES"
  echo "============================================================"
  mkdir -p "$ROOT_DIR/bin" "$APP_DIR/ffmpeg/bin"

  if [ -x "$ROOT_DIR/bin/ffmpeg" ]; then
    export PATH="$ROOT_DIR/bin:$APP_DIR/ffmpeg/bin:$PATH"
    echo "OK: FFmpeg local encontrado: $ROOT_DIR/bin/ffmpeg"
    return 0
  fi
  if command -v ffmpeg >/dev/null 2>&1; then
    echo "OK: FFmpeg encontrado no sistema: $(command -v ffmpeg)"
    return 0
  fi
  if [ -x "/opt/homebrew/bin/ffmpeg" ] || [ -x "/usr/local/bin/ffmpeg" ]; then
    export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
    echo "OK: FFmpeg encontrado no Homebrew."
    return 0
  fi

  echo "Instalando FFmpeg local do FrameZero via pacote Python."
  echo "Esse método evita depender do servidor evermeet.cx."
  python -m pip install --upgrade imageio-ffmpeg
  python - <<'PYFFMPEG'
import os, shutil, stat, sys
try:
    import imageio_ffmpeg
    src = imageio_ffmpeg.get_ffmpeg_exe()
    root = os.environ.get('ROOT_DIR') or os.getcwd()
    app = os.environ.get('APP_DIR') or os.path.join(root, 'app')
    targets = [os.path.join(root, 'bin', 'ffmpeg'), os.path.join(app, 'ffmpeg', 'bin', 'ffmpeg')]
    for dest in targets:
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.copy2(src, dest)
        os.chmod(dest, os.stat(dest).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    print('FFmpeg local instalado:', targets[0])
except Exception as e:
    print('Falha ao preparar FFmpeg local:', e)
    sys.exit(1)
PYFFMPEG
  if [ -x "$ROOT_DIR/bin/ffmpeg" ]; then
    export PATH="$ROOT_DIR/bin:$APP_DIR/ffmpeg/bin:$PATH"
    echo "FFmpeg instalado com sucesso."
    return 0
  fi

  echo "ERRO: não consegui instalar FFmpeg. Sem FFmpeg os cortes não funcionam."
  return 1
}

configurar_nations_flag_mac() {
  mkdir -p "$APP_DIR"
  local flag="false"
  if [ "${FRAMEZERO_INSTALL_WITH_NATIONS:-0}" = "1" ] || [ "${FRAMEZERO_NATIONS_CORE_ONLY:-0}" = "1" ]; then
    flag="true"
  fi
  python3 - "$APP_DIR/config.json" "$flag" <<'PYNF'
import json, sys, pathlib
path=pathlib.Path(sys.argv[1]); flag=(sys.argv[2].lower()=="true")
try:
    cfg=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
except Exception:
    cfg={}
cfg["site_url"]="https://clips.framezeroai.com.br/obs"
cfg["version"]="1.1.8"
cfg["nations_enabled"]=flag
cfg["nations_active"]=flag
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding='utf-8')
# Espelha também em .framezero/nations/config.json, porque o Core Nations lê esse arquivo.
nations_dir = path.parent.parent / ".framezero" / "nations"
nations_dir.mkdir(parents=True, exist_ok=True)
npath = nations_dir / "config.json"
try:
    ncfg=json.loads(npath.read_text(encoding='utf-8')) if npath.exists() else {}
except Exception:
    ncfg={}
ncfg["enabled"]=flag
ncfg["nations_enabled"]=flag
ncfg["active"]=flag
npath.write_text(json.dumps(ncfg, ensure_ascii=False, indent=2), encoding='utf-8')
print("Nations:", "ativado" if flag else "desativado")
PYNF
}

configurar_nations_flag_mac

instalar_ffmpeg_obrigatorio_mac


instalar_plugins_obs_mac() {
  echo ""
  echo "============================================================"
  echo " INSTALANDO/VERIFICANDO PLUGINS DO OBS"
  echo "============================================================"
  echo "Plugins obrigatórios: BlackHole 2ch, Aitum Vertical, Aitum Multistream e Face Tracker."
  echo "Se algum plugin OBS não existir, o instalador tenta buscar no nosso GitHub e nas releases públicas."

  TMP_PLUG="$HOME/Desktop/FrameZero-OBS-Plugins"
  mkdir -p "$TMP_PLUG"

  OBS_PLUGIN_DIR_USER="$HOME/Library/Application Support/obs-studio/plugins"
  OBS_PLUGIN_DIR_SYS="/Library/Application Support/obs-studio/plugins"
  mkdir -p "$OBS_PLUGIN_DIR_USER" 2>/dev/null || true

  has_blackhole(){
    [ -d "/Library/Audio/Plug-Ins/HAL/BlackHole2ch.driver" ] && return 0
    [ -d "/Library/Audio/Plug-Ins/HAL/BlackHole.driver" ] && return 0
    find "/Library/Audio/Plug-Ins/HAL" -maxdepth 1 -iname "*BlackHole*.driver" 2>/dev/null | grep -qi BlackHole && return 0
    system_profiler SPAudioDataType 2>/dev/null | grep -Eiq "BlackHole[[:space:]]*2ch|BlackHole" && return 0
    return 1
  }

  has_aitum_vertical(){
    find "$OBS_PLUGIN_DIR_USER" "$OBS_PLUGIN_DIR_SYS" "/Applications/OBS.app/Contents/PlugIns" \
      \( -iname "*vertical*" -o -iname "*canvas*" -o -iname "*aitum*vertical*" -o -iname "*vertical-canvas*" \) 2>/dev/null | grep -Eiq "vertical|canvas|aitum"
  }
  has_aitum_multi(){
    find "$OBS_PLUGIN_DIR_USER" "$OBS_PLUGIN_DIR_SYS" "/Applications/OBS.app/Contents/PlugIns" \
      \( -iname "*multistream*" -o -iname "*multi*stream*" -o -iname "*aitum*multi*" -o -iname "*aitum*stream*" \) 2>/dev/null | grep -Eiq "multistream|multi|aitum"
  }
  has_face_tracker(){
    find "$OBS_PLUGIN_DIR_USER" "$OBS_PLUGIN_DIR_SYS" "/Applications/OBS.app/Contents/PlugIns" \
      \( -iname "*face*tracker*" -o -iname "*facetracker*" -o -iname "*face-tracker*" \) 2>/dev/null | grep -Eiq "face.*tracker|facetracker"
  }

  instalar_pkg_ou_dmg_mac_safe(){
    local SRC="$1"; local NAME="$2"
    [ -z "$SRC" ] && return 1
    [ ! -e "$SRC" ] && return 1
    case "$SRC" in
      *.pkg|*.PKG)
        echo "Instalando pacote $NAME: $SRC"
        sudo installer -pkg "$SRC" -target / && return 0
        return 1
        ;;
      *.dmg|*.DMG)
        local MOUNT_DIR
        MOUNT_DIR="$(hdiutil attach "$SRC" -nobrowse -quiet 2>/dev/null | awk '/\/Volumes\//{for(i=3;i<=NF;i++){printf $i (i<NF?" ":"")}; print ""}' | tail -n 1)"
        [ -z "$MOUNT_DIR" ] && return 1
        local PKG
        PKG="$(find "$MOUNT_DIR" -type f -iname "*.pkg" 2>/dev/null | head -n 1)"
        if [ -n "$PKG" ]; then sudo installer -pkg "$PKG" -target /; local RC=$?; hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true; return $RC; fi
        local PLUG
        PLUG="$(find "$MOUNT_DIR" -maxdepth 5 \( -iname "*.plugin" -o -iname "*.so" -o -iname "*.dylib" \) 2>/dev/null | head -n 1)"
        if [ -n "$PLUG" ]; then cp -R "$PLUG" "$OBS_PLUGIN_DIR_USER/" 2>/dev/null || sudo cp -R "$PLUG" "$OBS_PLUGIN_DIR_SYS/"; local RC=$?; hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true; return $RC; fi
        hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true
        return 1
        ;;
    esac
    return 1
  }

  install_obs_plugin_payload_mac(){
    local SRC="$1"; local NAME="$2"
    [ -z "$SRC" ] && return 1
    [ ! -e "$SRC" ] && return 1
    case "$SRC" in
      *.pkg|*.PKG|*.dmg|*.DMG)
        instalar_pkg_ou_dmg_mac_safe "$SRC" "$NAME"
        return $?
        ;;
      *.zip|*.ZIP)
        local UNZIP_DIR LOCAL_PKG OBSPLUG DATA_DIR
        UNZIP_DIR="$TMP_PLUG/unzip_${NAME// /_}"
        rm -rf "$UNZIP_DIR" 2>/dev/null || true
        mkdir -p "$UNZIP_DIR"
        unzip -q "$SRC" -d "$UNZIP_DIR" || return 1
        LOCAL_PKG="$(find "$UNZIP_DIR" -type f \( -iname "*.pkg" -o -iname "*.dmg" \) 2>/dev/null | head -n 1)"
        if [ -n "$LOCAL_PKG" ]; then instalar_pkg_ou_dmg_mac_safe "$LOCAL_PKG" "$NAME" && return 0; fi
        OBSPLUG="$(find "$UNZIP_DIR" -type d -path "*/obs-plugins" 2>/dev/null | head -n 1)"
        DATA_DIR="$(find "$UNZIP_DIR" -type d -path "*/data" 2>/dev/null | head -n 1)"
        if [ -n "$OBSPLUG" ]; then
          echo "Copiando obs-plugins de $NAME para $OBS_PLUGIN_DIR_USER"
          cp -R "$OBSPLUG/"* "$OBS_PLUGIN_DIR_USER/" 2>/dev/null || true
        fi
        if [ -n "$DATA_DIR" ]; then
          mkdir -p "$HOME/Library/Application Support/obs-studio/data"
          cp -R "$DATA_DIR/"* "$HOME/Library/Application Support/obs-studio/data/" 2>/dev/null || true
        fi
        if [ -z "$OBSPLUG" ]; then
          local PLUG
          PLUG="$(find "$UNZIP_DIR" -type d \( -iname "*.plugin" -o -iname "*.obs" \) 2>/dev/null | head -n 1)"
          if [ -n "$PLUG" ]; then cp -R "$PLUG" "$OBS_PLUGIN_DIR_USER/" 2>/dev/null || true; fi
        fi
        return 0
        ;;
    esac
    return 1
  }

  baixar_primeiro_arquivo_do_github_dir(){
    local REPO_DIR="$1"; local DEST="$2"
    python3 - "$REPO_DIR" "$DEST" <<'PYGHCONT'
import json, sys, urllib.request, pathlib
repo_dir=sys.argv[1].strip('/'); dest=pathlib.Path(sys.argv[2])
api=f'https://api.github.com/repos/gabrielxreis/framezero-clips-releases/contents/{repo_dir}?ref=main'
headers={'User-Agent':'FrameZeroInstaller','Accept':'application/vnd.github+json'}
try:
    data=json.loads(urllib.request.urlopen(urllib.request.Request(api, headers=headers), timeout=25).read().decode())
    for item in data:
        name=(item.get('name') or '').lower()
        if name.endswith(('.pkg','.dmg','.zip')) and item.get('download_url'):
            print(item['download_url'])
            sys.exit(0)
except Exception:
    pass
sys.exit(1)
PYGHCONT
    local URL
    URL="$(python3 - "$REPO_DIR" <<'PYGHCONT2'
import json, sys, urllib.request
repo_dir=sys.argv[1].strip('/')
api=f'https://api.github.com/repos/gabrielxreis/framezero-clips-releases/contents/{repo_dir}?ref=main'
headers={'User-Agent':'FrameZeroInstaller','Accept':'application/vnd.github+json'}
try:
    data=json.loads(urllib.request.urlopen(urllib.request.Request(api, headers=headers), timeout=25).read().decode())
    for item in data:
        name=(item.get('name') or '').lower()
        if name.endswith(('.pkg','.dmg','.zip')) and item.get('download_url'):
            print(item['download_url']); sys.exit(0)
except Exception:
    pass
sys.exit(1)
PYGHCONT2
)"
    [ -z "$URL" ] && return 1
    echo "Baixando pacote do nosso GitHub: $URL"
    curl -L --fail --retry 3 --connect-timeout 25 --progress-bar -o "$DEST" "$URL"
  }

  baixar_asset_github_multi_mac(){
    local REPOS="$1"; local REGEX="$2"; local DEST="$3"
    local URL
    URL="$(python3 - "$REPOS" "$REGEX" <<'PYGHREL'
import json, re, sys, urllib.request
repos=sys.argv[1].split(','); regex=re.compile(sys.argv[2], re.I)
headers={'User-Agent':'FrameZeroInstaller','Accept':'application/vnd.github+json'}
for repo in repos:
    for api in [f'https://api.github.com/repos/{repo}/releases/latest', f'https://api.github.com/repos/{repo}/releases']:
        try:
            data=json.loads(urllib.request.urlopen(urllib.request.Request(api, headers=headers), timeout=25).read().decode('utf-8','ignore'))
            releases=data if isinstance(data, list) else [data]
            for rel in releases:
                for a in rel.get('assets') or []:
                    name=a.get('name') or ''; url=a.get('browser_download_url') or ''
                    if url and regex.search(name): print(url); sys.exit(0)
        except Exception: pass
sys.exit(1)
PYGHREL
)"
    [ -z "$URL" ] && return 1
    echo "Baixando plugin OBS público: $URL"
    curl -L --fail --retry 3 --connect-timeout 25 --progress-bar -o "$DEST" "$URL"
  }

  ensure_homebrew_mac(){
    export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
    if command -v brew >/dev/null 2>&1; then return 0; fi
    echo "Homebrew não encontrado. Instalando Homebrew oficial..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || true
    [ -x "/opt/homebrew/bin/brew" ] && eval "$(/opt/homebrew/bin/brew shellenv)" 2>/dev/null || true
    [ -x "/usr/local/bin/brew" ] && eval "$(/usr/local/bin/brew shellenv)" 2>/dev/null || true
    command -v brew >/dev/null 2>&1
  }

  instalar_blackhole_obrigatorio(){
    echo "Instalando BlackHole 2ch via Homebrew: brew install --cask blackhole-2ch"
    ensure_homebrew_mac || return 1
    export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
    if ! has_blackhole; then
      if brew list --cask blackhole-2ch >/dev/null 2>&1; then
        brew reinstall --cask blackhole-2ch || true
      else
        brew install --cask blackhole-2ch || brew install blackhole-2ch || return 1
      fi
    fi
    # BlackHole só deve ser considerado pronto quando o driver aparecer no HAL/CoreAudio, não apenas quando o brew listar o cask.
    sudo killall -9 coreaudiod >/dev/null 2>&1 || true
    sleep 8
    if ! has_blackhole; then
      echo "AVISO: BlackHole instalado, mas pode precisar reiniciar o Mac para aparecer."
      touch "$ROOT_DIR/.blackhole_restart_required" 2>/dev/null || true
    fi
    return 0
  }

  instalar_plugin_obrigatorio(){
    local SLUG="$1"; local NAME="$2"; local REPOS="$3"; local REGEX="$4"; local CHECK_FUNC="$5"
    if $CHECK_FUNC; then echo "OK: $NAME já detectado."; return 0; fi
    echo "Instalando/verificando $NAME..."
    local LOCAL_PKG DL_FILE
    LOCAL_PKG="$(find "$ROOT_DIR/plugins/$SLUG/macos" -type f \( -iname "*.pkg" -o -iname "*.dmg" -o -iname "*.zip" \) 2>/dev/null | head -n 1)"
    install_obs_plugin_payload_mac "$LOCAL_PKG" "$NAME" || true
    if ! $CHECK_FUNC; then
      DL_FILE="$TMP_PLUG/${SLUG}.pkg"
      baixar_primeiro_arquivo_do_github_dir "plugins/$SLUG/macos" "$DL_FILE" && install_obs_plugin_payload_mac "$DL_FILE" "$NAME" || true
    fi
    if ! $CHECK_FUNC; then
      DL_FILE="$TMP_PLUG/${SLUG}-public.pkg"
      baixar_asset_github_multi_mac "$REPOS" "$REGEX" "$DL_FILE" && install_obs_plugin_payload_mac "$DL_FILE" "$NAME" || true
    fi
    if $CHECK_FUNC; then
      echo "OK: $NAME instalado/detectado."
      return 0
    fi
    echo "ERRO: $NAME não foi instalado/detectado."
    echo "Para instalação 100% garantida, coloque o instalador macOS oficial em: plugins/$SLUG/macos no GitHub."
    return 1
  }

  local FAILS=0
  if has_blackhole; then echo "OK: BlackHole 2ch já instalado/detectado."; else instalar_blackhole_obrigatorio || FAILS=$((FAILS+1)); fi

  instalar_plugin_obrigatorio "aitum-vertical" "Aitum Vertical" "Aitum/obs-vertical-canvas,Last-Fx/obs-aitum-vertical-canvas" "(vertical|canvas|aitum).*(mac|macos|universal).*\.(pkg|dmg|zip)$|.*\.(pkg|dmg|zip)$" has_aitum_vertical || FAILS=$((FAILS+1))
  instalar_plugin_obrigatorio "aitum-multistream" "Aitum Multistream" "Aitum/obs-aitum-multistream" "(multistream|multi|aitum).*(mac|macos|universal).*\.(pkg|dmg|zip)$|.*\.(pkg|dmg|zip)$" has_aitum_multi || FAILS=$((FAILS+1))
  instalar_plugin_obrigatorio "face-tracker" "Face Tracker" "norihiro/obs-face-tracker" "(face|tracker).*(mac|macos|universal).*\.(pkg|dmg|zip)$|.*mac.*\.(pkg|dmg|zip)$" has_face_tracker || FAILS=$((FAILS+1))

  if [ "$FAILS" != "0" ]; then
    echo "AVISO: $FAILS plugin(s) OBS ainda faltando. O FrameZero vai abrir, mas os recursos dependentes podem não aparecer no OBS."
    touch "$ROOT_DIR/.obs_plugins_missing" 2>/dev/null || true
  else
    rm -f "$ROOT_DIR/.obs_plugins_missing" 2>/dev/null || true
  fi
  echo "Plugins OBS: verificação concluída. Feche e abra o OBS para carregar plugins recém-instalados."
  return 0
}


bash "$ROOT_DIR/FRAMEZERO-INSTALL-OBS-PLUGINS-MAC.command" || { echo "AVISO: plugins podem precisar de reinicio, continuando Core."; exit 1; }
if [ "${FRAMEZERO_AUTO_INSTALL:-}" = "plugins_only" ]; then
  echo "Modo plugins_only concluído."
  exit 0
fi

configurar_obs_dock_mac() {
  echo ""
  echo "Configurando Browser Dock no OBS: FrameZero Clips..."
  if [ -f "$ROOT_DIR/tools/configure_obs_dock.py" ]; then
    if [ -x "$VENV_DIR/bin/python" ]; then
      "$VENV_DIR/bin/python" "$ROOT_DIR/tools/configure_obs_dock.py" || true
    else
      python3 "$ROOT_DIR/tools/configure_obs_dock.py" || true
    fi
    echo "Dock criado: Exibir > Docks > FrameZero Clips"
  else
    echo "Aviso: script de dock não encontrado."
  fi
}


configurar_obs_profile_mac() {
  echo ""
  echo "Instalando arquivo de configuração/perfil do OBS..."
  OBS_SUPPORT="$HOME/Library/Application Support/obs-studio"
  PROFILE_DIR="$OBS_SUPPORT/basic/profiles/FrameZero Clips"
  mkdir -p "$PROFILE_DIR"
  if [ -d "$ROOT_DIR/config/perfil-obs" ]; then
    cp -R "$ROOT_DIR/config/perfil-obs/"* "$PROFILE_DIR/" 2>/dev/null || true
    if [ -f "$PROFILE_DIR/basic.ini" ]; then
      echo "OK: perfil OBS instalado em $PROFILE_DIR"
    else
      echo "Aviso: tentei copiar o perfil OBS, mas o basic.ini não apareceu."
    fi
  else
    echo "Aviso: pasta config/perfil-obs não encontrada no pacote."
  fi
}

configurar_obs_profile_mac

configurar_autostart_mac() {
  echo ""
  echo "Configurando FrameZero Agent para iniciar automaticamente no Mac..."
  AGENT_SCRIPT="$ROOT_DIR/launcher/framezero-agent-mac.sh"
  if [ ! -f "$AGENT_SCRIPT" ]; then
    echo "Aviso: agente silencioso não encontrado: $AGENT_SCRIPT"
    return 0
  fi
  chmod +x "$AGENT_SCRIPT" 2>/dev/null || true
  mkdir -p "$HOME/Library/LaunchAgents"
  PLIST="$HOME/Library/LaunchAgents/br.com.framezero.clips.agent.plist"
  cat > "$PLIST" <<EOFPLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>br.com.framezero.clips.agent</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>$AGENT_SCRIPT</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <false/>
  <key>StandardOutPath</key>
  <string>$ROOT_DIR/.framezero/launchagent.out.log</string>
  <key>StandardErrorPath</key>
  <string>$ROOT_DIR/.framezero/launchagent.err.log</string>
</dict>
</plist>
EOFPLIST
  UID_ATUAL="$(id -u)"
  launchctl bootout "gui/$UID_ATUAL" "$PLIST" >/dev/null 2>&1 || true
  launchctl bootstrap "gui/$UID_ATUAL" "$PLIST" >/dev/null 2>&1 || true
  launchctl kickstart -k "gui/$UID_ATUAL/br.com.framezero.clips.agent" >/dev/null 2>&1 || true
  echo "Agent OK. Ele liga o servidor local sem abrir painel local."
}

registrar_launcher_mac() {
  LAUNCHER_APP="$ROOT_DIR/FrameZero Launcher.app"
  if [ -d "$LAUNCHER_APP" ]; then
    echo "Registrando FrameZero Launcher.app e protocolo framezero://..."
    chmod +x "$LAUNCHER_APP/Contents/MacOS/FrameZeroLauncher" 2>/dev/null || true
    xattr -dr com.apple.quarantine "$LAUNCHER_APP" 2>/dev/null || true
    LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"
    if [ -x "$LSREGISTER" ]; then
      "$LSREGISTER" -f "$LAUNCHER_APP" 2>/dev/null || true
    fi
    echo "Launcher registrado. O painel principal roda pelo dock do OBS."
  else
    echo "Aviso: FrameZero Launcher.app não encontrado."
  fi
}

instalar_app_aplicativos_mac() {
  echo ""
  echo "Atualizando app do FrameZero na pasta Aplicativos..."
  SRC_APP="$ROOT_DIR/FrameZero Launcher.app"
  DEST_APP="/Applications/FrameZero Clips.app"
  ALT_APP="/Applications/FrameZero Launcher.app"
  LEGACY_APP="/Applications/FrameZero.app"
  INSTALLER_APP="/Applications/Iniciar Instalador FrameZero.app"

  if [ ! -d "$SRC_APP" ]; then
    echo "AVISO: app launcher não encontrado no pacote: $SRC_APP"
    return 1
  fi

  # Remove apps antigos/quebrados e também o instalador colocado por engano em Aplicativos.
  for OLD_APP in "$LEGACY_APP" "$DEST_APP" "$ALT_APP" "$INSTALLER_APP"; do
    if [ -d "$OLD_APP" ]; then
      echo "Removendo app antigo: $OLD_APP"
      rm -rf "$OLD_APP" 2>/dev/null || sudo rm -rf "$OLD_APP" 2>/dev/null || true
    fi
  done

  # Garante que o app instalado seja o app FINAL, com ícone real e abrindo Terminal visível.
  mkdir -p "$SRC_APP/Contents/MacOS" "$SRC_APP/Contents/Resources" 2>/dev/null || true

  # Aplica o ícone do FrameZero de forma robusta.
  # O erro do ícone genérico acontece quando o .app é copiado sem o .icns válido
  # ou quando o LaunchServices/Finder mantém cache antigo.
  if [ -f "$ROOT_DIR/assets/FrameZero.icns" ]; then
    cp -f "$ROOT_DIR/assets/FrameZero.icns" "$SRC_APP/Contents/Resources/FrameZero.icns" 2>/dev/null || true
  fi

  # Fallback: se existir PNG, o próprio Mac gera um .icns limpo via iconutil.
  if [ -f "$ROOT_DIR/assets/FrameZeroIcon1024.png" ] && command -v sips >/dev/null 2>&1 && command -v iconutil >/dev/null 2>&1; then
    ICONSET="$ROOT_DIR/.framezero_icon.iconset"
    rm -rf "$ICONSET" 2>/dev/null || true
    mkdir -p "$ICONSET" 2>/dev/null || true
    sips -z 16 16     "$ROOT_DIR/assets/FrameZeroIcon1024.png" --out "$ICONSET/icon_16x16.png" >/dev/null 2>&1 || true
    sips -z 32 32     "$ROOT_DIR/assets/FrameZeroIcon1024.png" --out "$ICONSET/icon_16x16@2x.png" >/dev/null 2>&1 || true
    sips -z 32 32     "$ROOT_DIR/assets/FrameZeroIcon1024.png" --out "$ICONSET/icon_32x32.png" >/dev/null 2>&1 || true
    sips -z 64 64     "$ROOT_DIR/assets/FrameZeroIcon1024.png" --out "$ICONSET/icon_32x32@2x.png" >/dev/null 2>&1 || true
    sips -z 128 128   "$ROOT_DIR/assets/FrameZeroIcon1024.png" --out "$ICONSET/icon_128x128.png" >/dev/null 2>&1 || true
    sips -z 256 256   "$ROOT_DIR/assets/FrameZeroIcon1024.png" --out "$ICONSET/icon_128x128@2x.png" >/dev/null 2>&1 || true
    sips -z 256 256   "$ROOT_DIR/assets/FrameZeroIcon1024.png" --out "$ICONSET/icon_256x256.png" >/dev/null 2>&1 || true
    sips -z 512 512   "$ROOT_DIR/assets/FrameZeroIcon1024.png" --out "$ICONSET/icon_256x256@2x.png" >/dev/null 2>&1 || true
    sips -z 512 512   "$ROOT_DIR/assets/FrameZeroIcon1024.png" --out "$ICONSET/icon_512x512.png" >/dev/null 2>&1 || true
    sips -z 1024 1024 "$ROOT_DIR/assets/FrameZeroIcon1024.png" --out "$ICONSET/icon_512x512@2x.png" >/dev/null 2>&1 || true
    iconutil -c icns "$ICONSET" -o "$SRC_APP/Contents/Resources/FrameZero.icns" >/dev/null 2>&1 || true
    rm -rf "$ICONSET" 2>/dev/null || true
  fi
  cat > "$SRC_APP/Contents/MacOS/FrameZero" <<'APP_LAUNCHER'
#!/bin/bash
set -u
STABLE_ROOT="$HOME/Library/Application Support/obs-studio/FrameZero"
SCRIPT="$STABLE_ROOT/INICIAR.command"
INSTALLER="$STABLE_ROOT/INSTALAR-MAC.command"
if [ -f "$SCRIPT" ]; then
  chmod +x "$SCRIPT" 2>/dev/null || true
  xattr -dr com.apple.quarantine "$SCRIPT" 2>/dev/null || true
  osascript <<OSA >/dev/null 2>&1
try
  tell application "Terminal"
    activate
    do script "cd \"$STABLE_ROOT\" && bash ./INICIAR.command"
  end tell
end try
OSA
  exit 0
fi
if [ -f "$INSTALLER" ]; then
  chmod +x "$INSTALLER" 2>/dev/null || true
  xattr -dr com.apple.quarantine "$INSTALLER" 2>/dev/null || true
  osascript <<OSA >/dev/null 2>&1
try
  tell application "Terminal"
    activate
    do script "cd \"$STABLE_ROOT\" && bash ./INSTALAR-MAC.command"
  end tell
end try
OSA
  exit 0
fi
osascript -e 'display dialog "FrameZero não encontrou a instalação local. Rode o instalador FrameZero novamente." buttons {"OK"} default button "OK" with title "FrameZero"' >/dev/null 2>&1 || true
exit 1
APP_LAUNCHER
  chmod +x "$SRC_APP/Contents/MacOS/FrameZero" 2>/dev/null || true
  rm -f "$SRC_APP/Contents/MacOS/FrameZeroLauncher" "$SRC_APP/Contents/MacOS/FrameZeroInstaller" 2>/dev/null || true
  cat > "$SRC_APP/Contents/Info.plist" <<'APP_PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key>
  <string>FrameZero Clips</string>
  <key>CFBundleDisplayName</key>
  <string>FrameZero Clips</string>
  <key>CFBundleIdentifier</key>
  <string>br.com.framezero.clips</string>
  <key>CFBundleVersion</key>
  <string>1.0.100</string>
  <key>CFBundleShortVersionString</key>
  <string>1.0.100</string>
  <key>CFBundlePackageType</key>
  <string>APPL</string>
  <key>CFBundleExecutable</key>
  <string>FrameZero</string>
  <key>CFBundleIconFile</key>
  <string>FrameZero.icns</string>
  <key>LSMinimumSystemVersion</key>
  <string>12.0</string>
  <key>CFBundleURLTypes</key>
  <array>
    <dict>
      <key>CFBundleURLName</key>
      <string>FrameZero Local Launcher</string>
      <key>CFBundleURLSchemes</key>
      <array><string>framezero</string></array>
    </dict>
  </array>
</dict>
</plist>
APP_PLIST

  /usr/bin/ditto "$SRC_APP" "$DEST_APP" 2>/dev/null || sudo /usr/bin/ditto "$SRC_APP" "$DEST_APP" 2>/dev/null || true

  if [ -d "$DEST_APP" ] && [ -x "$DEST_APP/Contents/MacOS/FrameZero" ]; then
    chmod +x "$DEST_APP/Contents/MacOS/FrameZero" 2>/dev/null || sudo chmod +x "$DEST_APP/Contents/MacOS/FrameZero" 2>/dev/null || true
    xattr -dr com.apple.quarantine "$DEST_APP" 2>/dev/null || true

    # Garante que o ícone também exista no app final em /Applications.
    mkdir -p "$DEST_APP/Contents/Resources" 2>/dev/null || sudo mkdir -p "$DEST_APP/Contents/Resources" 2>/dev/null || true
    if [ -f "$SRC_APP/Contents/Resources/FrameZero.icns" ]; then
      cp -f "$SRC_APP/Contents/Resources/FrameZero.icns" "$DEST_APP/Contents/Resources/FrameZero.icns" 2>/dev/null || sudo cp -f "$SRC_APP/Contents/Resources/FrameZero.icns" "$DEST_APP/Contents/Resources/FrameZero.icns" 2>/dev/null || true
    fi
    touch "$DEST_APP" "$DEST_APP/Contents" "$DEST_APP/Contents/Info.plist" "$DEST_APP/Contents/Resources/FrameZero.icns" 2>/dev/null || true

    # Atualiza LaunchServices e caches do Finder/Dock para remover ícone genérico.
    LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"
    if [ -x "$LSREGISTER" ]; then
      "$LSREGISTER" -u "$DEST_APP" >/dev/null 2>&1 || true
      "$LSREGISTER" -f "$DEST_APP" >/dev/null 2>&1 || true
    fi
    qlmanage -r cache >/dev/null 2>&1 || true
    killall Finder >/dev/null 2>&1 || true
    killall Dock >/dev/null 2>&1 || true

    if [ -s "$DEST_APP/Contents/Resources/FrameZero.icns" ]; then
      echo "OK: ícone FrameZero aplicado: $DEST_APP/Contents/Resources/FrameZero.icns"
    else
      echo "AVISO: ícone FrameZero.icns não foi encontrado no app final."
    fi
    echo "OK: app final instalado em /Applications/FrameZero Clips.app"
    echo "OK: abertura pelo Terminal visível configurada."
  else
    echo "ERRO: não consegui instalar o app final em /Applications/FrameZero Clips.app"
    echo "O FrameZero não vai deixar app antigo/instalador como app final."
    return 1
  fi
}

echo "Gerando INICIAR.command corrigido..."
cat > "$ROOT_DIR/INICIAR.command" <<'EOI'
#!/bin/bash
set -Ee
trap 'RC=$?; if [ "$RC" -ne 0 ]; then echo ""; echo "[ERRO] A instalação encontrou um problema e esta janela vai ficar aberta."; echo "Tire um print desta tela e envie para o suporte."; read -r -p "Pressione ENTER para fechar..." _; fi' EXIT
cd "$(dirname "$0")"

STABLE_DIR="$HOME/Library/Application Support/obs-studio/FrameZero"
ROOT_REAL="$(cd "$(dirname "$0")" && pwd -P)"
if [[ "$ROOT_REAL" == /tmp/* || "$ROOT_REAL" == /private/tmp/* ]]; then
  if [ -f "$STABLE_DIR/INICIAR.command" ]; then
    echo "Redirecionando para a instalação oficial do FrameZero..."
    exec bash "$STABLE_DIR/INICIAR.command"
  fi
fi

ROOT_DIR="$(pwd)"
APP_DIR="$ROOT_DIR/app"
VENV_DIR="$ROOT_DIR/.framezero/venv"
REQ_FILE="$APP_DIR/requirements.txt"

clear
cat <<'MSG'
============================================================
 FRAMEZERO CLIPS 1.1.8 - LAUNCHER MAC
============================================================

Abrindo OBS e iniciando FrameZero...
Deixe esta janela aberta enquanto estiver usando o OBS. O Clips escuta o áudio sem precisar iniciar gravação.
Feito por @gabrielxreis_ Gabriel Reis

MSG

chmod +x *.command 2>/dev/null || true
xattr -dr com.apple.quarantine *.command 2>/dev/null || true

# ============================================================
# OBS Studio obrigatório antes de qualquer etapa do FrameZero
# Fonte oficial: https://obsproject.com/download
# ============================================================
detect_obs_app_mac() {
  if [ -d "/Applications/OBS.app" ]; then echo "/Applications/OBS.app"; return 0; fi
  if [ -d "/Applications/OBS Studio.app" ]; then echo "/Applications/OBS Studio.app"; return 0; fi
  return 1
}

obs_version_mac() {
  local APP="$1"
  if [ -n "$APP" ] && [ -f "$APP/Contents/Info.plist" ]; then
    /usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$APP/Contents/Info.plist" 2>/dev/null || true
  fi
}

latest_obs_version_mac() {
  curl -fsSL --connect-timeout 25 --retry 2 'https://obsproject.com/download' 2>/dev/null \
    | tr '\n' ' ' \
    | sed -n 's/.*Version:[[:space:]]*\([0-9][0-9.]*\).*/\1/p' \
    | head -n 1
}

latest_obs_dmg_url_mac() {
  local HTML ARCH_RE URL
  HTML="$(curl -fsSL --connect-timeout 30 --retry 2 'https://obsproject.com/download' 2>/dev/null || true)"
  [ -z "$HTML" ] && return 1
  case "$(uname -m)" in
    arm64|aarch64) ARCH_RE='apple|arm64|silicon' ;;
    *) ARCH_RE='intel|x86_64' ;;
  esac
  URL="$(printf '%s' "$HTML" \
    | tr '\"' '\n' \
    | grep -Eio 'https?://[^ ]+\.dmg[^ <]*' \
    | grep -Ei 'obs|OBS' \
    | grep -Ei 'mac|macos' \
    | grep -Ei "$ARCH_RE" \
    | head -n 1)"
  if [ -z "$URL" ]; then
    URL="$(printf '%s' "$HTML" \
      | tr '\"' '\n' \
      | grep -Eio 'https?://[^ ]+\.dmg[^ <]*' \
      | grep -Ei 'obs|OBS' \
      | grep -Ei 'mac|macos' \
      | head -n 1)"
  fi
  [ -n "$URL" ] && echo "$URL"
}



registrar_obs_path_mac() {
  local OBS_APP="$1"
  [ -z "$OBS_APP" ] && OBS_APP="$(detect_obs_app_mac || true)"
  [ -z "$OBS_APP" ] && return 1
  mkdir -p "$ROOT_DIR/.framezero" "$APP_DIR" 2>/dev/null || true
  echo "$OBS_APP" > "$ROOT_DIR/.framezero/obs_path.txt"
  echo "OBS instalado em: $OBS_APP"
  if command -v python3 >/dev/null 2>&1; then
    python3 - "$APP_DIR/config.json" "$OBS_APP" <<'PYOBS'
import json, pathlib, sys
p=pathlib.Path(sys.argv[1]); obs=sys.argv[2]
try:
    cfg=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
except Exception:
    cfg={}
cfg['obs_app_path']=obs
cfg['obs_bin_path']=obs
cfg['obs_installed']=True
p.parent.mkdir(parents=True, exist_ok=True)
p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding='utf-8')
PYOBS
  fi
}

instalar_ou_atualizar_obs_mac() {
  echo ""
  echo "============================================================"
  echo " VERIFICANDO OBS STUDIO - OBRIGATÓRIO"
  echo "============================================================"
  echo "Fonte oficial: https://obsproject.com/download"

  local OBS_APP CURRENT LATEST NEED_UPDATE JSON DMG URL MOUNT_DIR FOUND_APP
  OBS_APP="$(detect_obs_app_mac || true)"
  CURRENT="$(obs_version_mac "$OBS_APP")"
  LATEST="$(latest_obs_version_mac || true)"

  if [ -n "$OBS_APP" ]; then
    echo "OBS encontrado em: $OBS_APP"
    [ -n "$CURRENT" ] && echo "Versão instalada: $CURRENT"
  else
    echo "OBS não encontrado na pasta Aplicativos. Vou instalar agora."
  fi
  [ -n "$LATEST" ] && echo "Versão mais recente no site oficial: $LATEST"

  NEED_UPDATE=0
  if [ -z "$OBS_APP" ]; then
    NEED_UPDATE=1
  elif [ -n "$LATEST" ] && [ -n "$CURRENT" ] && [ "$CURRENT" != "$LATEST" ]; then
    echo "OBS está diferente da versão mais recente. Vou atualizar antes de continuar."
    NEED_UPDATE=1
  fi

  if [ "$NEED_UPDATE" = "1" ]; then
    JSON="$HOME/Desktop/framezero-obs-latest.json"
    DMG="$HOME/Desktop/FrameZero-OBS-Studio.dmg"
    URL="$(latest_obs_dmg_url_mac)"
    if [ -z "$URL" ]; then
      echo "ERRO: não consegui localizar o instalador oficial do OBS na página de download."
      echo "Fonte usada: https://obsproject.com/download"
      return 1
    fi
    echo "Baixando OBS oficial pelo link encontrado em obsproject.com/download: $URL"
    curl -L --fail --retry 3 --connect-timeout 25 --progress-bar -o "$DMG" "$URL" || { echo "ERRO: falha ao baixar OBS."; return 1; }
    echo "Montando instalador do OBS..."
    MOUNT_DIR="$(hdiutil attach "$DMG" -nobrowse 2>/dev/null | grep -o '/Volumes/.*' | head -n 1 || true)"
    if [ -z "$MOUNT_DIR" ]; then
      echo "ERRO: não consegui montar o DMG do OBS."
      return 1
    fi
    FOUND_APP="$(find "$MOUNT_DIR" -maxdepth 3 -type d \( -name 'OBS.app' -o -name 'OBS Studio.app' \) 2>/dev/null | head -n 1)"
    if [ -z "$FOUND_APP" ]; then
      hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true
      echo "ERRO: DMG do OBS montou, mas não encontrei OBS.app dentro dele."
      return 1
    fi
    echo "Instalando/atualizando OBS em /Applications..."
    rm -rf "/Applications/OBS.app" "/Applications/OBS Studio.app" 2>/dev/null || sudo rm -rf "/Applications/OBS.app" "/Applications/OBS Studio.app" 2>/dev/null || true
    cp -R "$FOUND_APP" "/Applications/" 2>/dev/null || sudo cp -R "$FOUND_APP" "/Applications/" || { hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true; echo "ERRO: falha ao copiar OBS para /Applications."; return 1; }
    hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true
    OBS_APP="$(detect_obs_app_mac || true)"
  fi

  if [ -z "$OBS_APP" ]; then
    echo "ERRO: OBS continua ausente. Não vou iniciar o Core sem OBS instalado."
    return 1
  fi
  registrar_obs_path_mac "$OBS_APP"
  echo "OK: OBS pronto para o FrameZero."
  return 0
}

precheck_basico_mac() {
  echo ""
  echo "Verificando programas necessários para instalar..."
  ERROS=0
  for CMD in curl unzip xattr shasum; do
    if command -v "$CMD" >/dev/null 2>&1; then
      echo "OK: $CMD encontrado."
    else
      echo "ERRO: $CMD não encontrado no Mac."
      ERROS=$((ERROS+1))
    fi
  done

  if [ "$(uname -m)" = "arm64" ]; then
    echo "OK: Mac Apple Silicon detectado."
  else
    echo "ERRO: esta versão exige Mac Apple Silicon M1/M2/M3/M4."
    ERROS=$((ERROS+1))
  fi

  if instalar_ou_atualizar_obs_mac; then
    echo "OK: OBS instalado/atualizado e caminho registrado."
  else
    echo "ERRO: OBS Studio é obrigatório e não pôde ser instalado/atualizado."
    ERROS=$((ERROS+1))
  fi

  if [ "$ERROS" -gt 0 ]; then
    echo ""
    echo "Não dá para continuar antes de corrigir os itens com ERRO acima."
    read -r -p "Pressione ENTER para sair..." _
    exit 1
  fi
  echo "Pré-verificação concluída."
}

precheck_basico_mac

if [ "$(uname -m)" != "arm64" ]; then
  echo "ERRO: esta versão exige Mac Apple Silicon (M1/M2/M3/M4)."
  read -p "Pressione ENTER para sair..."
  exit 1
fi

if [ ! -x "$VENV_DIR/bin/python" ]; then
  echo "Ambiente Python não encontrado. Vou rodar o instalador agora..."
  bash "$ROOT_DIR/INSTALAR-MAC.command"
fi

source "$VENV_DIR/bin/activate"

PYVER=$(python - <<'PY'
import sys
print(f"{sys.version_info.major}.{sys.version_info.minor}")
PY
)
case "$PYVER" in
  3.10|3.11|3.12|3.13) ;;
  *)
    echo "Ambiente Python incompatível. Reinstalando..."
    deactivate 2>/dev/null || true
    rm -rf "$VENV_DIR"
    bash "$ROOT_DIR/INSTALAR-MAC.command"
    source "$VENV_DIR/bin/activate"
    ;;
esac

export PATH="$ROOT_DIR/bin:$APP_DIR/ffmpeg/bin:$PATH"

kill_port(){
  PORT="$1"
  PID="$(lsof -ti tcp:$PORT 2>/dev/null || true)"
  if [ -n "$PID" ]; then
    echo "Encerrando servidor antigo na porta $PORT..."
    kill -9 $PID 2>/dev/null || true
  fi
}

if ! python - <<'PY' >/dev/null 2>&1
import mlx_whisper, numpy, sounddevice, websockets
PY
then
  echo "Dependências do FrameZero incompletas. Corrigindo agora..."
  python -m pip install --upgrade pip wheel
  python -m pip install "setuptools<82"
  python -m pip install --upgrade --upgrade-strategy only-if-needed -r "$REQ_FILE"
fi

export PATH="$ROOT_DIR/bin:$APP_DIR/ffmpeg/bin:$PATH"

kill_port(){
  PORT="$1"
  PID="$(lsof -ti tcp:$PORT 2>/dev/null || true)"
  if [ -n "$PID" ]; then
    echo "Encerrando servidor antigo na porta $PORT..."
    kill -9 $PID 2>/dev/null || true
  fi
}

if ! python - <<'PY' >/dev/null 2>&1
import mlx_whisper, numpy, sounddevice, websockets
PY
then
  echo ""
  echo "ERRO: não consegui carregar as dependências do FrameZero."
  echo "Rode o instalador novamente."
  echo ""
  read -p "Pressione ENTER para sair..."
  exit 1
fi

echo "Verificando OBS, BlackHole e plugins obrigatórios antes de iniciar o Core..."
instalar_ou_atualizar_obs_mac || { echo "ERRO: OBS Studio é obrigatório."; read -p "Pressione ENTER para sair..." _; exit 1; }
if [ -f "$ROOT_DIR/FRAMEZERO-INSTALL-OBS-PLUGINS-MAC.command" ]; then
  bash "$ROOT_DIR/FRAMEZERO-INSTALL-OBS-PLUGINS-MAC.command" || { echo "ERRO: plugins obrigatórios ausentes. O Core não será iniciado."; read -p "Pressione ENTER para sair..." _; exit 1; }
fi


configurar_obs_websocket_mac(){
  local OBS_SUPPORT="$HOME/Library/Application Support/obs-studio"
  local GLOB="$OBS_SUPPORT/global.ini"
  mkdir -p "$OBS_SUPPORT"
  python3 - "$GLOB" <<'PYWS'
from pathlib import Path
import sys, configparser
p=Path(sys.argv[1])
cp=configparser.ConfigParser(strict=False)
cp.optionxform=str
if p.exists(): cp.read(p, encoding='utf-8')
wanted={
    'ServerEnabled':'true',
    'ServerPort':'4455',
    'AlertsEnabled':'false',
    'AuthRequired':'false',
    'FirstLoad':'false'
}
changed=False
if not cp.has_section('OBSWebSocket'):
    cp.add_section('OBSWebSocket'); changed=True
for k,v in wanted.items():
    if cp['OBSWebSocket'].get(k) != v:
        cp['OBSWebSocket'][k]=v; changed=True
if changed:
    with p.open('w', encoding='utf-8') as f: cp.write(f, space_around_delimiters=False)
    print('OK: OBS WebSocket configurado automaticamente.')
else:
    print('OK: OBS WebSocket já estava configurado. Nada a alterar.')
PYWS
}

echo "Verificando atualizações antes de abrir o OBS..."
if [ -f "$ROOT_DIR/FrameZero-Update-Check.command" ]; then
  bash "$ROOT_DIR/FrameZero-Update-Check.command" || true
fi
configurar_obs_websocket_mac || true
osascript -e 'tell application "OBS" to quit' >/dev/null 2>&1 || true
pkill -x OBS >/dev/null 2>&1 || true
sleep 2
kill_port 8765
kill_port 8766
kill_port 8889
sleep 1
OBS_APP_PATH="$(cat "$ROOT_DIR/.framezero/obs_path.txt" 2>/dev/null || detect_obs_app_mac || true)"
if [ -n "$OBS_APP_PATH" ]; then open "$OBS_APP_PATH" 2>/dev/null || true; else open -a "OBS" 2>/dev/null || open -a "OBS Studio" 2>/dev/null || true; fi
echo "Aguardando OBS carregar plugins e WebSocket..."
sleep 8

echo "FrameZero iniciado."
echo "Painel no OBS: Dock FrameZero Clips"
echo "WebSocket local: ws://localhost:8765"
echo "FrameZero pronto para uso."
echo ""

python "$APP_DIR/servidor.py"

echo ""
read -p "FrameZero finalizado. Pressione ENTER para fechar..."
EOI
echo '{"version":"1.1.8","installer_version":"1.0.99","online_installer_version":"1.0.99","app":"FrameZero Clips"}' > "$ROOT_DIR/framezero_local_version.json"
chmod +x "$ROOT_DIR/INICIAR.command"
chmod +x "$ROOT_DIR/FrameZero-Update-Check.command" 2>/dev/null || true
xattr -dr com.apple.quarantine "$ROOT_DIR/INICIAR.command" 2>/dev/null || true
chmod +x "$ROOT_DIR/ABRIR-FRAMEZERO-MAC.command" "$ROOT_DIR/DESLIGAR-FRAMEZERO-MAC.command" 2>/dev/null || true
xattr -dr com.apple.quarantine "$ROOT_DIR/ABRIR-FRAMEZERO-MAC.command" "$ROOT_DIR/DESLIGAR-FRAMEZERO-MAC.command" 2>/dev/null || true


verificar_instalacao_final_mac() {
  echo ""
  echo "============================================================"
  echo " VERIFICANDO INSTALAÇÃO DO FRAMEZERO"
  echo "============================================================"
  ERROS=0
  [ -f "$ROOT_DIR/app/servidor.py" ] && echo "OK: servidor local instalado." || { echo "ERRO: servidor.py não encontrado."; ERROS=$((ERROS+1)); }
  [ -x "$VENV_DIR/bin/python" ] && echo "OK: ambiente Python instalado." || { echo "ERRO: venv Python não encontrado."; ERROS=$((ERROS+1)); }
  [ -f "$ROOT_DIR/app/config.json" ] && echo "OK: config.json encontrado." || { echo "ERRO: config.json não encontrado."; ERROS=$((ERROS+1)); }
  [ -f "$ROOT_DIR/INICIAR.command" ] && echo "OK: inicializador criado." || { echo "ERRO: inicializador não encontrado."; ERROS=$((ERROS+1)); }
  [ -f "$ROOT_DIR/framezero_local_version.json" ] && echo "OK: versão local registrada." || { echo "ERRO: versão local não registrada."; ERROS=$((ERROS+1)); }
  if [ "$ERROS" -ne 0 ]; then
    echo ""
    echo "ERRO: a verificação final encontrou problemas."
    read -r -p "Pressione ENTER para sair..." _
    exit 1
  fi
  echo "Verificação final OK. Tudo pronto para uso."
}


garantir_atalho_aplicativos_mac() {
  echo ""
  echo "Garantindo atalho do FrameZero em Aplicativos..."
  STABLE_ROOT="$HOME/Library/Application Support/obs-studio/FrameZero"
  TMP_APP="$ROOT_DIR/.framezero/FrameZero Clips.app"
  rm -rf "$TMP_APP" 2>/dev/null || true
  mkdir -p "$TMP_APP/Contents/MacOS" "$TMP_APP/Contents/Resources" 2>/dev/null || true

  if [ -f "$ROOT_DIR/assets/FrameZero.icns" ]; then
    cp -f "$ROOT_DIR/assets/FrameZero.icns" "$TMP_APP/Contents/Resources/FrameZero.icns" 2>/dev/null || true
  fi

  cat > "$TMP_APP/Contents/MacOS/FrameZero" <<'FZ_APP_LAUNCH'
#!/bin/bash
set -u
STABLE_ROOT="$HOME/Library/Application Support/obs-studio/FrameZero"
SCRIPT="$STABLE_ROOT/INICIAR.command"
INSTALLER="$STABLE_ROOT/INSTALAR-MAC.command"
if [ -f "$SCRIPT" ]; then
  chmod +x "$SCRIPT" 2>/dev/null || true
  xattr -dr com.apple.quarantine "$STABLE_ROOT" 2>/dev/null || true
  osascript <<OSA >/dev/null 2>&1
try
  tell application "Terminal"
    activate
    do script "cd \"$STABLE_ROOT\" && bash ./INICIAR.command"
  end tell
end try
OSA
  exit 0
fi
if [ -f "$INSTALLER" ]; then
  chmod +x "$INSTALLER" 2>/dev/null || true
  xattr -dr com.apple.quarantine "$STABLE_ROOT" 2>/dev/null || true
  osascript <<OSA >/dev/null 2>&1
try
  tell application "Terminal"
    activate
    do script "cd \"$STABLE_ROOT\" && bash ./INSTALAR-MAC.command"
  end tell
end try
OSA
  exit 0
fi
osascript -e 'display dialog "FrameZero não encontrou a instalação local. Rode o instalador novamente." buttons {"OK"} default button "OK" with title "FrameZero"' >/dev/null 2>&1 || true
exit 1
FZ_APP_LAUNCH
  chmod +x "$TMP_APP/Contents/MacOS/FrameZero" 2>/dev/null || true

  cat > "$TMP_APP/Contents/Info.plist" <<'FZ_APP_PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key>
  <string>FrameZero</string>
  <key>CFBundleDisplayName</key>
  <string>FrameZero</string>
  <key>CFBundleIdentifier</key>
  <string>br.com.framezero.app</string>
  <key>CFBundleVersion</key>
  <string>1.0.100</string>
  <key>CFBundleShortVersionString</key>
  <string>1.0.100</string>
  <key>CFBundlePackageType</key>
  <string>APPL</string>
  <key>CFBundleExecutable</key>
  <string>FrameZero</string>
  <key>CFBundleIconFile</key>
  <string>FrameZero.icns</string>
  <key>LSMinimumSystemVersion</key>
  <string>12.0</string>
</dict>
</plist>
FZ_APP_PLIST

  # Mantem somente um app em Aplicativos para não confundir o usuário.
  rm -rf "/Applications/FrameZero.app" "/Applications/FrameZero Clips.app" 2>/dev/null || true
  sudo rm -rf "/Applications/FrameZero.app" "/Applications/FrameZero Clips.app" 2>/dev/null || true

  DEST_APP="/Applications/FrameZero Clips.app"
  /usr/bin/ditto "$TMP_APP" "$DEST_APP" 2>/dev/null || sudo /usr/bin/ditto "$TMP_APP" "$DEST_APP" 2>/dev/null || true
  if [ -d "$DEST_APP" ] && [ -x "$DEST_APP/Contents/MacOS/FrameZero" ]; then
    xattr -dr com.apple.quarantine "$DEST_APP" 2>/dev/null || true
    touch "$DEST_APP" "$DEST_APP/Contents/Info.plist" 2>/dev/null || true
    echo "OK: atalho unico criado em $DEST_APP"
  else
    echo "AVISO: não consegui criar $DEST_APP. A instalação principal continuará funcionando."
  fi

  LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"
  if [ -x "$LSREGISTER" ]; then
    "$LSREGISTER" -u "/Applications/FrameZero.app" >/dev/null 2>&1 || true
    "$LSREGISTER" -f "/Applications/FrameZero Clips.app" >/dev/null 2>&1 || true
  fi
  qlmanage -r cache >/dev/null 2>&1 || true
}

# v81t: sem agent oculto e sem protocolo obrigatório.
# O usuário inicia pelo INICIAR-FRAMEZERO.command, com Terminal visível.
configurar_obs_dock_mac
registrar_launcher_mac
instalar_app_aplicativos_mac || echo "AVISO: app principal em /Applications não foi criado pela rotina antiga; tentando fallback seguro."
garantir_atalho_aplicativos_mac
verificar_instalacao_final_mac

echo ""
echo "============================================================"
echo " INSTALAÇÃO CONCLUÍDA"
echo "============================================================"
if [ "${FRAMEZERO_SKIP_LAUNCH:-}" = "1" ]; then
  echo "FrameZero Clips instalado. O instalador continuará com os pacotes adicionais."
  echo "Painel do OBS: Dock FrameZero Clips"
  echo ""
  exit 0
fi

echo "Agora vou iniciar o FrameZero Clips."
echo "Deixe esta janela aberta enquanto estiver usando o OBS. O Clips escuta o áudio sem precisar iniciar gravação."
echo "O painel fica disponível no dock do OBS: FrameZero Clips"
echo ""
sleep 1
bash "$ROOT_DIR/INICIAR.command"
echo ""
read -r -p "FrameZero finalizado. Pressione ENTER para fechar..." _
