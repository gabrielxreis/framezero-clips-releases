#!/bin/bash
set -e

SITE_URL="https://clips.framezeroai.com.br/obs"
STABLE_DIR="$HOME/Library/Application Support/obs-studio/FrameZero"

CURRENT_VERSION="1.1.14"
VERSION_URL="https://raw.githubusercontent.com/gabrielxreis/framezero-clips-releases/main/latest/version.json"

check_for_updates() {
  TMP_DIR="${TMPDIR:-/tmp}/FrameZeroSelfUpdate"
  mkdir -p "$TMP_DIR"
  MANIFEST="$TMP_DIR/version.json"
  echo "Verificando atualizações do FrameZero"
  if ! curl -fL --connect-timeout 10 "$VERSION_URL" -o "$MANIFEST"; then
    echo "Não consegui verificar atualização agora. Continuando com a versão instalada."
    return 0
  fi
  NEED_UPDATE="$(python3 - "$MANIFEST" "$STABLE_DIR/framezero_local_version.json" <<'PY' 2>/dev/null || echo no
import json, sys
from pathlib import Path
from packaging.version import Version
manifest = json.load(open(sys.argv[1]))
latest = str(manifest.get('latest_version','0.0.0'))
latest_installer = str(manifest.get('online_installer_version') or manifest.get('installer_version') or manifest.get('installer_ui_version') or '0.0.0')
force = bool(manifest.get('force_update', False) or manifest.get('required_update', False))
local = '0.0.0'
local_installer = '0.0.0'
p = Path(sys.argv[2])
if p.exists():
    try:
        j = json.load(open(p))
        local = str(j.get('version','0.0.0'))
        local_installer = str(j.get('installer_version') or j.get('online_installer_version') or '0.0.0')
    except Exception: pass
print('yes' if force or Version(latest) > Version(local) or Version(latest_installer) > Version(local_installer) else 'no')
PY
)"
  if [ "$NEED_UPDATE" = "yes" ]; then
    echo ""
    echo "Atualização encontrada. Baixando pacote de atualização..."
    ZIP="$TMP_DIR/clips_update.zip"
    EXTRACT="$TMP_DIR/clips_extract"
    rm -rf "$EXTRACT"; mkdir -p "$EXTRACT"
    MAC_URL="$(python3 - "$MANIFEST" <<'PY'
import json, sys
print(json.load(open(sys.argv[1])).get('mac_url',''))
PY
)"
    if [ -z "$MAC_URL" ]; then echo "Manifest sem pacote Mac."; return 0; fi
    if ! curl -fL "$MAC_URL" -o "$ZIP"; then echo "Falha ao baixar atualização."; return 0; fi
    unzip -q -o "$ZIP" -d "$EXTRACT"
    SCRIPT="$(find "$EXTRACT" -type f -name '*FRAMEZERO*CLIPS*.command' | head -n 1)"
    if [ -z "$SCRIPT" ]; then echo "Não encontrei o instalador da atualização."; return 0; fi
    chmod +x "$SCRIPT" 2>/dev/null || true
    FRAMEZERO_AUTO_INSTALL=update bash "$SCRIPT"
    return 10
  fi
  return 0
}

ROOT_DIR="$(cd "$(dirname "$0")" && pwd -P)"

# Se estiver rodando de Downloads/ZIP, copia para a pasta fixa do OBS e reabre de lá.
if [ "$ROOT_DIR" != "$STABLE_DIR" ]; then
  echo "============================================================"
  echo " FRAMEZERO CLIPS 1.1.14 - INICIALIZADOR MAC"
  echo "============================================================"
  echo "Copiando/atualizando FrameZero em:"
  echo "  $STABLE_DIR"
  mkdir -p "$STABLE_DIR"

  TMP_CONFIG=""
  if [ -f "$STABLE_DIR/app/config.json" ]; then
    TMP_CONFIG="$(mktemp /tmp/framezero_config.XXXXXX.json)"
    cp "$STABLE_DIR/app/config.json" "$TMP_CONFIG" 2>/dev/null || true
  fi

  if command -v rsync >/dev/null 2>&1; then
    rsync -a --delete \
      --exclude '.framezero/' \
      --exclude 'app/config.json' \
      --exclude 'app/venv/' \
      --exclude 'venv/' \
      --exclude 'logs/' \
      --exclude '__pycache__/' \
      --exclude '.pytest_cache/' \
      --exclude '.DS_Store' \
      "$ROOT_DIR/" "$STABLE_DIR/"
  else
    ditto "$ROOT_DIR" "$STABLE_DIR"
  fi

  if [ -n "$TMP_CONFIG" ] && [ -f "$TMP_CONFIG" ]; then
    mkdir -p "$STABLE_DIR/app"
    cp "$TMP_CONFIG" "$STABLE_DIR/app/config.json" 2>/dev/null || true
    rm -f "$TMP_CONFIG" 2>/dev/null || true
  fi

  chmod +x "$STABLE_DIR"/*.command 2>/dev/null || true
  xattr -dr com.apple.quarantine "$STABLE_DIR" 2>/dev/null || true
  exec "$STABLE_DIR/INICIAR-FRAMEZERO.command"
fi

check_for_updates
UPD_RC=$?
if [ "$UPD_RC" = "10" ]; then
  echo "Atualização aplicada. Reabrindo FrameZero Clips..."
  exec "$STABLE_DIR/INICIAR-FRAMEZERO.command"
fi

cd "$STABLE_DIR"
rm -f /tmp/framezero-run-*.command 2>/dev/null || true
# Remove agent oculto de versões antigas; v81t usa Terminal/CMD visível pelo inicializador.
OLD_PLIST="$HOME/Library/LaunchAgents/br.com.framezero.clips.agent.plist"
if [ -f "$OLD_PLIST" ]; then
  launchctl bootout "gui/$(id -u)" "$OLD_PLIST" >/dev/null 2>&1 || true
  rm -f "$OLD_PLIST" 2>/dev/null || true
fi
ROOT_DIR="$STABLE_DIR"
APP_DIR="$ROOT_DIR/app"
RUNTIME_DIR="$ROOT_DIR/.framezero"
VENV_DIR="$RUNTIME_DIR/venv"
REQ_FILE="$APP_DIR/requirements.txt"
REQ_HASH_FILE="$RUNTIME_DIR/.requirements.sha256"
LOG_DIR="$ROOT_DIR/logs"
LOG_FILE="$LOG_DIR/framezero-terminal.log"
mkdir -p "$LOG_DIR" "$RUNTIME_DIR"

touch "$LOG_FILE" 2>/dev/null || true
exec > >(tee -a "$LOG_FILE") 2>&1

clear
cat <<MSG
============================================================
 FRAMEZERO CLIPS 1.1.14 - INICIALIZADOR
============================================================

Este inicializador abre o OBS e inicia o servidor FrameZero
com o Terminal visível, para você acompanhar tudo em tempo real.

Painel OBS/site:
$SITE_URL

Deixe esta janela aberta enquanto estiver usando o FrameZero.

MSG

health_ok(){ /usr/bin/curl -fsS --connect-timeout 1 "http://127.0.0.1:8766/health" >/dev/null 2>&1; }

kill_port(){
  local PORT="$1"
  local PID
  PID="$(lsof -ti tcp:$PORT 2>/dev/null || true)"
  if [ -n "$PID" ]; then
    echo "Encerrando servidor antigo na porta $PORT..."
    kill -9 $PID 2>/dev/null || true
  fi
}

req_hash(){
  if command -v shasum >/dev/null 2>&1 && [ -f "$REQ_FILE" ]; then
    shasum -a 256 "$REQ_FILE" | awk '{print $1}'
  else
    echo ""
  fi
}

precisa_instalar="0"
if [ ! -x "$VENV_DIR/bin/python" ]; then
  precisa_instalar="1"
else
  HASH_ATUAL="$(req_hash)"
  HASH_ANTIGO="$(cat "$REQ_HASH_FILE" 2>/dev/null || true)"
  if [ -n "$HASH_ATUAL" ] && [ "$HASH_ATUAL" != "$HASH_ANTIGO" ]; then
    precisa_instalar="1"
  fi
fi

if [ "$precisa_instalar" = "1" ]; then
  echo "Preparando/atualizando ambiente. Isso só deve demorar quando for a primeira instalação ou quando houver dependência nova."
  FRAMEZERO_AUTO_INSTALL=update bash "$ROOT_DIR/INSTALAR-MAC.command"
else
  echo "Ambiente já instalado. Pulando instalação de dependências."
fi

# Para mostrar logs no Terminal, encerramos qualquer servidor oculto antigo antes de iniciar aqui.
kill_port 8765
kill_port 8766
kill_port 8889
sleep 1

if [ "$(uname -m)" != "arm64" ]; then
  echo "ERRO: esta versão exige Mac Apple Silicon M1/M2/M3/M4."
  read -p "Pressione ENTER para sair..."
  exit 1
fi

if [ ! -x "$VENV_DIR/bin/python" ]; then
  echo "ERRO: ambiente Python não encontrado mesmo após instalação."
  read -p "Pressione ENTER para sair..."
  exit 1
fi


ensure_ffmpeg_runtime_mac(){
  echo ""
  echo "============================================================"
  echo " VERIFICANDO FFMPEG - OBRIGATÓRIO PARA GERAR CORTES"
  echo "============================================================"
  export PATH="$ROOT_DIR/bin:$APP_DIR/ffmpeg/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

  if command -v ffmpeg >/dev/null 2>&1; then
    if ffmpeg -version >/dev/null 2>&1; then
      echo "OK: FFmpeg encontrado: $(command -v ffmpeg)"
      return 0
    fi
  fi

  echo "FFmpeg não encontrado. Sem FFmpeg o FrameZero detecta cortes, mas não renderiza 16x9/9x16."
  echo "Tentando instalar FFmpeg local obrigatório dentro do FrameZero..."
  source "$VENV_DIR/bin/activate"
  python -m pip install --upgrade imageio-ffmpeg
  python - "$ROOT_DIR" "$APP_DIR" <<'PYFFMPEG_RUNTIME'
import os, shutil, stat, sys
try:
    import imageio_ffmpeg
    src = imageio_ffmpeg.get_ffmpeg_exe()
    root = sys.argv[1]
    app = sys.argv[2]
    targets = [os.path.join(root, 'bin', 'ffmpeg'), os.path.join(app, 'ffmpeg', 'bin', 'ffmpeg')]
    for dest in targets:
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.copy2(src, dest)
        os.chmod(dest, os.stat(dest).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    print('FFmpeg local instalado:', targets[0])
except Exception as e:
    print('Falha ao instalar FFmpeg local:', e)
    sys.exit(1)
PYFFMPEG_RUNTIME

  export PATH="$ROOT_DIR/bin:$APP_DIR/ffmpeg/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
  if command -v ffmpeg >/dev/null 2>&1 && ffmpeg -version >/dev/null 2>&1; then
    echo "OK: FFmpeg instalado e validado: $(command -v ffmpeg)"
    return 0
  fi

  echo ""
  echo "ERRO: FFmpeg é obrigatório e não foi instalado."
  echo "Instale manualmente com: brew install ffmpeg"
  echo "Depois feche e abra o FrameZero novamente."
  read -p "Pressione ENTER para sair..."
  exit 1
}

ensure_ffmpeg_runtime_mac

echo "Abrindo OBS..."
open -a "OBS" 2>/dev/null || open -a "OBS Studio" 2>/dev/null || true
sleep 2

echo "Abrindo painel no navegador também..."
open "$SITE_URL" >/dev/null 2>&1 || true

echo ""
echo "Iniciando servidor FrameZero..."
echo "Health: http://127.0.0.1:8766/health"
echo "WebSocket: ws://127.0.0.1:8765"
echo "Painel: $SITE_URL"
echo ""

source "$VENV_DIR/bin/activate"
python "$APP_DIR/servidor.py"

echo ""
read -p "FrameZero foi encerrado. Pressione ENTER para fechar..."
