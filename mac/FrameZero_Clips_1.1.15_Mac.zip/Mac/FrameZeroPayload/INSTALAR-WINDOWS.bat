@echo off
chcp 65001 >nul
cd /d "%~dp0"
call "installers\INSTALAR-WINDOWS.bat"
