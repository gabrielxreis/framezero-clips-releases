@echo off
echo Fechando processos locais do FrameZero...
wmic process where "CommandLine like '%%servidor.py%%'" call terminate >nul 2>nul
echo Pronto.
pause
