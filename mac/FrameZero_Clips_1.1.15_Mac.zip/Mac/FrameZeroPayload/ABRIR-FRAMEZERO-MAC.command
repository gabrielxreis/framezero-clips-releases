#!/bin/bash
cd "$(dirname "$0")"
chmod +x "FrameZero Launcher.app/Contents/MacOS/FrameZeroLauncher" 2>/dev/null || true
xattr -dr com.apple.quarantine "FrameZero Launcher.app" 2>/dev/null || true
open "FrameZero Launcher.app"
