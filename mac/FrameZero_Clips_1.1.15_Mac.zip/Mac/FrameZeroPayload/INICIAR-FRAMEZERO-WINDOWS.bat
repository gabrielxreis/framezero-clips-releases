@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
title FrameZero Clips v81t - Inicializador
color 0E

set "SITE_URL=https://clips.framezeroai.com.br/obs"
set "ROOT=%~dp0"
set "ROOT=%ROOT:~0,-1%"
set "STABLE_ROOT=%APPDATA%\obs-studio\FrameZero"

REM Se estiver rodando do Download/ZIP, copia para a pasta fixa do OBS e reabre de la.
if /I not "%ROOT%"=="%STABLE_ROOT%" (
    echo ============================================================
    echo  FRAMEZERO CLIPS v81t - INICIALIZADOR WINDOWS
    echo ============================================================
    echo.
    echo Copiando/atualizando FrameZero em:
    echo   %STABLE_ROOT%
    if not exist "%STABLE_ROOT%" mkdir "%STABLE_ROOT%" >nul 2>nul
    set "TMP_CFG=%TEMP%\framezero_config_backup.json"
    if exist "%STABLE_ROOT%\app\config.json" copy /y "%STABLE_ROOT%\app\config.json" "%TMP_CFG%" >nul 2>nul
    robocopy "%ROOT%" "%STABLE_ROOT%" /E /XD ".framezero" "venv" "logs" "__pycache__" ".pytest_cache" /XF ".DS_Store" >nul
    if errorlevel 8 (
        echo ERRO ao copiar para a pasta fixa.
        pause
        exit /b 1
    )
    if exist "%TMP_CFG%" (
        if not exist "%STABLE_ROOT%\app" mkdir "%STABLE_ROOT%\app"
        copy /y "%TMP_CFG%" "%STABLE_ROOT%\app\config.json" >nul 2>nul
        del "%TMP_CFG%" >nul 2>nul
    )
    cd /d "%STABLE_ROOT%"
    call "%STABLE_ROOT%\INICIAR-FRAMEZERO-WINDOWS.bat"
    exit /b %errorlevel%
)

cd /d "%STABLE_ROOT%"
REM Remove agent oculto de versões antigas; v81t usa CMD visível pelo inicializador.
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\FrameZero Agent.lnk" >nul 2>nul
set "ROOT=%STABLE_ROOT%"
set "APP=%ROOT%\app"
set "VENV=%APP%\venv"
set "REQ_FILE=%APP%\requirements-windows.txt"
if not exist "%REQ_FILE%" set "REQ_FILE=%APP%\requirements.txt"
set "RUNTIME_DIR=%ROOT%\.framezero"
set "REQ_HASH_FILE=%RUNTIME_DIR%\requirements-windows.sha256"
set "LOGDIR=%ROOT%\logs"
set "LOG=%LOGDIR%\framezero-terminal.log"
if not exist "%LOGDIR%" mkdir "%LOGDIR%" >nul 2>nul
if not exist "%RUNTIME_DIR%" mkdir "%RUNTIME_DIR%" >nul 2>nul

cls
echo ============================================================
echo  FRAMEZERO CLIPS v81t - INICIALIZADOR
echo ============================================================
echo.
echo Este inicializador abre o OBS e inicia o servidor FrameZero
echo com o CMD visivel, para acompanhar tudo em tempo real.
echo.
echo Painel OBS/site:
echo %SITE_URL%
echo.
echo Deixe esta janela aberta enquanto estiver usando o FrameZero.
echo.

set "NEED_INSTALL=0"
if not exist "%VENV%\Scripts\python.exe" set "NEED_INSTALL=1"
for /f "usebackq delims=" %%H in (`powershell -NoProfile -Command "if(Test-Path '%REQ_FILE%'){(Get-FileHash -Algorithm SHA256 '%REQ_FILE%').Hash}"`) do set "REQ_HASH=%%H"
set "OLD_HASH="
if exist "%REQ_HASH_FILE%" set /p OLD_HASH=<"%REQ_HASH_FILE%"
if defined REQ_HASH if /I not "%REQ_HASH%"=="%OLD_HASH%" set "NEED_INSTALL=1"

if "%NEED_INSTALL%"=="1" (
    echo Preparando/atualizando ambiente. Isso so deve demorar na primeira instalacao ou quando houver dependencia nova.
    set "FRAMEZERO_AUTO_INSTALL=update"
    call "%ROOT%\installers\INSTALAR-WINDOWS.bat"
    if errorlevel 1 (
        echo.
        echo ERRO na instalacao/atualizacao.
        pause
        exit /b 1
    )
) else (
    echo Ambiente ja instalado. Pulando instalacao de dependencias.
)

echo.
echo Encerrando servidor antigo para mostrar os logs nesta janela...
for %%P in (8765 8766 8889) do (
    for /f "tokens=5" %%A in ('netstat -ano ^| findstr /R /C:":%%P .*LISTENING"') do taskkill /PID %%A /F >nul 2>nul
)

echo Abrindo OBS...
if exist "%ProgramFiles%\obs-studio\bin\64bit\obs64.exe" (
    start "" "%ProgramFiles%\obs-studio\bin\64bit\obs64.exe"
) else if exist "%ProgramFiles(x86)%\obs-studio\bin\64bit\obs64.exe" (
    start "" "%ProgramFiles(x86)%\obs-studio\bin\64bit\obs64.exe"
) else (
    start "" obs64.exe >nul 2>nul
)

echo Abrindo painel no navegador tambem...
start "" "%SITE_URL%"

echo.
echo Iniciando servidor FrameZero...
echo Health: http://127.0.0.1:8766/health
echo WebSocket: ws://127.0.0.1:8765
echo Painel: %SITE_URL%
echo.

cd /d "%APP%"
if exist "%APP%\ffmpeg\bin\ffmpeg.exe" set "PATH=%APP%\ffmpeg\bin;%PATH%"
set "PY=%VENV%\Scripts\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" "%APP%\servidor.py"

echo.
echo FrameZero foi encerrado.
pause
