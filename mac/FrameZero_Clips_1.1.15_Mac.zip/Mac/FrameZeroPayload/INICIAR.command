#!/bin/bash
set +e
ROOT_DIR="$HOME/Library/Application Support/obs-studio/FrameZero"
ORIGINAL="$ROOT_DIR/INICIAR.command.framezero-original-before-autoupdate-fix"
UPDATER="$ROOT_DIR/FrameZero-Update-Check.command"
LOG_DIR="$ROOT_DIR/logs"
mkdir -p "$LOG_DIR"

clear
cat <<'MSG'
============================================================
 FRAMEZERO CLIPS - LAUNCHER COM AUTO-UPDATE GITHUB
============================================================
Este executor consulta o GitHub antes de iniciar o Core.
Se houver versão nova, atualiza e reinicia automaticamente.
Se não houver, abre o FrameZero instalado normalmente.
============================================================
MSG

if [ -f "$UPDATER" ]; then
  bash "$UPDATER"
  CODE=$?
  if [ "$CODE" = "88" ]; then
    echo "Reabrindo FrameZero atualizado..."
    exec "$ROOT_DIR/INICIAR.command"
  fi
fi

if [ -f "$ORIGINAL" ]; then
  echo "Abrindo launcher local atual..."
  exec bash "$ORIGINAL"
else
  echo "ERRO: launcher original não encontrado."
  echo "Esperado: $ORIGINAL"
  read -p "Pressione ENTER para sair..."
  exit 1
fi