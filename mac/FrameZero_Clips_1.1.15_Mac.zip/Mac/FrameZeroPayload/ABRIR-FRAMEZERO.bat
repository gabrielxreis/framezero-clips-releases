@echo off
cd /d "%~dp0"
call "INICIAR-FRAMEZERO-WINDOWS.bat"
