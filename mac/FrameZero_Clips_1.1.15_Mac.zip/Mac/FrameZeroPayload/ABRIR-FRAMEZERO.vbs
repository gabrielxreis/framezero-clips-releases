Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
launcher = root & "\launcher\framezero-launcher.bat"
shell.Run Chr(34) & launcher & Chr(34), 0, False
