#!/bin/bash
cd "$(dirname "$0")"
echo "Desligando FrameZero local..."
PID_FILE=".framezero/framezero.pid"
if [ -f "$PID_FILE" ]; then
  PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [ -n "$PID" ]; then kill "$PID" 2>/dev/null || true; fi
fi
pkill -f "servidor.py" 2>/dev/null || true
for PORTA in 8765 8766 8889; do
  PID=$(lsof -ti tcp:$PORTA 2>/dev/null || true)
  if [ -n "$PID" ]; then kill -9 $PID 2>/dev/null || true; fi
done
echo "FrameZero desligado."
read -p "Pressione ENTER para fechar..."
