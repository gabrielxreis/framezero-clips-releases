#!/bin/bash
set +e
ROOT_DIR="$(cd "$(dirname "$0")" && pwd -P)"

log(){ echo "$@"; }

# OBS Studio obrigatório antes de verificar plugins.
detect_obs_app_mac() {
  if [ -d "/Applications/OBS.app" ]; then echo "/Applications/OBS.app"; return 0; fi
  if [ -d "/Applications/OBS Studio.app" ]; then echo "/Applications/OBS Studio.app"; return 0; fi
  return 1
}
obs_version_mac() {
  local APP="$1"
  [ -n "$APP" ] && [ -f "$APP/Contents/Info.plist" ] && /usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$APP/Contents/Info.plist" 2>/dev/null || true
}
latest_obs_version_mac() {
  curl -fsSL --connect-timeout 25 --retry 2 'https://obsproject.com/download' 2>/dev/null \
    | tr '\n' ' ' \
    | sed -n 's/.*Version:[[:space:]]*\([0-9][0-9.]*\).*/\1/p' \
    | head -n 1
}
latest_obs_dmg_url_mac() {
  local HTML ARCH_RE URL
  HTML="$(curl -fsSL --connect-timeout 30 --retry 2 'https://obsproject.com/download' 2>/dev/null || true)"
  [ -z "$HTML" ] && return 1
  case "$(uname -m)" in arm64|aarch64) ARCH_RE='apple|arm64|silicon' ;; *) ARCH_RE='intel|x86_64' ;; esac
  URL="$(printf '%s' "$HTML" | tr '\"' '\n' | grep -Eio 'https?://[^ ]+\.dmg[^ <]*' | grep -Ei 'obs|OBS' | grep -Ei 'mac|macos' | grep -Ei "$ARCH_RE" | head -n 1)"
  if [ -z "$URL" ]; then
    URL="$(printf '%s' "$HTML" | tr '\"' '\n' | grep -Eio 'https?://[^ ]+\.dmg[^ <]*' | grep -Ei 'obs|OBS' | grep -Ei 'mac|macos' | head -n 1)"
  fi
  [ -n "$URL" ] && echo "$URL"
}

registrar_obs_path_mac() {
  local OBS_APP="$1"
  [ -z "$OBS_APP" ] && OBS_APP="$(detect_obs_app_mac || true)"
  [ -z "$OBS_APP" ] && return 1
  mkdir -p "$ROOT_DIR/.framezero" "$ROOT_DIR/app" 2>/dev/null || true
  echo "$OBS_APP" > "$ROOT_DIR/.framezero/obs_path.txt"
  echo "OBS instalado em: $OBS_APP"
  if command -v python3 >/dev/null 2>&1; then
    python3 - "$ROOT_DIR/app/config.json" "$OBS_APP" <<'PYOBS'
import json, pathlib, sys
p=pathlib.Path(sys.argv[1]); obs=sys.argv[2]
try: cfg=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
except Exception: cfg={}
cfg['obs_app_path']=obs; cfg['obs_bin_path']=obs; cfg['obs_installed']=True
p.parent.mkdir(parents=True, exist_ok=True)
p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding='utf-8')
PYOBS
  fi
}
instalar_ou_atualizar_obs_mac() {
  echo ""
  echo "============================================================"
  echo " VERIFICANDO OBS STUDIO - OBRIGATÓRIO"
  echo "============================================================"
  echo "Fonte oficial: https://obsproject.com/download"
  local OBS_APP CURRENT LATEST NEED_UPDATE DMG URL MOUNT_DIR FOUND_APP
  OBS_APP="$(detect_obs_app_mac || true)"
  CURRENT="$(obs_version_mac "$OBS_APP")"
  LATEST="$(latest_obs_version_mac || true)"
  [ -n "$OBS_APP" ] && echo "OBS encontrado em: $OBS_APP"
  [ -n "$CURRENT" ] && echo "Versão instalada: $CURRENT"
  [ -n "$LATEST" ] && echo "Versão mais recente no site oficial: $LATEST"
  NEED_UPDATE=0
  [ -z "$OBS_APP" ] && NEED_UPDATE=1
  [ -n "$OBS_APP" ] && [ -n "$LATEST" ] && [ -n "$CURRENT" ] && [ "$CURRENT" != "$LATEST" ] && NEED_UPDATE=1
  if [ "$NEED_UPDATE" = "1" ]; then
    DMG="$HOME/Desktop/FrameZero-OBS-Studio.dmg"
    URL="$(latest_obs_dmg_url_mac || true)"
    [ -z "$URL" ] && { echo "ERRO: não consegui localizar o instalador oficial do OBS na página de download."; return 1; }
    echo "Baixando OBS oficial pelo link encontrado em obsproject.com/download: $URL"
    curl -L --fail --retry 3 --connect-timeout 25 --progress-bar -o "$DMG" "$URL" || return 1
    MOUNT_DIR="$(hdiutil attach "$DMG" -nobrowse 2>/dev/null | grep -o '/Volumes/.*' | head -n 1 || true)"
    [ -z "$MOUNT_DIR" ] && return 1
    FOUND_APP="$(find "$MOUNT_DIR" -maxdepth 3 -type d \( -name 'OBS.app' -o -name 'OBS Studio.app' \) 2>/dev/null | head -n 1)"
    [ -z "$FOUND_APP" ] && { hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true; return 1; }
    osascript -e 'tell application "OBS" to quit' >/dev/null 2>&1 || true
    pkill -x OBS >/dev/null 2>&1 || true
    rm -rf "/Applications/OBS.app" "/Applications/OBS Studio.app" 2>/dev/null || sudo rm -rf "/Applications/OBS.app" "/Applications/OBS Studio.app" 2>/dev/null || true
    cp -R "$FOUND_APP" "/Applications/" 2>/dev/null || sudo cp -R "$FOUND_APP" "/Applications/" || { hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true; return 1; }
    hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true
    OBS_APP="$(detect_obs_app_mac || true)"
  fi
  [ -z "$OBS_APP" ] && return 1
  registrar_obs_path_mac "$OBS_APP"
  echo "OK: OBS pronto para o FrameZero."
}

configurar_obs_websocket_mac(){
  local OBS_SUPPORT="$HOME/Library/Application Support/obs-studio"
  local GLOB="$OBS_SUPPORT/global.ini"
  mkdir -p "$OBS_SUPPORT"
  python3 - "$GLOB" <<'PYWS'
from pathlib import Path
import sys, configparser
p=Path(sys.argv[1])
cp=configparser.ConfigParser(strict=False)
cp.optionxform=str
if p.exists(): cp.read(p, encoding='utf-8')
wanted={
    'ServerEnabled':'true',
    'ServerPort':'4455',
    'AlertsEnabled':'false',
    'AuthRequired':'false',
    'FirstLoad':'false'
}
changed=False
if not cp.has_section('OBSWebSocket'):
    cp.add_section('OBSWebSocket'); changed=True
sec=cp['OBSWebSocket']
for k,v in wanted.items():
    if sec.get(k) != v:
        sec[k]=v; changed=True
if changed:
    with p.open('w', encoding='utf-8') as f: cp.write(f, space_around_delimiters=False)
    print('OK: OBS WebSocket configurado automaticamente.')
else:
    print('OK: OBS WebSocket já estava configurado. Nada a alterar.')
PYWS
}

instalar_plugins_obs_mac() {
  echo ""
  echo "============================================================"
  echo " VERIFICAÇÃO OBRIGATÓRIA: OBS + PLUGINS ANTES DO FRAMEZERO"
  echo "============================================================"
  echo "Antes de iniciar o Core, o FrameZero precisa confirmar:"
  echo "- BlackHole 2ch"
  echo "- Aitum Vertical Canvas"
  echo "- Aitum Multistream"
  echo "- OBS Face Tracker"
  echo ""

  instalar_ou_atualizar_obs_mac || { echo "ERRO: OBS Studio é obrigatório antes dos plugins. O Core não será iniciado."; return 1; }
  configurar_obs_websocket_mac || true

  # OBS precisa estar fechado durante a cópia dos plugins, senão ele pode carregar cache antigo.
  osascript -e 'tell application "OBS" to quit' >/dev/null 2>&1 || true
  pkill -x OBS >/dev/null 2>&1 || true
  sleep 1

  TMP_PLUG="$HOME/Desktop/FrameZero-OBS-Plugins"
  mkdir -p "$TMP_PLUG"

  OBS_PLUGIN_DIR_USER="$HOME/Library/Application Support/obs-studio/plugins"
  OBS_DATA_DIR_USER="$HOME/Library/Application Support/obs-studio/data/obs-plugins"
  OBS_PLUGIN_DIR_SYS="/Library/Application Support/obs-studio/plugins"
  OBS_DATA_DIR_SYS="/Library/Application Support/obs-studio/data/obs-plugins"
  OBS_APP_PLUGINS="/Applications/OBS.app/Contents/PlugIns"
  OBS_APP_DATA="/Applications/OBS.app/Contents/Resources/data/obs-plugins"
  mkdir -p "$OBS_PLUGIN_DIR_USER" "$OBS_DATA_DIR_USER" 2>/dev/null || true

  # Evita pedir senha em todo início: antes de qualquer sudo, verifica se tudo já está instalado
  # nas pastas que o OBS realmente carrega. Se estiver OK, não espelha, não reinstala e não pede senha.
  quick_has_blackhole(){
    [ -d "/Library/Audio/Plug-Ins/HAL/BlackHole2ch.driver" ] && return 0
    [ -d "/Library/Audio/Plug-Ins/HAL/BlackHole.driver" ] && return 0
    find "/Library/Audio/Plug-Ins/HAL" -maxdepth 1 -iname "*BlackHole*.driver" 2>/dev/null | grep -qi BlackHole && return 0
    system_profiler SPAudioDataType 2>/dev/null | grep -Eiq "BlackHole[[:space:]]*2ch|BlackHole" && return 0
    return 1
  }
  quick_has_plugin(){
    local CANON="$1"; shift
    local EXTRA="$*"
    local ROOTS=("$OBS_PLUGIN_DIR_USER" "$OBS_PLUGIN_DIR_SYS" "$OBS_APP_PLUGINS")
    local R X
    for R in "${ROOTS[@]}"; do
      [ -d "$R" ] || continue
      [ -d "$R/$CANON.plugin" ] && return 0
      [ -d "$R/$CANON" ] && return 0
      [ -f "$R/$CANON/bin/$CANON.so" ] && return 0
      [ -f "$R/$CANON/bin/$CANON.dylib" ] && return 0
      [ -f "$R/$CANON.so" ] && return 0
      [ -f "$R/$CANON.dylib" ] && return 0
      for X in $EXTRA; do
        [ -d "$R/$X.plugin" ] && return 0
        [ -d "$R/$X" ] && return 0
        [ -f "$R/$X/bin/$X.so" ] && return 0
        [ -f "$R/$X/bin/$X.dylib" ] && return 0
        [ -f "$R/$X.so" ] && return 0
        [ -f "$R/$X.dylib" ] && return 0
      done
    done
    return 1
  }
  if quick_has_blackhole \
     && quick_has_plugin "obs-vertical-canvas" "aitum-vertical-canvas vertical-canvas" \
     && quick_has_plugin "obs-aitum-multistream" "aitum-multistream" \
     && quick_has_plugin "obs-face-tracker" "face-tracker facetracker"; then
    echo "OK: BlackHole 2ch detectado."
    echo "OK: Aitum Vertical Canvas já detectado em pasta OBS válida."
    echo "OK: Aitum Multistream já detectado em pasta OBS válida."
    echo "OK: OBS Face Tracker já detectado em pasta OBS válida."
    echo "Plugins obrigatórios OK. Nenhuma instalação/cópia necessária."
    return 0
  fi

  sudo mkdir -p "$OBS_PLUGIN_DIR_SYS" "$OBS_DATA_DIR_SYS" "$OBS_APP_PLUGINS" "$OBS_APP_DATA" >/dev/null 2>&1 || true

  has_blackhole(){
    [ -d "/Library/Audio/Plug-Ins/HAL/BlackHole2ch.driver" ] && return 0
    [ -d "/Library/Audio/Plug-Ins/HAL/BlackHole.driver" ] && return 0
    find "/Library/Audio/Plug-Ins/HAL" -maxdepth 1 -iname "*BlackHole*.driver" 2>/dev/null | grep -qi BlackHole && return 0
    system_profiler SPAudioDataType 2>/dev/null | grep -Eiq "BlackHole[[:space:]]*2ch|BlackHole" && return 0
    return 1
  }

  has_plugin_exact(){
    local CANON="$1"; shift
    local EXTRA="$*"
    local ROOTS=("$OBS_PLUGIN_DIR_USER" "$OBS_PLUGIN_DIR_SYS" "$OBS_APP_PLUGINS")
    local R
    for R in "${ROOTS[@]}"; do
      [ -d "$R" ] || continue
      [ -d "$R/$CANON.plugin" ] && return 0
      [ -f "$R/$CANON/bin/$CANON.so" ] && return 0
      [ -f "$R/$CANON/bin/$CANON.dylib" ] && return 0
      [ -f "$R/$CANON.so" ] && return 0
      [ -f "$R/$CANON.dylib" ] && return 0
      for X in $EXTRA; do
        [ -d "$R/$X.plugin" ] && return 0
        [ -f "$R/$X/bin/$X.so" ] && return 0
        [ -f "$R/$X.so" ] && return 0
      done
    done
    return 1
  }
  has_aitum_vertical(){ has_plugin_exact "obs-vertical-canvas" "aitum-vertical-canvas vertical-canvas"; }
  has_aitum_multi(){ has_plugin_exact "obs-aitum-multistream" "aitum-multistream"; }
  has_face_tracker(){ has_plugin_exact "obs-face-tracker" "face-tracker facetracker"; }

  ensure_homebrew_mac(){
    export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
    if command -v brew >/dev/null 2>&1; then return 0; fi
    echo "Homebrew não encontrado. Instalando Homebrew oficial para instalar BlackHole..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || true
    [ -x "/opt/homebrew/bin/brew" ] && eval "$(/opt/homebrew/bin/brew shellenv)" 2>/dev/null || true
    [ -x "/usr/local/bin/brew" ] && eval "$(/usr/local/bin/brew shellenv)" 2>/dev/null || true
    command -v brew >/dev/null 2>&1
  }

  instalar_blackhole_obrigatorio(){
    echo "Instalando BlackHole 2ch via Homebrew: brew install --cask blackhole-2ch"
    ensure_homebrew_mac || return 1
    export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
    if ! has_blackhole; then
      if brew list --cask blackhole-2ch >/dev/null 2>&1; then
        brew reinstall --cask blackhole-2ch || true
      else
        brew install --cask blackhole-2ch || brew install blackhole-2ch || return 1
      fi
    fi
    # BlackHole só deve ser considerado pronto quando o driver aparecer no HAL/CoreAudio, não apenas quando o brew listar o cask.
    sudo killall -9 coreaudiod >/dev/null 2>&1 || true
    sleep 8
    if has_blackhole; then return 0; fi
    echo "AVISO: Homebrew instalou BlackHole, mas o macOS pode precisar reiniciar para mostrar o dispositivo de áudio."
    echo "Continuando a instalação do FrameZero. Se o BlackHole não aparecer no OBS, reinicie o Mac uma vez."
    touch "$ROOT_DIR/.blackhole_restart_required" 2>/dev/null || true
    return 0
  }

  fix_permissions_plugin(){
    local TARGET="$1"
    [ -e "$TARGET" ] || return 0
    xattr -dr com.apple.quarantine "$TARGET" >/dev/null 2>&1 || true
    chmod -R a+rX "$TARGET" >/dev/null 2>&1 || true
  }

  copy_dir_contents(){
    local SRC="$1"; local DST="$2"
    [ -d "$SRC" ] || return 1
    mkdir -p "$DST" 2>/dev/null || sudo mkdir -p "$DST" || true
    cp -R "$SRC/"* "$DST/" 2>/dev/null || sudo cp -R "$SRC/"* "$DST/" || return 1
    return 0
  }

  copy_obs_layout_from_dir(){
    local DIR="$1"; local NAME="$2"; local DID=1; local P
    # 1) Bundle .plugin para user e system
    while IFS= read -r -d '' P; do
      echo "Copiando bundle OBS de $NAME: $P"
      rm -rf "$OBS_PLUGIN_DIR_USER/$(basename "$P")" 2>/dev/null || true
      sudo rm -rf "$OBS_PLUGIN_DIR_SYS/$(basename "$P")" >/dev/null 2>&1 || true
      cp -R "$P" "$OBS_PLUGIN_DIR_USER/" 2>/dev/null || true
      sudo cp -R "$P" "$OBS_PLUGIN_DIR_SYS/" >/dev/null 2>&1 || true
      sudo cp -R "$P" "$OBS_APP_PLUGINS/" >/dev/null 2>&1 || true
      fix_permissions_plugin "$OBS_PLUGIN_DIR_USER/$(basename "$P")"
      sudo xattr -dr com.apple.quarantine "$OBS_PLUGIN_DIR_SYS/$(basename "$P")" >/dev/null 2>&1 || true
      sudo chmod -R a+rX "$OBS_PLUGIN_DIR_SYS/$(basename "$P")" >/dev/null 2>&1 || true
      sudo xattr -dr com.apple.quarantine "$OBS_APP_PLUGINS/$(basename "$P")" >/dev/null 2>&1 || true
      sudo chmod -R a+rX "$OBS_APP_PLUGINS/$(basename "$P")" >/dev/null 2>&1 || true
      DID=0
    done < <(find "$DIR" -type d -iname "*.plugin" -print0 2>/dev/null)

    # 2) Layout OBS: obs-plugins/ e data/obs-plugins/
    local OBSPLUG DATAOBS
    OBSPLUG="$(find "$DIR" -type d -path "*/obs-plugins" 2>/dev/null | head -n 1)"
    DATAOBS="$(find "$DIR" -type d -path "*/data/obs-plugins" 2>/dev/null | head -n 1)"
    if [ -n "$OBSPLUG" ]; then
      echo "Copiando pasta obs-plugins de $NAME para user e system"
      copy_dir_contents "$OBSPLUG" "$OBS_PLUGIN_DIR_USER" || true
      sudo mkdir -p "$OBS_PLUGIN_DIR_SYS" >/dev/null 2>&1 || true
      sudo cp -R "$OBSPLUG/"* "$OBS_PLUGIN_DIR_SYS/" >/dev/null 2>&1 || true
      sudo cp -R "$OBSPLUG/"* "$OBS_APP_PLUGINS/" >/dev/null 2>&1 || true
      fix_permissions_plugin "$OBS_PLUGIN_DIR_USER"
      sudo chmod -R a+rX "$OBS_PLUGIN_DIR_SYS" >/dev/null 2>&1 || true
      sudo chmod -R a+rX "$OBS_APP_PLUGINS" >/dev/null 2>&1 || true
      DID=0
    fi
    if [ -n "$DATAOBS" ]; then
      echo "Copiando dados data/obs-plugins de $NAME para user e system"
      copy_dir_contents "$DATAOBS" "$OBS_DATA_DIR_USER" || true
      sudo mkdir -p "$OBS_DATA_DIR_SYS" >/dev/null 2>&1 || true
      sudo cp -R "$DATAOBS/"* "$OBS_DATA_DIR_SYS/" >/dev/null 2>&1 || true
      sudo cp -R "$DATAOBS/"* "$OBS_APP_DATA/" >/dev/null 2>&1 || true
      fix_permissions_plugin "$OBS_DATA_DIR_USER"
      sudo chmod -R a+rX "$OBS_DATA_DIR_SYS" >/dev/null 2>&1 || true
      sudo chmod -R a+rX "$OBS_APP_DATA" >/dev/null 2>&1 || true
      DID=0
    fi
    return $DID
  }


  mirror_obs_plugins_between_real_folders(){
    echo "Espelhando plugins entre pastas reais do OBS no Mac..."
    local SRCBASE DSTBASE ITEM BASE
    for SRCBASE in "$OBS_PLUGIN_DIR_USER" "$OBS_PLUGIN_DIR_SYS" "$OBS_APP_PLUGINS"; do
      [ -d "$SRCBASE" ] || continue
      find "$SRCBASE" -maxdepth 2 \( -iname "*vertical*" -o -iname "*canvas*" -o -iname "*aitum*" -o -iname "*multistream*" -o -iname "*face*tracker*" -o -iname "*facetracker*" \) -print0 2>/dev/null | while IFS= read -r -d '' ITEM; do
        BASE="$(basename "$ITEM")"
        for DSTBASE in "$OBS_PLUGIN_DIR_USER" "$OBS_PLUGIN_DIR_SYS" "$OBS_APP_PLUGINS"; do
          [ "$SRCBASE" = "$DSTBASE" ] && continue
          mkdir -p "$DSTBASE" 2>/dev/null || sudo mkdir -p "$DSTBASE" >/dev/null 2>&1 || true
          rm -rf "$DSTBASE/$BASE" 2>/dev/null || sudo rm -rf "$DSTBASE/$BASE" >/dev/null 2>&1 || true
          cp -R "$ITEM" "$DSTBASE/" 2>/dev/null || sudo cp -R "$ITEM" "$DSTBASE/" >/dev/null 2>&1 || true
          xattr -dr com.apple.quarantine "$DSTBASE/$BASE" >/dev/null 2>&1 || sudo xattr -dr com.apple.quarantine "$DSTBASE/$BASE" >/dev/null 2>&1 || true
          chmod -R a+rX "$DSTBASE/$BASE" >/dev/null 2>&1 || sudo chmod -R a+rX "$DSTBASE/$BASE" >/dev/null 2>&1 || true
        done
      done
    done
    for SRCBASE in "$OBS_DATA_DIR_USER" "$OBS_DATA_DIR_SYS" "$OBS_APP_DATA"; do
      [ -d "$SRCBASE" ] || continue
      find "$SRCBASE" -maxdepth 2 \( -iname "*vertical*" -o -iname "*canvas*" -o -iname "*aitum*" -o -iname "*multistream*" -o -iname "*face*tracker*" -o -iname "*facetracker*" \) -print0 2>/dev/null | while IFS= read -r -d '' ITEM; do
        BASE="$(basename "$ITEM")"
        for DSTBASE in "$OBS_DATA_DIR_USER" "$OBS_DATA_DIR_SYS" "$OBS_APP_DATA"; do
          [ "$SRCBASE" = "$DSTBASE" ] && continue
          mkdir -p "$DSTBASE" 2>/dev/null || sudo mkdir -p "$DSTBASE" >/dev/null 2>&1 || true
          rm -rf "$DSTBASE/$BASE" 2>/dev/null || sudo rm -rf "$DSTBASE/$BASE" >/dev/null 2>&1 || true
          cp -R "$ITEM" "$DSTBASE/" 2>/dev/null || sudo cp -R "$ITEM" "$DSTBASE/" >/dev/null 2>&1 || true
          chmod -R a+rX "$DSTBASE/$BASE" >/dev/null 2>&1 || sudo chmod -R a+rX "$DSTBASE/$BASE" >/dev/null 2>&1 || true
        done
      done
    done
  }

  extract_pkg_payload_and_copy_obs_layout(){
    local PKG="$1"; local NAME="$2"; local EXP="$TMP_PLUG/pkg_expand_${NAME// /_}"; local PAY OUT
    rm -rf "$EXP" 2>/dev/null || true
    mkdir -p "$EXP"
    pkgutil --expand "$PKG" "$EXP/expanded" >/dev/null 2>&1 || return 1
    find "$EXP/expanded" -name Payload -type f -print0 2>/dev/null | while IFS= read -r -d '' PAY; do
      OUT="$EXP/payload_$(basename "$(dirname "$PAY")")"
      mkdir -p "$OUT"
      (cd "$OUT" && cat "$PAY" | gzip -dc 2>/dev/null | cpio -idm >/dev/null 2>&1) || true
      copy_obs_layout_from_dir "$OUT" "$NAME" || true
    done
    mirror_obs_plugins_between_real_folders || true
    return 0
  }

  instalar_pkg_ou_dmg_mac_safe(){
    local SRC="$1"; local NAME="$2"
    [ -z "$SRC" ] && return 1
    [ ! -e "$SRC" ] && return 1
    case "$SRC" in
      *.pkg|*.PKG)
        echo "Instalando pacote $NAME: $SRC"
        sudo installer -pkg "$SRC" -target /
        local RC=$?
        extract_pkg_payload_and_copy_obs_layout "$SRC" "$NAME" || true
        mirror_obs_plugins_between_real_folders || true
        [ "$RC" = "0" ] && return 0
        return 1
        ;;
      *.dmg|*.DMG)
        echo "Montando DMG $NAME: $SRC"
        local MOUNT_DIR
        MOUNT_DIR="$(hdiutil attach "$SRC" -nobrowse -quiet 2>/dev/null | awk '/\/Volumes\//{for(i=3;i<=NF;i++){printf $i (i<NF?" ":"")}; print ""}' | tail -n 1)"
        [ -z "$MOUNT_DIR" ] && return 1
        local PKG
        PKG="$(find "$MOUNT_DIR" -type f -iname "*.pkg" 2>/dev/null | head -n 1)"
        if [ -n "$PKG" ]; then sudo installer -pkg "$PKG" -target /; local RC=$?; extract_pkg_payload_and_copy_obs_layout "$PKG" "$NAME" || true; mirror_obs_plugins_between_real_folders || true; hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true; return $RC; fi
        copy_obs_layout_from_dir "$MOUNT_DIR" "$NAME"
        local RC=$?
        hdiutil detach "$MOUNT_DIR" -quiet 2>/dev/null || true
        return $RC
        ;;
    esac
    return 1
  }

  install_obs_plugin_payload_mac(){
    local SRC="$1"; local NAME="$2"
    [ -z "$SRC" ] && return 1
    [ ! -e "$SRC" ] && return 1
    echo "Processando instalador de $NAME: $SRC"
    case "$SRC" in
      *.pkg|*.PKG|*.dmg|*.DMG)
        instalar_pkg_ou_dmg_mac_safe "$SRC" "$NAME"
        return $?
        ;;
      *.zip|*.ZIP)
        local UNZIP_DIR LOCAL_PKG
        UNZIP_DIR="$TMP_PLUG/unzip_${NAME// /_}"
        rm -rf "$UNZIP_DIR" 2>/dev/null || true
        mkdir -p "$UNZIP_DIR"
        unzip -q "$SRC" -d "$UNZIP_DIR" || return 1
        LOCAL_PKG="$(find "$UNZIP_DIR" -type f \( -iname "*.pkg" -o -iname "*.dmg" \) 2>/dev/null | head -n 1)"
        if [ -n "$LOCAL_PKG" ]; then instalar_pkg_ou_dmg_mac_safe "$LOCAL_PKG" "$NAME" && return 0; fi
        copy_obs_layout_from_dir "$UNZIP_DIR" "$NAME"
        return $?
        ;;
      *.tar.gz|*.tgz|*.TGZ)
        local TAR_DIR="$TMP_PLUG/tar_${NAME// /_}"
        rm -rf "$TAR_DIR" 2>/dev/null || true
        mkdir -p "$TAR_DIR"
        tar -xzf "$SRC" -C "$TAR_DIR" || return 1
        copy_obs_layout_from_dir "$TAR_DIR" "$NAME"
        return $?
        ;;
    esac
    return 1
  }

  escolher_asset_github(){
    local REPOS="$1"; local DESTDIR="$2"; local KIND="$3"
    python3 - "$REPOS" "$DESTDIR" "$KIND" <<'PYGHREL'
import json, re, sys, urllib.request, pathlib
repos=[r.strip() for r in sys.argv[1].split(',') if r.strip()]
destdir=pathlib.Path(sys.argv[2]); kind=sys.argv[3]
headers={'User-Agent':'FrameZeroInstaller','Accept':'application/vnd.github+json'}
valid=re.compile(r'\.(pkg|dmg|zip|tar\.gz|tgz)$', re.I)
mac_words=re.compile(r'(mac|macos|darwin|osx|universal|arm64|aarch64|apple)', re.I)
bad_words=re.compile(r'(windows|win64|win32|linux|ubuntu|debian|fedora|rpm|deb|appimage|flatpak|exe|msi|pdb|debug|source)', re.I)
kind_words={
 'vertical': re.compile(r'(vertical|canvas)', re.I),
 'multi': re.compile(r'(multi|stream)', re.I),
 'face': re.compile(r'(face|tracker)', re.I),
}
for repo in repos:
    candidates=[]
    for api in [f'https://api.github.com/repos/{repo}/releases/latest', f'https://api.github.com/repos/{repo}/releases?per_page=20']:
        try:
            data=json.loads(urllib.request.urlopen(urllib.request.Request(api, headers=headers), timeout=30).read().decode('utf-8','ignore'))
            releases=data if isinstance(data, list) else [data]
            for rel in releases:
                for a in rel.get('assets') or []:
                    name=a.get('name') or ''; url=a.get('browser_download_url') or ''
                    if not url or not valid.search(name): continue
                    if bad_words.search(name): continue
                    score=0
                    if mac_words.search(name): score+=30
                    if kind_words.get(kind) and kind_words[kind].search(name): score+=8
                    if 'universal' in name.lower(): score+=5
                    if 'arm64' in name.lower() or 'aarch64' in name.lower(): score+=4
                    if name.lower().endswith('.pkg'): score+=7
                    elif name.lower().endswith('.dmg'): score+=6
                    elif name.lower().endswith('.zip'): score+=3
                    candidates.append((score,name,url,repo))
        except Exception:
            pass
    if candidates:
        candidates.sort(reverse=True)
        score,name,url,repo=candidates[0]
        safe=re.sub(r'[^A-Za-z0-9._+-]+','_',name)
        print(url+'|'+str(destdir/safe))
        sys.exit(0)
sys.exit(1)
PYGHREL
  }

  baixar_asset_github_multi_mac(){
    local REPOS="$1"; local DESTDIR="$2"; local KIND="$3"
    local LINE URL DEST
    LINE="$(escolher_asset_github "$REPOS" "$DESTDIR" "$KIND")" || return 1
    URL="${LINE%%|*}"; DEST="${LINE#*|}"
    [ -z "$URL" ] && return 1
    echo "Baixando plugin OBS de release pública: $URL" >&2
    curl -L --fail --retry 3 --connect-timeout 30 --progress-bar -o "$DEST" "$URL" >&2 || return 1
    printf "%s\n" "$DEST"
    return 0
  }

  instalar_plugin_obrigatorio(){
    local SLUG="$1"; local NAME="$2"; local REPOS="$3"; local CHECK_FUNC="$4"; local KIND="$5"
    if $CHECK_FUNC; then echo "OK: $NAME já detectado em pasta OBS válida."; return 0; fi
    echo "Instalando $NAME obrigatório..."
    echo "Fonte oficial: $REPOS"
    local LOCAL_PKG DL_FILE
    LOCAL_PKG="$(find "$ROOT_DIR/plugins/$SLUG/macos" -type f \( -iname "*.pkg" -o -iname "*.dmg" -o -iname "*.zip" -o -iname "*.tgz" -o -iname "*.tar.gz" \) 2>/dev/null | head -n 1)"
    if [ -n "$LOCAL_PKG" ]; then install_obs_plugin_payload_mac "$LOCAL_PKG" "$NAME" || true; fi
    if ! $CHECK_FUNC; then
      DL_FILE="$(baixar_asset_github_multi_mac "$REPOS" "$TMP_PLUG" "$KIND")" && [ -f "$DL_FILE" ] && install_obs_plugin_payload_mac "$DL_FILE" "$NAME" || true
    fi
    mirror_obs_plugins_between_real_folders || true
    if $CHECK_FUNC; then
      echo "OK: $NAME instalado/detectado em pasta OBS válida."
      return 0
    fi
    echo "ERRO: $NAME é obrigatório e não foi instalado/detectado em uma pasta que o OBS carrega."
    echo "Repo usado: $REPOS"
    return 1
  }

  local FAILS=0
  if has_blackhole; then echo "OK: BlackHole 2ch detectado."; else instalar_blackhole_obrigatorio || FAILS=$((FAILS+1)); fi
  instalar_plugin_obrigatorio "aitum-vertical" "Aitum Vertical Canvas" "Aitum/obs-vertical-canvas" has_aitum_vertical vertical || FAILS=$((FAILS+1))
  instalar_plugin_obrigatorio "aitum-multistream" "Aitum Multistream" "Aitum/obs-aitum-multistream" has_aitum_multi multi || FAILS=$((FAILS+1))
  instalar_plugin_obrigatorio "face-tracker" "OBS Face Tracker" "norihiro/obs-face-tracker" has_face_tracker face || FAILS=$((FAILS+1))

  mirror_obs_plugins_between_real_folders || true

  if [ "$FAILS" != "0" ]; then
    echo ""
    echo "AVISO: faltam $FAILS componente(s) para detectar agora."
    echo "O FrameZero continuará a instalação; se algum plugin não aparecer no OBS, reinicie o Mac e abra novamente."
    touch "$ROOT_DIR/.obs_plugins_missing" 2>/dev/null || true
    return 0
  fi
  rm -f "$ROOT_DIR/.obs_plugins_missing" 2>/dev/null || true
  echo "Plugins obrigatórios OK. OBS será reaberto para carregar os plugins."
  return 0
}

instalar_plugins_obs_mac
exit $?
