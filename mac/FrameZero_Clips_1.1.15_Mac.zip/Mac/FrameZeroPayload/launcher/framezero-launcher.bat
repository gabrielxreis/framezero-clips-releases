@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
set "LAUNCHER_DIR=%~dp0"
for %%I in ("%LAUNCHER_DIR%..") do set "ROOT=%%~fI"
set "APP=%ROOT%\app"
set "LOGDIR=%ROOT%\logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%" >nul 2>nul
set "LOG=%LOGDIR%\framezero-agent.log"

REM Se o servidor local já estiver ativo, só abre o painel.
powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8766/health' -TimeoutSec 1; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
if "%errorlevel%"=="0" goto ABRIR

cd /d "%APP%"
if exist "%APP%\ffmpeg\bin\ffmpeg.exe" set "PATH=%APP%\ffmpeg\bin;%PATH%"

set "PY="
if exist "%APP%\venv\Scripts\pythonw.exe" set "PY=%APP%\venv\Scripts\pythonw.exe"
if not defined PY if exist "%APP%\venv\Scripts\python.exe" set "PY=%APP%\venv\Scripts\python.exe"
if not defined PY set "PY=pythonw"

REM Inicia o servidor sem janela de CMD quando possível.
start "FrameZero OBS Local" /min "%PY%" "%APP%\servidor.py"

REM Aguarda o /health ficar pronto.
for /L %%A in (1,1,45) do (
  powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8766/health' -TimeoutSec 1; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
  if "!errorlevel!"=="0" goto ABRIR
  timeout /t 1 >nul
)

:ABRIR
start "" "http://127.0.0.1:8766/obs-panel.html"
exit /b 0
