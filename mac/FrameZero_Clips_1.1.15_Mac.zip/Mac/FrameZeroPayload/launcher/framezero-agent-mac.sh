#!/bin/bash
# FrameZero silent agent: starts local backend without opening browser/OBS panel.
set -u
ROOT="$HOME/Library/Application Support/obs-studio/FrameZero"
APP="$ROOT/app"
VENV="$ROOT/.framezero/venv"
LOG="$ROOT/.framezero/framezero-agent.log"
PID="$ROOT/.framezero/framezero.pid"
HEALTH="http://127.0.0.1:8766/health"
mkdir -p "$ROOT/.framezero"
exec >> "$LOG" 2>&1

echo ""
echo "[FrameZero Agent] $(date)"
health_ok(){ /usr/bin/curl -fsS --connect-timeout 1 "$HEALTH" >/dev/null 2>&1; }
if health_ok; then
  echo "Health OK. Nada a fazer."
  exit 0
fi
if [ ! -f "$APP/servidor.py" ]; then
  echo "servidor.py nao encontrado em $APP"
  exit 0
fi
if [ ! -x "$VENV/bin/python" ]; then
  echo "venv nao encontrado. Rode o instalador."
  exit 0
fi
if [ -f "$PID" ]; then
  OLD="$(cat "$PID" 2>/dev/null || true)"
  if [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null; then
    echo "PID vivo mas health offline: $OLD. Encerrando."
    kill "$OLD" 2>/dev/null || true
    sleep 1
  fi
fi
cd "$ROOT" || exit 0
nohup "$VENV/bin/python" "$APP/servidor.py" >> "$LOG" 2>&1 &
echo $! > "$PID"
echo "Servidor iniciado PID $(cat "$PID")"
exit 0
