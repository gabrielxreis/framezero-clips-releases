# v81q - Painel somente pelo site + Agent local

Correção do erro `ERR_UNKNOWN_URL_SCHEME` dentro do OBS.

- O dock do OBS fica sempre em `https://clips.framezeroai.com.br/obs`.
- A página do site não deve mais redirecionar o OBS para `framezero://obs/start`.
- O app local vira apenas um motor/agent em segundo plano em `127.0.0.1`.
- Mac: LaunchAgent inicia o backend local ao login.
- Windows: atalho no Startup inicia o backend local ao login.
- O launcher manual abre o site, não mais o painel local `127.0.0.1/obs-panel.html`.

Para publicar no site, use o arquivo `site/clips-framezero-obs.html` como base e adicione login/senha nele.
