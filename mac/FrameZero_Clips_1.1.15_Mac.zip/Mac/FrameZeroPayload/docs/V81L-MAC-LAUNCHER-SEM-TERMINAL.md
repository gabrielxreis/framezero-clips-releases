# V81L — Mac Launcher sem Terminal

Adicionado `FrameZero Launcher.app` com `CFBundleURLSchemes=framezero`.

Fluxo:

```txt
clips.framezeroai.com.br/obs
→ framezero://obs/start
→ FrameZero Launcher.app
→ inicia app/servidor.py sem Terminal
→ health em http://127.0.0.1:8766/health
→ painel em http://127.0.0.1:8766/obs-panel.html
```

Também foi adicionado `Access-Control-Allow-Private-Network: true` no servidor local para melhorar compatibilidade de site HTTPS público consultando localhost.

A primeira instalação ainda usa `INSTALAR-MAC.command`. Depois disso, o uso normal pode ser pelo site/protocolo ou pelo app.
