# V81K - Launcher sem CMD + status de carregamento

- Adicionado protocolo `framezero://obs/start` para o site `clips.framezeroai.com.br/obs` abrir o app local depois de instalado.
- Adicionado `ABRIR-FRAMEZERO.vbs`, que inicia o servidor sem mostrar janela de CMD.
- Adicionado servidor HTTP local em `http://127.0.0.1:8766/health` e `http://127.0.0.1:8766/obs-panel.html`.
- Adicionada tela de loading no painel enquanto o servidor conecta.
- Adicionado exemplo de página web em `site/clips-framezero-obs.html`.

Observação: navegador não pode executar `.bat` direto. O site chama o protocolo registrado pelo instalador, e o protocolo aciona o launcher local.
