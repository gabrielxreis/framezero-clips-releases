# V81N — Browser Dock automático no OBS

Adicionado suporte para o instalador criar automaticamente um painel no OBS:

- Nome do dock: `FrameZero Clips`
- URL: `https://clips.framezeroai.com.br/obs`

## Como funciona

O instalador executa `tools/configure_obs_dock.py`, que atualiza o arquivo de configuração do OBS:

- Windows: `%APPDATA%\obs-studio\user.ini`
- Mac: `~/Library/Application Support/obs-studio/user.ini`

A chave configurada é:

```ini
[BasicWindow]
ExtraBrowserDocks=[{"title":"FrameZero Clips","url":"https://clips.framezeroai.com.br/obs"}]
```

Também atualiza `global.ini` se ele já existir, para compatibilidade com instalações antigas.

## Observação

Se o OBS estiver aberto durante a instalação, feche e abra novamente para o painel aparecer em:

`Exibir > Docks > FrameZero Clips`
