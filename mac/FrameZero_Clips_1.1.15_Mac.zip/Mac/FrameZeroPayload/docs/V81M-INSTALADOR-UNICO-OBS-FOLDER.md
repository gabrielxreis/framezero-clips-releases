# FrameZero v81m — Instalador único e pasta fixa do OBS

Esta versão instala o FrameZero em uma pasta fixa ligada ao OBS, para o usuário não depender mais da pasta Downloads nem de abrir CMD/Terminal manualmente.

## Windows

Instala em:

```txt
%APPDATA%\obs-studio\FrameZero
```

O instalador registra o protocolo:

```txt
framezero://obs/start
```

O site `clips.framezeroai.com.br/obs` pode chamar esse protocolo. O launcher liga o servidor local oculto e abre o painel quando `/health` responder.

## Mac

Instala em:

```txt
~/Library/Application Support/obs-studio/FrameZero
```

O instalador registra o `FrameZero Launcher.app` com o protocolo:

```txt
framezero://obs/start
```

Depois da instalação, o usuário pode abrir pelo site sem rodar `.command` manualmente.

## Por que não dentro do OBS.app?

Porque atualizar ou reinstalar o OBS pode apagar arquivos dentro do app. A pasta `obs-studio/FrameZero` é mais segura para dados, configurações, venv, chaves, launcher e painel local.
