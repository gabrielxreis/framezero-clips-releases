# v81p - Instaladores únicos

- Windows: instalador único com payload embutido, sem fechar sozinho, log e shortcut com ícone.
- Mac: instalador .app com ícone e abertura mais robusta via Terminal.
