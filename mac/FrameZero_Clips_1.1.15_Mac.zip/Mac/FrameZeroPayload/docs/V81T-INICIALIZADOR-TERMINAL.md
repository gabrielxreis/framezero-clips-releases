# V81T - Inicializador com Terminal/CMD visível

- Mac volta a usar `.command`, sem Installer.app obrigatório.
- Windows usa `.bat` com CMD visível.
- O inicializador copia para a pasta fixa do OBS, atualiza só quando necessário, abre o OBS e inicia o servidor com logs em tempo real.
- O painel do OBS continua no site `https://clips.framezeroai.com.br/obs`, pronto para login/senha.
- O servidor carrega `mlx-whisper` sob demanda para subir mais rápido.
- Sem autostart oculto obrigatório: o usuário inicia pelo inicializador.
