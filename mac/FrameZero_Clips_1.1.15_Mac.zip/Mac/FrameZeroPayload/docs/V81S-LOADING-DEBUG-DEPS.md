# FrameZero v81s — Loading, Debug e Dependências Inteligentes

- Painel do site exibe barra de progresso enquanto o servidor local inicia.
- Se o WebSocket desconectar, o painel mostra popup com opção de reconectar e abrir debug.
- Botão pequeno `debug` abre Terminal/CMD com o log em tempo real do motor local.
- O servidor local grava log persistente em `FrameZero/logs/framezero-agent.log`.
- Instaladores pulam instalação de dependências quando o ambiente já está pronto e o requirements não mudou.
- O painel continua rodando pelo site `https://clips.framezeroai.com.br/obs`.
