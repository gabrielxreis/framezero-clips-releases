#!/bin/bash
set -Ee
trap 'RC=$?; if [ "$RC" -ne 0 ]; then echo ""; echo "[ERRO] Não foi possível iniciar o instalador."; read -r -p "Pressione ENTER para fechar..." _; fi' EXIT
DIR="$(cd "$(dirname "$0")" && pwd -P)"
cd "$DIR/FrameZeroPayload"
chmod +x *.command 2>/dev/null || true
xattr -dr com.apple.quarantine "$DIR/FrameZeroPayload" 2>/dev/null || true
export FRAMEZERO_AUTO_INSTALL="${FRAMEZERO_AUTO_INSTALL:-clean}"
bash ./INSTALAR-MAC.command
