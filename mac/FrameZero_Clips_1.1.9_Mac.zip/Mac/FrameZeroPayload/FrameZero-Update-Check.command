#!/bin/bash
set +e
ROOT_DIR="${ROOT_DIR:-$HOME/Library/Application Support/obs-studio/FrameZero}"
STABLE_DIR="$HOME/Library/Application Support/obs-studio/FrameZero"
REPO_RAW="https://raw.githubusercontent.com/gabrielxreis/framezero-clips-releases/main"
VERSION_URLS=(
  "$REPO_RAW/latest/version.json"
  "$REPO_RAW/version.json"
)
LOCAL_FILE="$STABLE_DIR/framezero_local_version.json"
TMP_BASE="/tmp/framezero-auto-update-$$"
mkdir -p "$TMP_BASE"
cleanup(){ rm -rf "$TMP_BASE" 2>/dev/null || true; }
trap cleanup EXIT

read_json_key(){
  local file="$1" key="$2"
  /usr/bin/python3 - "$file" "$key" <<'PYJSONKEY' 2>/dev/null
import json,sys
p,k=sys.argv[1],sys.argv[2]
try:
    d=json.load(open(p,encoding='utf-8'))
    v=d.get(k,"")
    print(v if not isinstance(v,(dict,list)) else json.dumps(v, ensure_ascii=False))
except Exception:
    print("")
PYJSONKEY
}

ver_gt(){
  /usr/bin/python3 - "$1" "$2" <<'PYVER'
import re,sys
def parts(v):
    return [int(x) for x in re.findall(r'\d+', v or '0')[:4]]
a=parts(sys.argv[1]); b=parts(sys.argv[2])
while len(a)<4: a.append(0)
while len(b)<4: b.append(0)
sys.exit(0 if a>b else 1)
PYVER
}

fetch_version_json(){
  local out="$1"
  local ts="$(date +%s)"
  for url in "${VERSION_URLS[@]}"; do
    echo "Consultando GitHub: $url"
    if curl -fsSL --connect-timeout 10 --retry 2 -H "Cache-Control: no-cache" -H "Pragma: no-cache" "$url?ts=$ts" -o "$out"; then
      if /usr/bin/python3 - "$out" <<'PYOK' >/dev/null 2>&1
import json,sys
json.load(open(sys.argv[1], encoding='utf-8'))
PYOK
      then
        echo "OK: version.json baixado do GitHub."
        return 0
      fi
    fi
  done
  return 1
}

local_installer_version(){
  local v=""
  if [ -f "$LOCAL_FILE" ]; then
    v="$(read_json_key "$LOCAL_FILE" installer_version)"
    [ -n "$v" ] || v="$(read_json_key "$LOCAL_FILE" installer_ui_version)"
    [ -n "$v" ] || v="$(read_json_key "$LOCAL_FILE" online_installer_version)"
  fi
  if [ -z "$v" ] && [ -f "$STABLE_DIR/latest/version.json" ]; then
    v="$(read_json_key "$STABLE_DIR/latest/version.json" installer_version)"
    [ -n "$v" ] || v="$(read_json_key "$STABLE_DIR/latest/version.json" online_installer_version)"
  fi
  if [ -z "$v" ] && [ -f "$STABLE_DIR/version.json" ]; then
    v="$(read_json_key "$STABLE_DIR/version.json" installer_version)"
    [ -n "$v" ] || v="$(read_json_key "$STABLE_DIR/version.json" online_installer_version)"
  fi
  if [ -z "$v" ] && [ -f "$STABLE_DIR/APP_VERSION.txt" ]; then
    v="$(cat "$STABLE_DIR/APP_VERSION.txt" | tr -dc '0-9.' | head -c 20)"
  fi
  [ -n "$v" ] || v="0.0.0"
  echo "$v"
}

write_local_version(){
  local remote_json="$1"
  /usr/bin/python3 - "$LOCAL_FILE" "$remote_json" <<'PYWRITELOCAL' 2>/dev/null || true
import json,sys,pathlib,datetime
out=pathlib.Path(sys.argv[1])
remote=json.load(open(sys.argv[2],encoding='utf-8'))
installer=remote.get('installer_version') or remote.get('installer_ui_version') or remote.get('online_installer_version') or ''
data={
 'app':'FrameZero Clips',
 'version': remote.get('latest_version') or remote.get('version') or remote.get('clips_version') or '1.1.9',
 'clips_version': remote.get('clips_version') or remote.get('latest_version') or '1.1.9',
 'installer_version': installer,
 'installer_ui_version': installer,
 'online_installer_version': installer,
 'build': remote.get('build') or remote.get('release_name') or '',
 'updated_from_github': True,
 'updated_at': datetime.datetime.utcnow().isoformat()+'Z'
}
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
PYWRITELOCAL
}

echo "============================================================"
echo " VERIFICANDO ATUALIZAÇÃO DO FRAMEZERO NO GITHUB"
echo "============================================================"
REMOTE_JSON="$TMP_BASE/version.json"
if ! fetch_version_json "$REMOTE_JSON"; then
  echo "AVISO: não consegui consultar atualização no GitHub agora. Continuando com a versão local."
  exit 0
fi

LOCAL_INSTALLER="$(local_installer_version)"
REMOTE_INSTALLER="$(read_json_key "$REMOTE_JSON" installer_version)"
[ -n "$REMOTE_INSTALLER" ] || REMOTE_INSTALLER="$(read_json_key "$REMOTE_JSON" installer_ui_version)"
[ -n "$REMOTE_INSTALLER" ] || REMOTE_INSTALLER="$(read_json_key "$REMOTE_JSON" online_installer_version)"
MAC_URL="$(read_json_key "$REMOTE_JSON" mac_url)"
[ -n "$MAC_URL" ] || MAC_URL="$(read_json_key "$REMOTE_JSON" mac_package_url)"
[ -n "$MAC_URL" ] || MAC_URL="$REPO_RAW/mac/FrameZero_Clips_1.1.9_Mac.zip"

# Troca github.com/.../raw/main para raw.githubusercontent se vier assim.
MAC_URL="${MAC_URL/github.com\/gabrielxreis\/framezero-clips-releases\/raw\/main/raw.githubusercontent.com\/gabrielxreis\/framezero-clips-releases\/main}"

echo "Versão local do instalador/Core: $LOCAL_INSTALLER"
echo "Versão disponível no GitHub: $REMOTE_INSTALLER"
echo "Pacote Mac: $MAC_URL"

if [ -z "$REMOTE_INSTALLER" ]; then
  echo "AVISO: version.json não trouxe installer_version. Continuando."
  exit 0
fi

if ! ver_gt "$REMOTE_INSTALLER" "$LOCAL_INSTALLER"; then
  echo "FrameZero já está atualizado."
  if [ ! -f "$LOCAL_FILE" ]; then write_local_version "$REMOTE_JSON"; fi
  exit 0
fi

echo "Atualização encontrada no GitHub. Baixando pacote Mac..."
PKG="$TMP_BASE/FrameZero_Clips_Mac.zip"
if ! curl -fL --progress-bar --retry 2 -H "Cache-Control: no-cache" "$MAC_URL?ts=$(date +%s)" -o "$PKG"; then
  echo "ERRO: não consegui baixar atualização do FrameZero. Continuando com versão local."
  exit 0
fi
if [ ! -s "$PKG" ]; then
  echo "ERRO: pacote baixado vazio. Continuando com versão local."
  exit 0
fi
EXTRACT="$TMP_BASE/extract"
mkdir -p "$EXTRACT"
if ! unzip -q "$PKG" -d "$EXTRACT"; then
  echo "ERRO: não consegui extrair atualização. Continuando com versão local."
  exit 0
fi
SRC_FILE="$(find "$EXTRACT" -type f -name INICIAR.command -print -quit)"
if [ -z "$SRC_FILE" ]; then
  echo "ERRO: pacote de atualização inválido: INICIAR.command não encontrado."
  exit 0
fi
SRC="$(dirname "$SRC_FILE")"

echo "Aplicando atualização em: $STABLE_DIR"
mkdir -p "$STABLE_DIR"
TMP_CONFIG=""
if [ -f "$STABLE_DIR/app/config.json" ]; then
  TMP_CONFIG="$TMP_BASE/config.json"
  cp "$STABLE_DIR/app/config.json" "$TMP_CONFIG" 2>/dev/null || true
fi

if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete \
    --exclude '.framezero/' \
    --exclude 'app/config.json' \
    --exclude 'logs/' \
    --exclude '__pycache__/' \
    --exclude '.DS_Store' \
    "$SRC/" "$STABLE_DIR/"
else
  ditto "$SRC" "$STABLE_DIR"
fi

if [ -n "$TMP_CONFIG" ] && [ -f "$TMP_CONFIG" ]; then
  mkdir -p "$STABLE_DIR/app"
  cp "$TMP_CONFIG" "$STABLE_DIR/app/config.json" 2>/dev/null || true
fi
chmod +x "$STABLE_DIR"/*.command 2>/dev/null || true
xattr -dr com.apple.quarantine "$STABLE_DIR" 2>/dev/null || true
write_local_version "$REMOTE_JSON"

echo "Atualização aplicada para v$REMOTE_INSTALLER. Reiniciando launcher atualizado..."
exit 88