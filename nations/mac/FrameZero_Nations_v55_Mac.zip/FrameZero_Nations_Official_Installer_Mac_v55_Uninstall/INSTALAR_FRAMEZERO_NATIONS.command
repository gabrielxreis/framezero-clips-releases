#!/bin/bash
set -u
clear
echo "============================================================"
echo "                  FRAMEZERO NATIONS"
echo " Feito por Gabriel Reis | @gabrielxreis_ | @framezeroai"
echo "============================================================"
echo "Tradução simultânea para igrejas com IA

              Feito por Gabriel Reis

             Instagram: @gabrielxreis_
              Instagram: @framezeroai

        © 2026 FrameZero AI. Todos os direitos reservados.
============================================================

Instala/atualiza o FrameZero Nations completo:"
echo "- Core Nations v55"
echo "- Provider runtime fix"
echo "- ElevenLabs/Piper/local"
echo "- Tradução antes do TTS"
echo "- Gerenciador de idiomas TTS"
echo "- Idiomas com fila/status/retry pelo Core; não pula definitivamente se falhar"
echo "============================================================"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD_SERVER="$SCRIPT_DIR/payload/servidor.py"
CATALOG="$SCRIPT_DIR/payload/voices_catalog.json"

if [ ! -f "$PAYLOAD_SERVER" ]; then
  echo "❌ servidor.py do payload não encontrado: $PAYLOAD_SERVER"
  read -p "ENTER para sair..." _
  exit 1
fi

python3 -m py_compile "$PAYLOAD_SERVER" >/tmp/fz_v55_compile.log 2>&1
if [ $? -ne 0 ]; then
  echo "❌ servidor.py v55 interno inválido."
  cat /tmp/fz_v55_compile.log
  read -p "ENTER para sair..." _
  exit 1
fi

echo "✅ servidor.py v55 interno validado."

if ! command -v ffmpeg >/dev/null 2>&1; then
  if [ -x /opt/homebrew/bin/ffmpeg ]; then export PATH="/opt/homebrew/bin:$PATH"; fi
  if [ -x /usr/local/bin/ffmpeg ]; then export PATH="/usr/local/bin:$PATH"; fi
fi

if command -v ffmpeg >/dev/null 2>&1; then
  echo "✔ ffmpeg: $(command -v ffmpeg)"
else
  echo "⚠ ffmpeg não encontrado. Instale com: brew install ffmpeg"
fi

find_targets() {
  TARGETS_FILE="/tmp/fz_nations_targets_v55.txt"
  : > "$TARGETS_FILE"
  STABLE="$HOME/Library/Application Support/obs-studio/FrameZero/app/servidor.py"
  if [ -f "$STABLE" ]; then
    echo "$STABLE" >> "$TARGETS_FILE"
  fi
  # Nunca atualizar payloads temporários do instalador por padrão.
  # Isso evitava o painel detectar versões antigas em /tmp/framezero-installer-*.
  if [ "${FRAMEZERO_INCLUDE_TMP_TARGETS:-0}" = "1" ]; then
    for run in /tmp/framezero-run-*.command; do
      [ -f "$run" ] || continue
      dir=$(grep -E '^cd ' "$run" | tail -1 | sed 's/^cd "//; s/"$//')
      case "$dir" in
        /tmp/*|/private/tmp/*) : ;;
        *) if [ -n "$dir" ] && [ -f "$dir/app/servidor.py" ]; then echo "$dir/app/servidor.py" >> "$TARGETS_FILE"; fi ;;
      esac
    done
  fi
  awk '!seen[$0]++' "$TARGETS_FILE" > "$TARGETS_FILE.uniq" && mv "$TARGETS_FILE.uniq" "$TARGETS_FILE"
}

install_core() {
  find_targets
  COUNT=$(wc -l < "$TARGETS_FILE" | tr -d ' ')
  if [ "$COUNT" = "0" ]; then
    echo "❌ Não encontrei servidor.py do FrameZero. Abra o FrameZero Clips e rode de novo."
    return 1
  fi
  echo ""
  echo "Servidores que serão atualizados:"
  sed 's/^/ - /' "$TARGETS_FILE"
  echo ""
  OK=0; FAIL=0
  while IFS= read -r TARGET; do
    [ -f "$TARGET" ] || continue
    echo ""
    echo "────────────────────────────────────────"
    echo "Atualizando: $TARGET"
    DIR=$(dirname "$TARGET")
    ROOT=$(cd "$DIR/.." && pwd)
    BKDIR="$DIR/backups_nations"
    mkdir -p "$BKDIR"
    TS=$(date +%Y%m%d-%H%M%S)
    BACKUP="$BKDIR/servidor.py.before-nations-v55-$TS.bak"
    cp "$TARGET" "$BACKUP"
    TMP="$BKDIR/servidor.py.v55-candidate-$TS.py"
    cp "$PAYLOAD_SERVER" "$TMP"
    python3 -m py_compile "$TMP" >/tmp/fz_v55_target_compile.log 2>&1
    if [ $? -ne 0 ]; then
      echo "❌ v55 inválido para este alvo"
      cat /tmp/fz_v55_target_compile.log
      FAIL=$((FAIL+1)); continue
    fi
    cp "$TMP" "$TARGET"
    NDIR="$ROOT/nations"
    mkdir -p "$NDIR/voices" "$NDIR/models" "$NDIR/cache" "$NDIR/logs" "$NDIR/downloads"
    if [ -f "$CATALOG" ]; then cp "$CATALOG" "$NDIR/voices_catalog.json" 2>/dev/null || true; fi
    update_config "$NDIR/nations_config.json"
    echo "✔ Instalado v55: $TARGET"
    echo "  Backup: $BACKUP"
    OK=$((OK+1))
  done < "$TARGETS_FILE"
  echo ""
  echo "Core concluído. Sucesso: $OK | Falhas: $FAIL"
}

update_config() {
  CFG="$1"
  python3 - "$CFG" <<'PYCFG'
import json, sys, pathlib
path=pathlib.Path(sys.argv[1])
ALL=["pt-BR","pt-PT","en-US","es-ES","fr-FR","de-DE","it-IT","nl-NL","pl-PL","ru-RU","uk-UA","ar-SA","zh-CN","hi-IN","ja-JP","ko-KR","id-ID","vi-VN","tl-PH","sw-KE"]
try:
    cfg=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
except Exception:
    cfg={}
cfg.setdefault("source_language","pt-BR")
cfg.setdefault("active_languages",["en-US"])
cfg["available_languages"]=ALL
cfg["voice_languages"]=ALL
cfg["language_manager"]="v55"
cfg["official_installer"]="v55"
cfg["enabled"]=True
cfg["nations_enabled"]=True
cfg["nations_active"]=True
cfg["active"]=True
cfg.setdefault("voice_engine","piper")
cfg.setdefault("voice_profile","intelligent")
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
PYCFG
}

download_voice_one() {
  NDIR="$1"
  CODE="$2"
  python3 - "$CATALOG" "$CODE" "$NDIR" <<'PYGET'
import json, sys, pathlib, subprocess, os
catalog=pathlib.Path(sys.argv[1])
code=sys.argv[2]
ndir=pathlib.Path(sys.argv[3])
data=json.loads(catalog.read_text(encoding='utf-8'))
item=data.get(code)
if not item:
    print(f"⚠ {code}: não existe no catálogo")
    sys.exit(0)
base="https://huggingface.co/rhasspy/piper-voices/resolve/main"
stem=item["url_path"]
voice=item["voice"]
dest=ndir/"voices"/code
dest.mkdir(parents=True, exist_ok=True)
onnx=dest/(voice+".onnx")
js=dest/(voice+".onnx.json")
urls=[(f"{base}/{stem}.onnx", onnx), (f"{base}/{stem}.onnx.json", js)]
ok=True
for url, path in urls:
    if path.exists() and path.stat().st_size>1000:
        continue
    print(f"  ⬇ {code}: {path.name}")
    cmd=["curl","-L","--fail","--connect-timeout","12","--max-time","180","--retry","1","-o",str(path),url]
    r=subprocess.run(cmd)
    if r.returncode!=0 or (not path.exists()) or path.stat().st_size<1000:
        try: path.unlink()
        except Exception: pass
        ok=False
        break
if ok:
    print(f"  ✔ {code} instalado")
else:
    print(f"  ⚠ {code} falhou, pulando")
PYGET
}

refresh_installed_languages() {
  NDIR="$1"
  python3 - "$NDIR/nations_config.json" "$NDIR/voices" <<'PYREF'
import json, sys, pathlib
cfgp=pathlib.Path(sys.argv[1]); voices=pathlib.Path(sys.argv[2])
ALL=["pt-BR","pt-PT","en-US","es-ES","fr-FR","de-DE","it-IT","nl-NL","pl-PL","ru-RU","uk-UA","ar-SA","zh-CN","hi-IN","ja-JP","ko-KR","id-ID","vi-VN","tl-PH","sw-KE"]
try: cfg=json.loads(cfgp.read_text(encoding='utf-8')) if cfgp.exists() else {}
except Exception: cfg={}
installed=[]
for code in ALL:
    d=voices/code
    if d.exists() and any(p.suffix==".onnx" and p.stat().st_size>1000 for p in d.glob("*.onnx")):
        installed.append(code)
cfg["installed_languages"]=installed
cfg["voice_languages"]=installed
cfg["available_languages"]=ALL
cfgp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
print("✔ Idiomas instalados no Core:", ", ".join(installed) if installed else "nenhum")
PYREF
}

download_all_languages_for_roots() {
  find_targets
  COUNT=$(wc -l < "$TARGETS_FILE" | tr -d ' ')
  if [ "$COUNT" = "0" ]; then
    echo "❌ Não encontrei FrameZero. Abra o FrameZero Clips e rode de novo."
    return 1
  fi
  ROOTS_FILE="/tmp/fz_nations_roots_v55.txt"
  : > "$ROOTS_FILE"
  while IFS= read -r TARGET; do
    [ -f "$TARGET" ] || continue
    DIR=$(dirname "$TARGET")
    ROOT=$(cd "$DIR/.." && pwd)
    echo "$ROOT" >> "$ROOTS_FILE"
  done < "$TARGETS_FILE"
  awk '!seen[$0]++' "$ROOTS_FILE" > "$ROOTS_FILE.uniq" && mv "$ROOTS_FILE.uniq" "$ROOTS_FILE"

  LANGS="pt-BR pt-PT en-US es-ES fr-FR de-DE it-IT nl-NL pl-PL ru-RU uk-UA ar-SA zh-CN hi-IN ja-JP ko-KR id-ID vi-VN tl-PH sw-KE"
  while IFS= read -r ROOT; do
    NDIR="$ROOT/nations"
    mkdir -p "$NDIR/voices" "$NDIR/logs" "$NDIR/downloads"
    echo ""
    echo "============================================================"
    echo "Baixando idiomas para:"
    echo "$NDIR"
    echo "Modo Core: se um idioma falhar, fica pendente e será tentado novamente pelo Core."
    echo "============================================================"
    for CODE in $LANGS; do
      download_voice_one "$NDIR" "$CODE" || true
    done
    refresh_installed_languages "$NDIR"
  done < "$ROOTS_FILE"
}

download_selected_language() {
  find_targets
  COUNT=$(wc -l < "$TARGETS_FILE" | tr -d ' ')
  if [ "$COUNT" = "0" ]; then
    echo "❌ Não encontrei FrameZero."
    return 1
  fi
  echo ""
  echo "Digite o código do idioma, exemplo: en-US, es-ES, fr-FR, ja-JP"
  read -p "Idioma: " CODE
  [ -n "$CODE" ] || return 0
  ROOTS_FILE="/tmp/fz_nations_roots_v55.txt"
  : > "$ROOTS_FILE"
  while IFS= read -r TARGET; do
    [ -f "$TARGET" ] || continue
    DIR=$(dirname "$TARGET")
    ROOT=$(cd "$DIR/.." && pwd)
    echo "$ROOT" >> "$ROOTS_FILE"
  done < "$TARGETS_FILE"
  awk '!seen[$0]++' "$ROOTS_FILE" > "$ROOTS_FILE.uniq" && mv "$ROOTS_FILE.uniq" "$ROOTS_FILE"
  while IFS= read -r ROOT; do
    NDIR="$ROOT/nations"
    mkdir -p "$NDIR/voices"
    download_voice_one "$NDIR" "$CODE" || true
    refresh_installed_languages "$NDIR"
  done < "$ROOTS_FILE"
}

show_status() {
  find_targets
  while IFS= read -r TARGET; do
    [ -f "$TARGET" ] || continue
    ROOT=$(cd "$(dirname "$TARGET")/.." && pwd)
    CFG="$ROOT/nations/nations_config.json"
    echo ""
    echo "FrameZero: $ROOT"
    if [ -f "$CFG" ]; then
      python3 - "$CFG" <<'PYST'
import json, sys
cfg=json.load(open(sys.argv[1], encoding='utf-8'))
print("Core:", cfg.get("official_installer") or cfg.get("language_manager"))
print("Ativos:", cfg.get("active_languages"))
print("Instalados:", cfg.get("installed_languages"))
print("Disponíveis:", len(cfg.get("available_languages") or []))
PYST
    else
      echo "Sem config Nations."
    fi
  done < "$TARGETS_FILE"
}


uninstall_nations_only() {
  clear
  echo "============================================================"
  echo "                  FRAMEZERO NATIONS"
  echo "        DESINSTALAR SOMENTE FRAMEZERO NATIONS"
  echo ""
  echo "              Feito por Gabriel Reis"
  echo "             Instagram: @gabrielxreis_"
  echo "              Instagram: @framezeroai"
  echo "============================================================"
  echo ""
  echo "Esta opção remove somente o Nations."
  echo ""
  echo "Ela NÃO remove:"
  echo "- FrameZero Clips"
  echo "- OBS Studio"
  echo "- seus cortes"
  echo "- suas gravações"
  echo "- suas configurações principais do OBS"
  echo ""
  echo "Ela tenta restaurar o último backup do servidor.py antes do Nations."
  echo "Se não encontrar backup, apenas remove a pasta nations e mantém o Core atual."
  echo "============================================================"
  read -p "Tem certeza que deseja desinstalar somente o Nations? (s/n): " CONFIRM
  if [ "$CONFIRM" != "s" ] && [ "$CONFIRM" != "S" ]; then
    echo "Cancelado."
    return 0
  fi

  find_targets
  COUNT=$(wc -l < "$TARGETS_FILE" | tr -d ' ')
  if [ "$COUNT" = "0" ]; then
    echo "❌ Não encontrei FrameZero."
    return 1
  fi

  OK=0; FAIL=0
  while IFS= read -r TARGET; do
    [ -f "$TARGET" ] || continue
    echo ""
    echo "────────────────────────────────────────"
    echo "Removendo Nations de: $TARGET"
    DIR=$(dirname "$TARGET")
    ROOT=$(cd "$DIR/.." && pwd)
    BKDIR="$DIR/backups_nations"

    RESTORED=0
    if [ -d "$BKDIR" ]; then
      LAST_BACKUP=$(ls -t "$BKDIR"/servidor.py.before-nations-*.bak 2>/dev/null | head -1 || true)
      if [ -n "$LAST_BACKUP" ] && [ -f "$LAST_BACKUP" ]; then
        TMP="$BKDIR/servidor.py.restore-test-$(date +%Y%m%d-%H%M%S).py"
        cp "$LAST_BACKUP" "$TMP"
        python3 -m py_compile "$TMP" >/tmp/fz_uninstall_restore_compile.log 2>&1
        if [ $? -eq 0 ]; then
          cp "$LAST_BACKUP" "$TARGET"
          RESTORED=1
          echo "✓ servidor.py restaurado do backup:"
          echo "  $LAST_BACKUP"
        else
          echo "⚠ Backup encontrado, mas inválido. Mantendo servidor.py atual."
          cat /tmp/fz_uninstall_restore_compile.log
        fi
        rm -f "$TMP" 2>/dev/null || true
      fi
    fi

    if [ "$RESTORED" = "0" ]; then
      echo "⚠ Nenhum backup válido encontrado para restaurar."
      echo "  servidor.py atual foi mantido."
    fi

    if [ -d "$ROOT/nations" ]; then
      TS=$(date +%Y%m%d-%H%M%S)
      ARCHIVE="$ROOT/nations.uninstalled-$TS"
      mv "$ROOT/nations" "$ARCHIVE"
      echo "✓ Pasta Nations removida/arquivada em:"
      echo "  $ARCHIVE"
    else
      echo "ℹ Pasta Nations não encontrada."
    fi

    OK=$((OK+1))
  done < "$TARGETS_FILE"

  echo ""
  echo "============================================================"
  echo "Desinstalação do Nations concluída."
  echo ""
  echo "FrameZero Clips e OBS foram preservados."
  echo ""
  echo "Instagram:"
  echo "@gabrielxreis_"
  echo "@framezeroai"
  echo "============================================================"
  echo "Sucesso: $OK | Falhas: $FAIL"
}

if [ "${FRAMEZERO_NATIONS_CORE_ONLY:-}" = "1" ]; then
  echo ""
  echo "Instalando FrameZero Nations Core automaticamente..."
  install_core
  echo "FrameZero Nations Core instalado."
  exit 0
fi

if [ "${FRAMEZERO_NATIONS_LANGS_ONLY:-}" = "1" ]; then
  echo ""
  echo "Baixando idiomas do Nations em segundo plano..."
  export FRAMEZERO_IGNORE_TMP_TARGETS=1
  download_all_languages_for_roots || true
  echo "Idiomas do Nations processados."
  exit 0
fi

if [ "${FRAMEZERO_NATIONS_AUTO_INSTALL:-}" = "1" ]; then
  echo ""
  echo "Instalando FrameZero Nations automaticamente..."
  install_core
  echo ""
  echo "Baixando todos os idiomas do Nations automaticamente..."
  download_all_languages_for_roots || true
  echo "FrameZero Nations instalado com idiomas."
  exit 0
fi

while true; do
  echo ""
  echo "1) Instalar/Atualizar FrameZero Nations v55"
  echo "2) Baixar TODOS os idiomas TTS (pula erro e continua)"
  echo "3) Baixar UM idioma específico"
  echo "4) Ver status"
  echo "5) Desinstalar somente o Nations"
  echo "6) Sair"
  read -p "Escolha uma opção: " OP
  case "$OP" in
    1) install_core ;;
    2) download_all_languages_for_roots ;;
    3) download_selected_language ;;
    4) show_status ;;
    5) uninstall_nations_only ;;
    6) exit 0 ;;
    *) echo "Opção inválida." ;;
  esac
done
