FrameZero Nations Official Installer Mac v55

Instalador oficial com:
- @gabrielxreis_
- @framezeroai
- Instalar/atualizar Nations
- Baixar todos os idiomas
- Baixar idioma específico
- Ver status
- Desinstalar somente o Nations, preservando FrameZero Clips e OBS
