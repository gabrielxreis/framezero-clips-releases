#!/bin/bash
cd "$(dirname "$0")"
PY="./.framezero/venv/bin/python"
if [ ! -x "$PY" ]; then
  PY="python3"
fi
exec "$PY" "app/framezero_timeline_exporter.py" "$@"
