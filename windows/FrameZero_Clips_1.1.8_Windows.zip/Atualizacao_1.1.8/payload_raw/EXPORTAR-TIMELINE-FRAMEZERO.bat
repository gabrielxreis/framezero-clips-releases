@echo off
cd /d "%~dp0"
if exist ".framezero\venv\Scripts\python.exe" (
  ".framezero\venv\Scripts\python.exe" "app\framezero_timeline_exporter.py" %*
) else (
  python "app\framezero_timeline_exporter.py" %*
)
pause
