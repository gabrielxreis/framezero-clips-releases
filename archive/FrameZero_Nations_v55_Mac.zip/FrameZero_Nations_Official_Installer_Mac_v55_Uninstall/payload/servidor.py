"""
FrameZero Clips 1.1 - Global Language Rules + Cortes integrado ao OBS.

Recursos:
  1. Transcreve em PT-BR usando MLX Whisper local ou VPS.
  2. Timestamp zera quando o OBS comeca a gravar/transmitir.
  3. Deteccao de cortes:
       - SEM chave OpenAI: modo automatico local com cunho viral/emocional
         (historia, pico de voz, tensao, virada, frase de impacto e CTA).
       - COM chave OpenAI: opcional; o GPT melhora titulo/razao dos cortes.
  4. Clipe durante a live via Replay Buffer do OBS:
       - automatico quando o detector local/IA aponta um momento forte (acima do limiar)
       - manual pelo botao no painel
     O OBS salva um arquivo so daquele trecho, na hora.
  5. Botao no painel pra colar/salvar a chave da OpenAI (guardada em config.json).

A transcricao agora usa MLX MLX Whisper local no Mac Apple Silicon.
Sem VPS, sem FunASR, sem SenseVoice e sem /transcribe.
"""

import asyncio
import json
import os
import uuid
import re
import time
import shutil
import gc
import threading
import queue
import io
import wave
import tempfile
import platform
import base64
import subprocess
import uuid
from pathlib import Path

import numpy as np

# Fix: no Windows ARM64, sounddevice procura libportaudioarm64.dll mas o pacote
# instala com nome libportaudio64bit.dll. Copia antes de importar.
try:
    import importlib.util, shutil as _shutil
    _sd_spec = importlib.util.find_spec("_sounddevice_data")
    if _sd_spec:
        _pb = Path(_sd_spec.submodule_search_locations[0]) / "portaudio-binaries"
        _arm = _pb / "libportaudioarm64.dll"
        _x64 = _pb / "libportaudio64bit.dll"
        if not _arm.exists() and _x64.exists():
            _shutil.copy2(_x64, _arm)
except Exception:
    pass

try:
    import sounddevice as sd
    SOUNDDEVICE_OK = True
    SOUNDDEVICE_ERROR = ""
except Exception as e:
    sd = None
    SOUNDDEVICE_OK = False
    SOUNDDEVICE_ERROR = str(e)
    print(f"[audio] sounddevice/PortAudio indisponivel: {e}")
    print("[audio] O servidor vai continuar sem captura direta do dispositivo. Use o plugin/audio via OBS ou instale/repare o driver de audio se precisar.")
try:
    import mlx_whisper
    TEM_MLX = True
except Exception:
    mlx_whisper = None
    TEM_MLX = False
try:
    from faster_whisper import WhisperModel
    TEM_FASTER_WHISPER = True
except Exception:
    WhisperModel = None
    TEM_FASTER_WHISPER = False
import websockets
import obsws_python as obs
import logging
logging.getLogger("websockets.server").setLevel(logging.CRITICAL)

try:
    import requests
except Exception:
    requests = None

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

# ----------------------------- CONFIGURACAO -----------------------------

PASTA = Path(__file__).parent
ARQ_CONFIG = PASTA / "config.json"

CONFIG = {
    "modelo": "small",
    "modelo_ao_vivo": "small",
    "modelo_refino": "large-v3-turbo",
    "idioma": "pt",
    # v1.1 Global Language Rules: um idioma por vez, sem modo automático por padrão.
    "language_profile": "pt-BR",
    "global_language_mode": "standard",       # standard=leve; ai_boost=opcional com OpenAI/Gemini
    "source_language": "pt",
    "output_language": "pt-BR",
    "live_translation_enabled": False,
    "live_translation_provider": "gemini",    # gemini ou openai
    "live_translation_target": "en",
    "phrase_ai_enabled": False,               # análise frase por frase, desligado por padrão
    "phrase_ai_provider": "gemini",
    "sample_rate": 16000,
    "canais": 1,
    "bloco_segundos": 4.0,
    "bloco_segundos_ao_vivo_local": 4.0,
    "beam_size_ao_vivo": 5,
    "vps_modo_tempo_real": True,
    "vps_bloco_segundos_ao_vivo": 2.5,
    "segurar_frase_incompleta_ao_vivo": False,
    "beam_size": 7,
    # MLX Whisper local usa prompt curto em PT-BR; refino contextual fica na VPS/Ollama.
    "prompt_transcricao": "",
    "transcricao_motor": "padrao",  # padrao=MLX local; turbo=OpenAI Realtime
    "transcricao_ativa": True,
    "openai_realtime_model": "gpt-realtime-whisper",
    "openai_realtime_delay": "high",
    "openai_realtime_commit_segundos": 12.0,
    "gemini_api_key": "",
    "gemini_enabled": False,
    "gemini_model": "gemini-2.5-flash-lite",
    # Gemini economico: analisa menos vezes, mas com janela movel grande.
    "gemini_intervalo_seg": 45.0,
    "gemini_janela_contexto_seg": 180.0,
    "gemini_min_chars": 700,
    "gemini_max_chars": 9000,
    "gemini_timeout_seg": 35.0,
    "gemini_tutorial_url": "https://ai.google.dev/gemini-api/docs/api-key",
    "corte_seguro": True,
    "agrupar_assunto": True,
    "local_asr_engine": "mlx-whisper",
    "whisper_local_perfil": "leve",          # leve ou pro
    "whisper_local_modelo_leve": "mlx-community/whisper-large-v3-turbo",
    "whisper_local_modelo_pro": "mlx-community/whisper-large-v3",
    "whisper_local_device_cpu": "cpu",
    "whisper_local_compute_type_cpu": "int8",
    "whisper_local_compute_type_gpu": "float16",
    "whisper_local_usuario_tem_gpu": False,
    "whisper_local_task": "transcribe",
    "whisper_local_language": "pt",
    "forcar_ptbr_local": True,
    "idioma_whisper_local": "pt",
    "correcao_contextual_ao_vivo": True,
    "modelo_ao_vivo_rapido": "base",
    "modelo_ao_vivo_preciso": "small",
    "whisper_local_perfil": "leve",             # leve ou pro
    "whisper_local_usuario_tem_gpu": False,      # usuario informa se o PC tem GPU NVIDIA/CUDA
    "whisper_local_modelo_leve": "mlx-community/whisper-large-v3-turbo",
    "whisper_local_modelo_pro": "mlx-community/whisper-large-v3",
    "whisper_local_device_cpu": "cpu",
    "whisper_local_device_gpu": "cuda:0",
    "whisper_local_sensevoice_aceita_ptbr": False,
    "whisper_local_rejeitar_ingles_em_ptbr": True,
    "whisper_local_fallback_vps_se_invalido": True,
    "whisper_local_baixar_modelo_durante_gravacao": False,
    "whisper_local_vad_model": "fsmn-vad",
    "whisper_local_punc_model": "ct-punc",
    "transcricao_modo": "local",        # v75: MLX MLX Whisper local/offline
    "whisper_vps_base_url": "http://2.25.157.230:8000",
    "transcription_engine": "mlx-whisper",
    "whisper_vps_endpoint": "/transcribe-fastwhisper",
    "whisper_vps_url": "http://2.25.157.230:8000/transcribe-fastwhisper",
    "whisper_vps_token": "framezero_obs_2026",
    "vps_auth_header": "x-api-key",
    "vps_modelo_ia_principal": "criador-cristao:latest",
    "vps_modelo_ia_base": "qwen2.5:3b",
    "vps_modelo_ia_extra": "deepseek-r1:1.5b",
    "vps_ollama_interno": "http://127.0.0.1:11434",
    "whisper_vps_health_endpoint": "/health",
    "whisper_vps_jobs_endpoint": "/jobs",
    "vps_timeout_seg": 45,
    "vps_poll_jobs": True,
    "vps_job_timeout_seg": 90,
    "vps_fallback_local": False,
    "vps_enviar_audio_ao_vivo": False,
    "whisper_vps_analyze_endpoint": "/analyze-text",
    "vps_analisar_com_ia_local": False,
    "vps_analyze_timeout_seg": 120,
    "vps_analyze_min_chars": 80,
    "vps_analyze_live_endpoint": "/analyze-live-chunk",
    "vps_tentar_analyze_live_chunk": False,
    "forcar_blackhole_se_existir": True,
    "forcar_blackhole_input_channels": True,
    "audio_device_index_forcado": None,
    "transcricao_tempo_real_prioridade": True,
    "vps_analyze_async": True,
    "audio_min_rms_para_status": 0.006,
    "dispositivo_audio": None,

    "obs_host": "localhost",
    "obs_porta": 4455,
    "obs_senha": "TROQUE_AQUI",

    "porta_painel": 8765,
    "painel_url": "https://clips.framezeroai.com.br/obs",
    "painel_ws_url": "ws://localhost:8765",
    "usar_painel_web": True,
    # Plugin opcional obs-audio-to-websocket: recebe audio do mixer do OBS.
    # O plugin do OBS conecta AQUI (ele e o cliente, nos somos o servidor).
    "porta_plugin_audio": 8889,
    "rota_plugin_audio": "/audio",

    # Cortes
    "limiar_corte": 60,          # v81e score60: corte em tempo real libera a partir de 60+
    "modo_corte_auto": "local", # local por padrao; OpenAI e apenas reforco opcional
    "cooldown_corte_seg": 60,    # v81: Corte Seguro segura para nao picotar assunto
    "segundos_clipe": 120,       # quanto o Replay Buffer guarda pra tras (ajuste no OBS tambem)
    "intervalo_ia_seg": 15,      # v81: Corte Seguro analisa com mais contexto
    "duracao_corte_min": 15,     # corte final minimo padrao
    "duracao_corte_max": 60,     # v81: corte seguro maximo padrao
    "margem_antes_corte": 10,    # segundos antes do pico emocional
    "margem_depois_corte": 8,   # segundos depois do pico emocional
    "corte_exato_automatico": True,
    "usar_srt_como_timecode": True,     # usa timestamps da transcrição/SRT como fonte de corte exato
    "srt_idioma": "pt-BR",
    "srt_caracteres_por_linha": 37,
    "srt_linha_unica": True,
    "srt_quebrar_em_cues": True,
    "corrigir_legenda_contexto": True,
    "finalizacao_contexto_corte": True,  # evita terminar corte no meio da conclusão da frase/ideia
    "modo_contexto_pregacao": True,  # entende historia/ensino/aplicacao antes de cortar
    "preferir_palavra_direcionada": True,  # prioriza trechos aplicáveis ao público
    "historia_precisa_aplicacao": True,  # evita exportar só a história sem a conclusão/palavra
    "tipo_conteudo": "pregacao",       # selecionado no topo do painel: pregacao ou musica
    "detectar_musica_pregacao": False, # seletor manual no painel; se True, volta ao automático
    "musica_priorizar_refrao": True,  # em música, prioriza refrão, ponte, clímax e partes bonitas
    "ollama_internet_conectado": True,
    "musica_usar_letra_online": True,
    "musica_refino_online": True,
    "musica_busca_letra_online": True,
    "musica_nao_substituir_sem_confianca": True,
    "musica_confianca_minima_letra": 0.82,
    "musica_preservar_louvor_espontaneo": True,
    "lyrics_reference_source": "web_via_ollama_vps",
    "lyrics_reference_policy": "internet_sugere_audio_manda",
    "vps_transcricao_quase_tempo_real": True,  # usa blocos curtos via VPS para reduzir atraso
    "max_linhas_busca_aplicacao": 18,
    "preferir_fechamento_frase": True,   # tenta terminar em ponto/fechamento natural do SRT
    "contexto_transcricao": "pregação cristã brasileira; nomes bíblicos: Abraão, Sara, Agar, Ismael, Noé, Arca de Noé, Senhor, Deus, serva, timão",
    # SRT limpo no padrão PT-BR.
    # v81j: não geramos mais legenda.ass para manter a pasta do corte mais limpa.
    "subtitle_font_family": "Poppins",
    "subtitle_font_size": 13,
    "subtitle_bold": True,
    "subtitle_alignment": 2,
    "subtitle_primary_color_ass": "&H00FFFFFF",
    "subtitle_outline_color_ass": "&H00000000",
    "subtitle_back_color_ass": "&H80000000",
    "subtitle_outline": 2,
    "subtitle_shadow": 0,
    "corte_exato_busca_seg": 90,     # procura a melhor janela até 90s ao redor do pico
    "corte_exato_score_minimo": 88,  # v81: evita cortes ruins com score alto
    "gerar_mapa_cortes": True,       # CSV/TXT com minutagem exata para pós
    "pasta_principal_cortes": "FrameZero_Cortes",
    # v81j: gera automaticamente as duas entregas principais dentro da mesma pasta do título.
    # Estrutura final: Pasta do Título / Título - 16x9.mp4
    #                  Pasta do Título / Título - 9x16.mp4
    "gerar_versoes_automaticas": True,
    "versoes_corte_automaticas": ["16x9", "9x16"],
    "usar_titulo_no_nome_video": True,
    # Proporcao manual antiga continua existindo como fallback quando o modo automático for desligado.
    "proporcao_corte": "original",

    # Modo Vertical nativo do FrameZero: sem instalar o Aitum.
    # Via WebSocket o OBS nao permite criar uma segunda tela/canvas independente
    # igual ao Aitum; esta funcao automatiza preview 9:16, cena auxiliar e cortes finais verticais.
    "vertical_ativo": False,
    "vertical_cena": "FrameZero Vertical",
    "vertical_proporcao": "9:16",
    "vertical_seguir_pastor": False,
}

# config.json guarda coisas que o usuario muda pelo painel (ex: chave OpenAI)
def carregar_config_usuario():
    if ARQ_CONFIG.exists():
        try:
            return json.loads(ARQ_CONFIG.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def salvar_config_usuario(d):
    atual = carregar_config_usuario()
    atual.update(d)
    ARQ_CONFIG.write_text(json.dumps(atual, ensure_ascii=False, indent=2), encoding="utf-8")

config_usuario = carregar_config_usuario()


# ----------------------------- GLOBAL LANGUAGE RULES v1.1 -----------------------------

# O FrameZero trabalha com UM idioma por vez por padrão.
# Não existe modo automático nesta etapa: o usuário escolhe o idioma no painel.
# AI Boost é opcional e pode habilitar tradução ao vivo e análise frase por frase via OpenAI/Gemini.
LANGUAGE_PROFILES = {
    "pt-BR": {
        "label": "Português Brasil", "whisper_language": "pt", "output_language": "pt-BR",
        "context": "pregação cristã brasileira; pastor falando; culto; igreja; referências bíblicas; momentos de fé, humor, história, emoção e aplicação prática",
        "ai_language": "português brasileiro", "caption_style": "emocional, direto, cristão brasileiro, natural para Reels/TikTok/Shorts",
        "god_terms": {"deus":"Deus", "senhor":"Senhor", "jesus":"Jesus", "espirito santo":"Espírito Santo", "espírito santo":"Espírito Santo"},
        "impact_patterns": ["não desista", "nao desista", "Deus está", "Deus não terminou", "receba essa palavra", "eu profetizo", "eu declaro", "chegou a hora"],
        "humor_patterns": ["olha para a pessoa do lado", "quem conhece alguém assim", "tem gente", "sabe aquela pessoa"],
        "story_patterns": ["eu lembro", "uma vez", "teve um dia", "quando eu era", "deixa eu te contar"],
        "hashtags": ["#pregação", "#fé", "#Jesus", "#Deus", "#igreja", "#reelscristao"],
    },
    "en": {
        "label": "English", "whisper_language": "en", "output_language": "en",
        "context": "Christian sermon in English; pastor speaking; church service; Bible references; faith, humor, story, emotional moments and practical application",
        "ai_language": "English", "caption_style": "clear, inspirational, natural for church social media, Reels, TikTok and Shorts",
        "god_terms": {"god":"God", "lord":"Lord", "jesus":"Jesus", "holy spirit":"Holy Spirit"},
        "impact_patterns": ["don't give up", "God is not finished", "this word is for you", "I declare", "I believe", "the Lord is saying"],
        "humor_patterns": ["look at your neighbor", "you know someone like this", "some of you", "tell your neighbor"],
        "story_patterns": ["I remember", "one day", "there was a time", "when I was", "let me tell you"],
        "hashtags": ["#sermon", "#faith", "#Jesus", "#God", "#church", "#christianreels"],
    },
    "es": {
        "label": "Español", "whisper_language": "es", "output_language": "es",
        "context": "predicación cristiana en español; pastor hablando; culto; iglesia; referencias bíblicas; fe, humor, historia, emoción y aplicación práctica",
        "ai_language": "español", "caption_style": "pastoral, emocional, latino, natural para Reels, TikTok y Shorts",
        "god_terms": {"dios":"Dios", "señor":"Señor", "senor":"Señor", "jesús":"Jesús", "jesus":"Jesús", "espíritu santo":"Espíritu Santo", "espiritu santo":"Espíritu Santo"},
        "impact_patterns": ["no te rindas", "Dios no ha terminado", "esta palabra es para ti", "yo declaro", "recibe esta palabra"],
        "humor_patterns": ["mira a la persona de al lado", "quién conoce a alguien así", "dile a tu vecino"],
        "story_patterns": ["yo recuerdo", "un día", "hubo un tiempo", "cuando yo era", "déjame contarte"],
        "hashtags": ["#predicación", "#fe", "#Jesús", "#Dios", "#iglesia", "#reelscristianos"],
    },
    "fr": {"label":"Français", "whisper_language":"fr", "output_language":"fr", "context":"prédication chrétienne en français; pasteur; église; références bibliques", "ai_language":"français", "caption_style":"clair, pastoral, inspirant", "god_terms":{"dieu":"Dieu", "seigneur":"Seigneur", "jésus":"Jésus", "esprit saint":"Esprit Saint"}, "impact_patterns":["n'abandonne pas", "Dieu n'a pas fini", "cette parole est pour toi"], "humor_patterns":["regarde ton voisin"], "story_patterns":["je me souviens", "un jour"], "hashtags":["#prédication", "#foi", "#Jésus", "#Dieu", "#église"]},
    "de": {"label":"Deutsch", "whisper_language":"de", "output_language":"de", "context":"christliche Predigt auf Deutsch; Pastor; Kirche; Bibelstellen", "ai_language":"Deutsch", "caption_style":"klar, inspirierend, kirchlich", "god_terms":{"gott":"Gott", "herr":"Herr", "jesus":"Jesus", "heiliger geist":"Heiliger Geist"}, "impact_patterns":["gib nicht auf", "Gott ist noch nicht fertig"], "humor_patterns":["schau deinen Nachbarn an"], "story_patterns":["ich erinnere mich", "eines Tages"], "hashtags":["#predigt", "#glaube", "#Jesus", "#Gott", "#kirche"]},
    "it": {"label":"Italiano", "whisper_language":"it", "output_language":"it", "context":"predicazione cristiana in italiano; pastore; chiesa; riferimenti biblici", "ai_language":"italiano", "caption_style":"chiaro, pastorale, ispirazionale", "god_terms":{"dio":"Dio", "signore":"Signore", "gesù":"Gesù", "gesu":"Gesù", "spirito santo":"Spirito Santo"}, "impact_patterns":["non arrenderti", "Dio non ha finito"], "humor_patterns":["guarda il tuo vicino"], "story_patterns":["mi ricordo", "un giorno"], "hashtags":["#predicazione", "#fede", "#Gesù", "#Dio", "#chiesa"]},
    "pt-PT": {"label":"Português Portugal", "whisper_language":"pt", "output_language":"pt-PT", "context":"pregação cristã em português europeu; pastor; igreja; referências bíblicas", "ai_language":"português europeu", "caption_style":"claro, pastoral, cristão", "god_terms":{"deus":"Deus", "senhor":"Senhor", "jesus":"Jesus", "espirito santo":"Espírito Santo", "espírito santo":"Espírito Santo"}, "impact_patterns":["não desistas", "Deus não terminou"], "humor_patterns":["olha para a pessoa ao lado"], "story_patterns":["lembro-me", "um dia"], "hashtags":["#pregação", "#fé", "#Jesus", "#Deus", "#igreja"]},
    "ko": {"label":"Korean", "whisper_language":"ko", "output_language":"ko", "context":"Korean Christian sermon; pastor speaking; church service; Bible references", "ai_language":"Korean", "caption_style":"clear, pastoral, emotional", "god_terms":{}, "impact_patterns":[], "humor_patterns":[], "story_patterns":[], "hashtags":["#sermon", "#church", "#Jesus"]},
    "ja": {"label":"Japanese", "whisper_language":"ja", "output_language":"ja", "context":"Japanese Christian sermon; pastor speaking; church service; Bible references", "ai_language":"Japanese", "caption_style":"clear, respectful, pastoral", "god_terms":{}, "impact_patterns":[], "humor_patterns":[], "story_patterns":[], "hashtags":["#sermon", "#church", "#Jesus"]},
    "zh": {"label":"Mandarin Chinese", "whisper_language":"zh", "output_language":"zh", "context":"Mandarin Chinese Christian sermon; pastor speaking; church service; Bible references", "ai_language":"Simplified Chinese", "caption_style":"clear, pastoral, inspirational", "god_terms":{}, "impact_patterns":[], "humor_patterns":[], "story_patterns":[], "hashtags":["#sermon", "#church", "#Jesus"]},
    "hi": {"label":"Hindi", "whisper_language":"hi", "output_language":"hi", "context":"Hindi Christian sermon; pastor speaking; church service; Bible references", "ai_language":"Hindi", "caption_style":"clear, pastoral, inspirational", "god_terms":{}, "impact_patterns":[], "humor_patterns":[], "story_patterns":[], "hashtags":["#sermon", "#church", "#Jesus"]},
    "ar": {"label":"Arabic", "whisper_language":"ar", "output_language":"ar", "context":"Arabic Christian sermon; pastor speaking; church service; Bible references", "ai_language":"Arabic", "caption_style":"clear, pastoral, inspirational", "god_terms":{}, "impact_patterns":[], "humor_patterns":[], "story_patterns":[], "hashtags":["#sermon", "#church", "#Jesus"]},
    "id": {"label":"Indonesian", "whisper_language":"id", "output_language":"id", "context":"Indonesian Christian sermon; pastor speaking; church service; Bible references", "ai_language":"Indonesian", "caption_style":"clear, pastoral, inspirational", "god_terms":{}, "impact_patterns":[], "humor_patterns":[], "story_patterns":[], "hashtags":["#sermon", "#church", "#Jesus"]},
    "tl": {"label":"Tagalog / Filipino", "whisper_language":"tl", "output_language":"tl", "context":"Tagalog/Filipino Christian sermon; pastor speaking; church service; Bible references", "ai_language":"Tagalog/Filipino", "caption_style":"clear, pastoral, inspirational", "god_terms":{}, "impact_patterns":[], "humor_patterns":[], "story_patterns":[], "hashtags":["#sermon", "#church", "#Jesus"]},
    "sw": {"label":"Swahili", "whisper_language":"sw", "output_language":"sw", "context":"Swahili Christian sermon; pastor speaking; church service; Bible references", "ai_language":"Swahili", "caption_style":"clear, pastoral, inspirational", "god_terms":{}, "impact_patterns":[], "humor_patterns":[], "story_patterns":[], "hashtags":["#sermon", "#church", "#Jesus"]},
    "yo": {"label":"Yoruba", "whisper_language":"yo", "output_language":"yo", "context":"Yoruba Christian sermon; pastor speaking; church service; Bible references", "ai_language":"Yoruba", "caption_style":"clear, pastoral, inspirational", "god_terms":{}, "impact_patterns":[], "humor_patterns":[], "story_patterns":[], "hashtags":["#sermon", "#church", "#Jesus"]},
}

SUPPORTED_LANGUAGE_ORDER = ["pt-BR","en","es","fr","de","it","pt-PT","ko","ja","zh","hi","ar","id","tl","sw","yo"]

def perfil_id_atual():
    pid = str(config_usuario.get("language_profile", CONFIG.get("language_profile", "pt-BR")) or "pt-BR").strip()
    return pid if pid in LANGUAGE_PROFILES else "pt-BR"

def perfil_idioma_atual():
    return LANGUAGE_PROFILES.get(perfil_id_atual(), LANGUAGE_PROFILES["pt-BR"])

def whisper_language_atual():
    return str(config_usuario.get("source_language") or perfil_idioma_atual().get("whisper_language") or "pt").strip()

def output_language_atual():
    return str(config_usuario.get("output_language") or perfil_idioma_atual().get("output_language") or perfil_id_atual()).strip()

def contexto_transcricao_atual():
    return str(config_usuario.get("contexto_transcricao") or perfil_idioma_atual().get("context") or "Christian sermon").strip()

def ai_language_atual():
    return str(perfil_idioma_atual().get("ai_language") or output_language_atual()).strip()

def ai_boost_ativo():
    return str(config_usuario.get("global_language_mode", CONFIG.get("global_language_mode", "standard"))).lower().strip() == "ai_boost"

def live_translation_ativa():
    return ai_boost_ativo() and bool(config_usuario.get("live_translation_enabled", CONFIG.get("live_translation_enabled", False)))

def phrase_ai_ativa():
    return ai_boost_ativo() and bool(config_usuario.get("phrase_ai_enabled", CONFIG.get("phrase_ai_enabled", False)))

def perfis_idioma_para_painel():
    return [{"id": k, "label": LANGUAGE_PROFILES[k].get("label", k), "whisper_language": LANGUAGE_PROFILES[k].get("whisper_language", k)} for k in SUPPORTED_LANGUAGE_ORDER if k in LANGUAGE_PROFILES]

def prompt_global_cortes():
    perfil = perfil_idioma_atual()
    lingua = ai_language_atual()
    contexto = contexto_transcricao_atual()
    estilo = perfil.get("caption_style", "natural church social media")
    impact = ", ".join(perfil.get("impact_patterns", [])[:10])
    humor = ", ".join(perfil.get("humor_patterns", [])[:8])
    story = ", ".join(perfil.get("story_patterns", [])[:8])
    return f"""You are a global AI clipping director for Christian churches.

Analyze a sermon/message in this language: {lingua}.
Context: {contexto}.
Output language: {lingua}.
Social caption style: {estilo}.

Find moments that can become viral or useful church social clips:
- stories and illustrations from the pulpit
- jokes, light moments and audience interaction
- emotional and memorable moments
- strong faith declarations
- practical application
- biblical teaching
- spiritual calls and altar-call style moments
- pastoral confrontation with love
- hope, healing, restoration and identity moments
- curiosity hooks and turning points

Language-specific hints:
Impact phrases/patterns: {impact or 'use natural phrases for this language'}
Humor/audience patterns: {humor or 'detect natural humor and audience interaction'}
Story patterns: {story or 'detect personal stories and illustrations'}

Return titles, reasons, impact phrases, captions and Bible references naturally in {lingua}.
Never translate unless live translation/output language explicitly asks for it.
Do not invent Bible verses; only extract references that appear or are clearly mentioned.
Respond only as valid JSON."""

BIBLE_BOOKS_BY_PROFILE = {
    "pt-BR": r"G[eê]nesis|[ÊE]xodo|Lev[ií]tico|N[uú]meros|Deuteron[oô]mio|Josu[eé]|Ju[ií]zes|Rute|(?:1|2)\s*Samuel|(?:1|2)\s*Reis|(?:1|2)\s*Cr[oô]nicas|Esdras|Neemias|Ester|J[oó]|Salmos?|Prov[eé]rbios|Eclesiastes|Cantares|Isa[ií]as|Jeremias|Ezequiel|Daniel|Mateus|Marcos|Lucas|Jo[aã]o|Atos|Romanos|(?:1|2)\s*Cor[ií]ntios|G[aá]latas|Ef[eé]sios|Filipenses|Colossenses|Hebreus|Tiago|Apocalipse|Gn|Ex|Sl|Pv|Mt|Mc|Lc|Jo|At|Rm|Ap",
    "en": r"Genesis|Exodus|Leviticus|Numbers|Deuteronomy|Joshua|Judges|Ruth|(?:1|2)\s*Samuel|(?:1|2)\s*Kings|(?:1|2)\s*Chronicles|Ezra|Nehemiah|Esther|Job|Psalms?|Proverbs|Ecclesiastes|Song of Songs|Isaiah|Jeremiah|Ezekiel|Daniel|Matthew|Mark|Luke|John|Acts|Romans|(?:1|2)\s*Corinthians|Galatians|Ephesians|Philippians|Colossians|Hebrews|James|Revelation|Gen|Ex|Ps|Prov|Matt|Mk|Lk|Jn|Rom|Rev",
    "es": r"G[eé]nesis|[ÉE]xodo|Lev[ií]tico|N[uú]meros|Deuteronomio|Josu[eé]|Jueces|Rut|(?:1|2)\s*Samuel|(?:1|2)\s*Reyes|(?:1|2)\s*Cr[oó]nicas|Esdras|Nehem[ií]as|Ester|Job|Salmos?|Proverbios|Eclesiast[eé]s|Cantares|Isa[ií]as|Jerem[ií]as|Ezequiel|Daniel|Mateo|Marcos|Lucas|Juan|Hechos|Romanos|(?:1|2)\s*Corintios|G[aá]latas|Efesios|Filipenses|Colosenses|Hebreos|Santiago|Apocalipsis|Gn|Ex|Sal|Mt|Mc|Lc|Jn|Ro|Ap",
    "fr": r"Gen[eè]se|Exode|L[eé]vitique|Nombres|Deut[eé]ronome|Josu[eé]|Juges|Ruth|Psaumes?|Proverbes|[ÉE]sa[iï]e|J[eé]r[eé]mie|Matthieu|Marc|Luc|Jean|Actes|Romains|Corinthiens|Galates|[ÉE]ph[eé]siens|Philippiens|H[eé]breux|Jacques|Apocalypse",
    "de": r"Genesis|Exodus|Levitikus|Numeri|Deuteronomium|Josua|Richter|Ruth|Psalmen?|Spr[uü]che|Jesaja|Jeremia|Matth[aä]us|Markus|Lukas|Johannes|Apostelgeschichte|R[oö]mer|Korinther|Galater|Epheser|Philipper|Hebr[aä]er|Jakobus|Offenbarung",
    "it": r"Genesi|Esodo|Levitico|Numeri|Deuteronomio|Giosu[eè]|Giudici|Rut|Salmi?|Proverbi|Isaia|Geremia|Matteo|Marco|Luca|Giovanni|Atti|Romani|Corinzi|Galati|Efesini|Filippesi|Ebrei|Giacomo|Apocalisse",
}

def bible_books_regex_atual():
    pid = perfil_id_atual()
    if pid == "pt-PT": pid = "pt-BR"
    return BIBLE_BOOKS_BY_PROFILE.get(pid) or BIBLE_BOOKS_BY_PROFILE.get("en")

# ----------------------------- FIM GLOBAL LANGUAGE RULES v1.1 -----------------------------

# ----------------------------- DETECTOR LOCAL DE CORTES -----------------------------

PALAVRAS_IMPACTO = {
    "deus","jesus","cristo","espirito","santo","senhor","milagre","cura",
    "libertacao","vitoria","fe","creia","levanta","hoje","agora","gloria",
    "aleluia","amem","profetico","uncao","altar","salvacao","graca","poder",
    "fogo","avivamento","transformacao","proposito","chamado","promessa",
    "familia","casamento","filho","filha","casa","dor","medo","ansiedade",
    "perdao","arrependimento","recomeco","impossivel","deserto","processo",
}

FRASES_IMPACTO = {
    "deus vai": 24, "deus esta": 20, "deus não": 18, "deus nao": 18,
    "eu profetizo": 32, "eu declaro": 30, "receba": 22, "tome posse": 26,
    "não desista": 34, "nao desista": 34, "não pare": 28, "nao pare": 28,
    "presta atenção": 22, "presta atencao": 22, "escuta isso": 24,
    "olha para mim": 20, "eu vim te dizer": 28, "o senhor está dizendo": 30,
    "o senhor esta dizendo": 30, "você não": 18, "voce nao": 18,
    "você vai": 20, "voce vai": 20, "chegou a hora": 30, "a partir de hoje": 28,
    "nunca mais": 24, "tem gente": 18, "sabe por quê": 18, "sabe por que": 18,
    "a bíblia diz": 20, "a biblia diz": 20, "está escrito": 20, "esta escrito": 20,
}


# Gatilhos adicionais para pregação que costuma performar em cortes:
# historia + tensão + virada + presença/voz + aplicação direta.
FRASES_VIRAIS_PREGA = {
    "deixa eu te contar": 20, "presta atenção": 18, "presta atencao": 18,
    "o problema é": 18, "o problema e": 18, "o ponto é": 16, "o ponto e": 16,
    "a questão é": 16, "a questao e": 16, "a verdade é": 22, "a verdade e": 22,
    "sabe o que acontece": 18, "sabe o que deus": 24, "quando deus": 18,
    "tem uma coisa": 16, "eu quero te dizer": 22, "escuta isso": 20,
    "foi aí que": 18, "foi ai que": 18, "até que": 16, "ate que": 16,
    "mas deus": 26, "só que deus": 24, "so que deus": 24, "de repente": 20,
    "no dia em que": 16, "quando ele percebe": 18, "olha para mim": 18,
    "isso aqui é forte": 24, "isso aqui e forte": 24, "isso é muito forte": 24,
}

PALAVRAS_EMOCIONAIS_PREGA = {
    "choro", "chorou", "dor", "ferida", "perda", "luto", "medo", "ansiedade",
    "depressao", "depressão", "sozinho", "deserto", "processo", "humilhado",
    "quebrado", "quebrantado", "arrependimento", "perdao", "perdão",
    "milagre", "cura", "restauracao", "restauração", "promessa", "proposito",
    "propósito", "presenca", "presença", "gloria", "glória", "uncao", "unção",
    "avivamento", "espirito", "espírito", "jesus", "deus"
}

# Música/louvor: a regra de corte é diferente de pregação.
# Em música, o melhor corte costuma estar no refrão, ponte, clímax, subida de emoção,
# repetição bonita ou frase cantável. Não precisa ter aplicação/explicação como pregação.
PALAVRAS_MUSICA_LOUVOR = {
    "louvor", "adoracao", "adoração", "cantar", "canto", "canção", "cancao",
    "voz", "som", "melodia", "refrão", "refrao", "ponte", "coro", "ministração",
    "minha alma", "meu coração", "meu coracao", "te adoro", "eu te amo",
    "santo", "digno", "hosana", "aleluia", "gloria", "glória", "pra sempre",
    "para sempre", "vem senhor", "espírito santo", "espirito santo"
}

FRASES_MUSICA_IMPACTO = {
    "te adoro": 28, "eu te amo": 26, "tu és santo": 30, "tu es santo": 30,
    "santo santo": 34, "digno é": 28, "digno e": 28, "pra sempre": 22,
    "para sempre": 22, "minha alma": 24, "meu coração": 22, "meu coracao": 22,
    "vem senhor": 24, "espírito santo": 26, "espirito santo": 26,
    "aleluia": 18, "glória": 18, "gloria": 18, "hosana": 20,
}

PALAVRAS_PREGA_FALA = {
    "biblia", "bíblia", "versiculo", "versículo", "capitulo", "capítulo",
    "texto", "pregacao", "pregação", "mensagem", "ensino", "historia", "história",
    "abraao", "abraão", "moises", "moisés", "davi", "paulo", "pedro",
    "olha", "presta", "atencao", "atenção", "entenda", "voce", "você",
    "porque", "portanto", "significa", "aplicacao", "aplicação", "disse"
}

def classificar_conteudo_bloco(texto):
    """Retorna 'musica' ou 'pregacao' olhando texto, repetição e vocabulário.
    É heurístico e serve para escolher a lógica de corte certa sem depender da IA.
    """
    normal = _norm(texto or "")
    if not normal:
        return "pregacao"
    palavras = [p.strip(".,!?;:()[]{}\"'") for p in normal.split() if p.strip(".,!?;:()[]{}\"'")]
    music_score = 0
    prega_score = 0
    for termo in PALAVRAS_MUSICA_LOUVOR:
        if _norm(termo) in normal:
            music_score += 5
    for termo in PALAVRAS_PREGA_FALA:
        if _norm(termo) in normal:
            prega_score += 4
    for frase, peso in FRASES_MUSICA_IMPACTO.items():
        if _norm(frase) in normal:
            music_score += max(5, int(peso/4))
    # Música costuma repetir palavras/frases curtas; pregação costuma ter frases longas e explicativas.
    if palavras:
        repeticao = len(palavras) - len(set(palavras))
        if repeticao >= 3:
            music_score += min(18, repeticao * 3)
        media_len = sum(len(p) for p in palavras) / max(1, len(palavras))
        if len(palavras) <= 22 and repeticao >= 2:
            music_score += 10
        if len(palavras) >= 34:
            prega_score += 8
    if re.search(r"\b(versiculo|versículo|capitulo|capítulo|a biblia diz|está escrito|esta escrito)\b", normal):
        prega_score += 18
    if re.search(r"\b(refr[aã]o|ponte|coro|cant[a-z]*|adora[a-z]*|louvor)\b", normal):
        music_score += 16
    return "musica" if music_score >= prega_score + 8 else "pregacao"


def tipo_conteudo_atual(texto=""):
    """Usa o seletor manual do painel. Se o usuário ativar detecção automática, classifica pelo texto."""
    manual = str(config_usuario.get("tipo_conteudo", CONFIG.get("tipo_conteudo", "pregacao"))).lower().strip()
    if manual not in ("pregacao", "musica"):
        manual = "pregacao"
    if bool(config_usuario.get("detectar_musica_pregacao", CONFIG.get("detectar_musica_pregacao", False))):
        return classificar_conteudo_bloco(texto or "")
    return manual


def score_heuristico_musica(texto):
    """Pontuação para louvor/música. Prioriza refrão, ponte, clímax e partes bonitas."""
    original = texto.strip()
    normal = _norm(original)
    palavras = [p.strip(".,!?;:()[]{}\"'") for p in normal.split()]
    palavras = [p for p in palavras if p]
    if len(palavras) < 3:
        return 0, [], "", ""
    score = 18
    razoes = ["música/louvor"]
    for frase, peso in FRASES_MUSICA_IMPACTO.items():
        if _norm(frase) in normal:
            score += peso
            razoes.append("frase cantável")
    n_music = 0
    for termo in PALAVRAS_MUSICA_LOUVOR:
        if _norm(termo) in normal:
            n_music += 1
    if n_music:
        score += min(n_music * 9, 36)
        razoes.append("vocabulário de louvor")
    repeticao = len(palavras) - len(set(palavras))
    if repeticao >= 2:
        score += min(repeticao * 8, 32)
        razoes.append("refrão/repetição")
    if 5 <= len(palavras) <= 24:
        score += 12
    if "!" in original:
        score += 8
    if re.search(r"\b(santo|digno|aleluia|gloria|glória|hosana|jesus|deus|senhor)\b", normal):
        score += 12
        razoes.append("clímax espiritual")
    emocao = "adoração"
    if re.search(r"\b(choro|quebrantado|alma|coracao|coração|amor)\b", normal):
        emocao = "quebrantamento"
    elif re.search(r"\b(aleluia|gloria|glória|hosana|celebrar|alegria)\b", normal):
        emocao = "celebração"
    funcao = "refrão" if repeticao >= 2 else "clímax musical"
    return min(score, 100), razoes[:4], emocao, funcao

EMOCOES_LOCAL = [
    ("quebrantamento", ["choro","dor","perdao","arrependimento","quebrantado","quebrantamento"]),
    ("fé", ["fe","creia","impossivel","milagre","promessa","vitoria"]),
    ("esperança", ["esperanca","recomeco","amanha","novo","restaurar","levanta"]),
    ("urgência", ["hoje","agora","tempo","hora","decida","escolha"]),
    ("convicção", ["declaro","profetizo","verdade","nunca","sempre","receba"]),
]

def _norm(txt):
    txt = txt.lower()
    txt = txt.replace("ã","a").replace("á","a").replace("à","a").replace("â","a")
    txt = txt.replace("é","e").replace("ê","e").replace("í","i")
    txt = txt.replace("ó","o").replace("ô","o").replace("õ","o").replace("ú","u").replace("ç","c")
    return re.sub(r"\s+", " ", txt).strip()

def corte_modo_atual():
    modo = str(config_usuario.get("corte_modo", config_usuario.get("modo_corte", "standard"))).lower().strip()
    return "fast" if modo == "fast" else "standard"

def current_limiar():
    try:
        base = int(config_usuario.get("limiar_corte", CONFIG["limiar_corte"]))
    except Exception:
        base = CONFIG["limiar_corte"]
    # Corte Seguro precisa ser mais delicado: score ruim não pode virar 100 e cortar toda hora.
    if corte_modo_atual() == "standard":
        return max(60, base)
    return max(60, base)

def duracao_cortes_config():
    """Retorna duração mínima/máxima configurada no painel.
    Esta função é a autoridade única para evitar clipes de Replay Buffer com 2 minutos.
    """
    try:
        mn = int(config_usuario.get("duracao_corte_min", config_usuario.get("chunk_seconds_min", CONFIG.get("duracao_corte_min", 15))))
    except Exception:
        mn = int(CONFIG.get("duracao_corte_min", 15))
    try:
        mx = int(config_usuario.get("duracao_corte_max", config_usuario.get("chunk_seconds_max", CONFIG.get("duracao_corte_max", 45))))
    except Exception:
        mx = int(CONFIG.get("duracao_corte_max", 45))
    mn = max(5, min(300, mn))
    mx = max(mn, min(300, mx))
    return mn, mx

def normalizar_janela_corte(inicio, fim, pico=None):
    """Garante que qualquer corte respeite exatamente min/max do painel.
    Se a janela vier maior (ex: replay buffer 120s), recorta ao redor do pico.
    """
    mn, mx = duracao_cortes_config()
    try: inicio = float(inicio or 0)
    except Exception: inicio = 0.0
    try: fim = float(fim or 0)
    except Exception: fim = inicio
    if pico is None:
        pico = fim if fim > inicio else inicio
    try: pico = float(pico or 0)
    except Exception: pico = inicio
    inicio = max(0.0, inicio)
    fim = max(inicio, fim)
    dur = fim - inicio
    if dur <= 0:
        # manual: pega a duração máxima anterior ao momento atual
        fim = max(inicio + mn, pico)
        inicio = max(0.0, fim - mx)
        dur = fim - inicio
    if dur > mx:
        # Mantém o pico dentro do clipe, com contexto antes e depois.
        antes = min(max(5.0, mx * 0.55), max(0.0, pico - inicio))
        novo_ini = max(0.0, pico - antes)
        novo_fim = novo_ini + mx
        if novo_fim < pico:
            novo_fim = pico
            novo_ini = max(0.0, novo_fim - mx)
        inicio, fim, dur = novo_ini, novo_fim, mx
    if dur < mn:
        extra = mn - dur
        inicio = max(0.0, inicio - extra * 0.55)
        fim = inicio + mn
        dur = mn
    # Segurança final: nunca ultrapassar máximo configurado.
    if dur > mx:
        fim = inicio + mx
        dur = mx
    return round(inicio, 2), round(fim, 2), round(dur, 2)


def score_heuristico(texto):
    """Pontua uma frase sem OpenAI. Projetado para cortar pouco, mas cortar sozinho.
    Em modo automático, primeiro entende se o trecho é música/louvor ou pregação.
    """
    original = texto.strip()
    if tipo_conteudo_atual(original) == "musica":
        return score_heuristico_musica(original)
    normal = _norm(original)
    palavras = [p.strip(".,!?;:()[]{}\"'") for p in normal.split()]
    palavras = [p for p in palavras if p]
    if len(palavras) < 4:
        return 0, [], "", ""

    score = 0
    razoes = []

    # Frases compostas valem mais que palavras soltas.
    for frase, peso in FRASES_IMPACTO.items():
        if _norm(frase) in normal:
            score += peso
            razoes.append(frase)

    # Camada viral/emocional para pregação: historia, tensao, virada e aplicação.
    for frase, peso in FRASES_VIRAIS_PREGA.items():
        if _norm(frase) in normal:
            score += peso
            razoes.append("viral: " + frase)

    n_emo = sum(1 for p in palavras if p in {_norm(x) for x in PALAVRAS_EMOCIONAIS_PREGA})
    if n_emo:
        score += min(n_emo * 7, 34)
        razoes.append("emoção espiritual")

    n_imp = sum(1 for p in palavras if p in {_norm(x) for x in PALAVRAS_IMPACTO})
    if n_imp:
        score += min(n_imp * 10, 38)
        razoes.append("palavras fortes")

    # Frases curtas/médias funcionam melhor como corte.
    if 7 <= len(palavras) <= 28:
        score += 12
    elif 29 <= len(palavras) <= 45:
        score += 6

    # Gatilhos de fala que geralmente viram corte.
    if "?" in original:
        score += 10; razoes.append("pergunta")
    if "!" in original:
        score += 8; razoes.append("ênfase")
    if re.search(r"\b(voce|você|tu|alguem|alguém|quem)\b", normal):
        score += 8
    if re.search(r"\b(hoje|agora|nunca|sempre|precisa|deve|pare|levanta|receba)\b", normal):
        score += 10; razoes.append("chamada")
    if re.search(r"\b(eu lembro|um dia|quando eu|teve uma vez|historia|história)\b", normal):
        score += 8; razoes.append("história")

    # Repetição de palavras importantes aumenta impacto.
    reps = len(palavras) - len(set(palavras))
    if reps >= 3:
        score += 5

    emocao = "fé"
    for nome, termos in EMOCOES_LOCAL:
        if any(_norm(t) in palavras or _norm(t) in normal for t in termos):
            emocao = nome
            break

    if any(r in razoes for r in ["pergunta", "chamada"]):
        funcao = "gancho"
    elif "história" in razoes:
        funcao = "história"
    elif score >= 78:
        funcao = "clímax"
    else:
        funcao = "declaração"

    # v81: calibração anti-score inflado.
    # Antes, palavras isoladas como "Deus", "hoje", "receba" podiam somar 100.
    # Agora 90+ só acontece quando há combinação de gancho + aplicação/virada + contexto.
    tem_direcao = bool(re.search(r"\b(voce|você|tu|alguem|alguém|quem|sua|seu|te|ti)\b", normal))
    tem_aplicacao = bool(re.search(r"\b(hoje|agora|precisa|deve|pare|levanta|receba|decida|escolha|nao desista|não desista|a partir de hoje|eu vim te dizer|eu quero te dizer)\b", normal))
    tem_virada = bool(re.search(r"\b(mas deus|so que deus|só que deus|de repente|foi ai que|foi aí que|ate que|até que|quando deus)\b", normal))
    tem_historia = bool(re.search(r"\b(historia|história|quando eu|um dia|teve uma vez|eu lembro|ele chegou|ela chegou)\b", normal))
    tem_base_biblica = bool(re.search(r"\b(biblia|bíblia|est[aá] escrito|versiculo|versículo|capitulo|capítulo)\b", normal))
    tem_frase_impacto = any(_norm(frase) in normal for frase in list(FRASES_IMPACTO.keys()) + list(FRASES_VIRAIS_PREGA.keys()))
    sinais_qualidade = sum([tem_direcao, tem_aplicacao, tem_virada, tem_historia, tem_base_biblica, tem_frase_impacto])

    # Penaliza fillers/trechos sem ideia fechada.
    if re.fullmatch(r"(e|aí|ai|né|tipo|então|entao|amém|amem|aleluia|glória|gloria|senhor|deus|jesus)[\s,.!?-]*", normal):
        score = min(score, 35)
    if len(palavras) < 8:
        score = min(score, 62)
    elif len(palavras) < 12 and sinais_qualidade < 3:
        score = min(score, 74)
    if len(palavras) > 70:
        score = min(score, 82)

    # Se não tem combinação de sinais, não pode parecer "100".
    if sinais_qualidade <= 1:
        score = min(score, 76)
    elif sinais_qualidade == 2:
        score = min(score, 86)
    elif sinais_qualidade == 3:
        score = min(score, 94)

    # 98-100 reservado para corte realmente excepcional, não para qualquer frase forte.
    if score >= 98 and sinais_qualidade < 5:
        score = 96
    if score >= 90 and not (tem_aplicacao or tem_virada or tem_direcao):
        score = 88

    return min(score, 100), razoes[:4], emocao, funcao

def titulo_local(texto, emocao, funcao):
    palavras = [p.strip(".,!?;:()[]{}\"'") for p in texto.split()]
    normal = _norm(texto)
    if "mas deus" in normal or "so que deus" in normal or "só que deus" in normal:
        return "Quando Deus entra na história"
    if "quem voce pensa que e" in normal or "quem você pensa que é" in normal:
        return "Quem você pensa que é?"
    if "sabe" in normal and "deus" in normal:
        return "Você sabe o que Deus está dizendo?"
    base = " ".join(palavras[:8]).strip()
    if len(base) > 46:
        base = base[:43].rstrip() + "..."
    if not base:
        base = f"Momento de {emocao}"
    return base[0].upper() + base[1:]

def cortes_locais(linhas_acumuladas):
    """Recebe [(tempo,texto)] e devolve cortes locais candidatos."""
    candidatos = []
    for i, (tt, tx) in enumerate(linhas_acumuladas):
        textos = [(tt, tx)]
        if i > 0:
            textos.append((linhas_acumuladas[i-1][0], linhas_acumuladas[i-1][1] + " " + tx))
        for tempo, texto in textos:
            s, raz, emocao, funcao = score_heuristico(texto)
            if volume_pico_no_tempo(tempo):
                s = min(100, s + 12)
                raz = (raz or []) + ["pico de voz/presença"]
                if emocao == "fé":
                    emocao = "presença"
            modo_corte = corte_modo_atual()
            limite_candidato = max(60, current_limiar() - (8 if modo_corte == "fast" else 2))
            # Corte Seguro só considera trechos com substância.
            if modo_corte == "standard" and len([p for p in _norm(texto).split() if p]) < 10:
                continue
            if s >= limite_candidato:
                candidatos.append({
                    "trecho": texto.strip(),
                    "score": s,
                    "titulo": titulo_local(texto, emocao, funcao),
                    "razao": ", ".join(raz) if raz else "detecção local",
                    "emocao": emocao,
                    "funcao": funcao,
                    "tempo": tempo,
                })
    # Melhor candidato da rodada para evitar excesso de clipes.
    candidatos.sort(key=lambda c: c["score"], reverse=True)
    return candidatos[:1]

ultimos_cortes_locais = []

def corte_local_repetido(texto, tempo):
    """Evita clipes duplicados quando a mesma frase aparece em janelas consecutivas."""
    global ultimos_cortes_locais
    normal = _norm(texto)[:90]
    cooldown = int(config_usuario.get("cooldown_corte_seg", CONFIG["cooldown_corte_seg"]))
    if corte_modo_atual() == "standard":
        cooldown = max(cooldown, 55)
    novos = []
    repetido = False
    for ant_txt, ant_t in ultimos_cortes_locais:
        if tempo - ant_t < cooldown:
            novos.append((ant_txt, ant_t))
            if normal and (normal in ant_txt or ant_txt in normal):
                repetido = True
    ultimos_cortes_locais = novos
    if repetido:
        return True
    ultimos_cortes_locais.append((normal, tempo))
    return False

def volume_pico_no_tempo(tempo):
    # considera pico se qualquer linha nos últimos ~2s teve volume acima do normal.
    try:
        t = float(tempo)
        for k, v in list(volume_picos.items()):
            if abs(float(k) - t) <= 2.5 and v:
                return True
    except Exception:
        pass
    return False

# ----------------------------- ESTADO -----------------------------
# ----------------------------- ESTADO -----------------------------

fila_audio = queue.Queue()
fila_analise = queue.Queue()
clientes = set()
loop_principal = None

gravando = False
transcricao_ativa_runtime = True
inicio_gravacao = None
gravacao_completa = None  # caminho do arquivo completo que o OBS gravou
linhas = []
cortes = []
obs_req = None            # cliente de request do OBS (pra disparar replay)
obs_conectado = False     # OBS WebSocket conectou com sucesso?

texto_desde_ia = []       # acumula linhas ate a proxima analise da IA
texto_contexto_ia = []     # janela movel maior para Gemini entender o assunto antes de cortar
ultima_ia = 0

# Sinais simples de presença/volume da fala para reforçar cortes emocionais.
volume_historico = []
volume_picos = {}

# Fila de clipes que pediram save mas ainda nao terminaram (pra renomear depois).
# Cada item: {"titulo","timestamp","inicio","fim"}
clipes_pendentes = queue.Queue()

# Pastas principais da sessão
pasta_cortes_ao_vivo = None
pasta_cortes_finais = None

# ----------------------------- AUDIO / TEMPO -----------------------------

stream_audio = None  # o InputStream atual
audio_status_atual = {"ok": False, "nome": "não iniciado", "rms": 0.0, "msg": "aguardando áudio"}
vps_status_atual = {"ok": True, "modo": "local", "msg": "MLX local/offline", "url": ""}
ultimo_status_audio_envio = 0
ultimo_status_vps_envio = 0

# Fonte de audio ativa: "dispositivo" (seletor local) ou "plugin" (mixer do OBS)
fonte_audio = "dispositivo"
plugin_conectado = False

def parse_audio_plugin(data):
    """
    Decodifica o pacote binario do obs-audio-to-websocket.
    Cabecalho de 28 bytes (little-endian), depois strings, depois PCM 16-bit.
    Devolve (audio_float32_mono, sample_rate) ou (None, None) se invalido.
    """
    import struct
    try:
        if len(data) < 28:
            return None, None
        off = 0
        # timestamp(8) sample_rate(4) channels(4) bit_depth(4) idLen(4) nameLen(4)
        _ts = struct.unpack_from("<Q", data, off)[0]; off += 8
        sr = struct.unpack_from("<I", data, off)[0]; off += 4
        ch = struct.unpack_from("<I", data, off)[0]; off += 4
        _bd = struct.unpack_from("<I", data, off)[0]; off += 4
        id_len = struct.unpack_from("<I", data, off)[0]; off += 4
        nm_len = struct.unpack_from("<I", data, off)[0]; off += 4
        off += id_len + nm_len  # pula as strings de id e nome da fonte
        pcm = data[off:]
        if not pcm:
            return None, None
        amostras = np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768.0
        if ch == 2:  # estereo interleaved -> mono
            amostras = amostras.reshape(-1, 2).mean(axis=1)
        return amostras, sr
    except Exception as e:
        print(f"[plugin] pacote invalido: {e}")
        return None, None

def reamostrar(audio, sr_origem, sr_destino):
    """Reamostragem linear simples (sem dependencia extra) pro ASR (16kHz)."""
    if sr_origem == sr_destino or len(audio) == 0:
        return audio
    razao = sr_destino / sr_origem
    n_novo = int(len(audio) * razao)
    if n_novo <= 0:
        return audio
    idx = np.linspace(0, len(audio) - 1, n_novo)
    return np.interp(idx, np.arange(len(audio)), audio).astype(np.float32)

def preparar_audio_whisper(audio):
    """Limpa e nivela o bloco antes de transcrever.
    Ajuda muito quando o audio vem baixo do OBS/BlackHole ou com DC offset.
    """
    if audio is None or len(audio) == 0:
        return audio
    audio = audio.astype(np.float32)
    audio = audio - float(np.mean(audio))
    rms = float(np.sqrt(np.mean(audio * audio)) + 1e-9)
    pico = float(np.max(np.abs(audio)) + 1e-9)

    # Se o audio estiver baixo, sobe o nivel sem estourar.
    # Mantem limite conservador para nao distorcer a voz.
    if rms < 0.045:
        ganho = min(6.0, 0.075 / rms)
        audio = audio * ganho

    pico = float(np.max(np.abs(audio)) + 1e-9)
    if pico > 0.98:
        audio = audio / pico * 0.98
    return np.clip(audio, -1.0, 1.0).astype(np.float32)



def audio_para_wav_bytes(audio, sample_rate=16000):
    """Converte float32 mono [-1,1] para WAV 16-bit em memoria."""
    audio = np.asarray(audio, dtype=np.float32)
    audio = np.clip(audio, -1.0, 1.0)
    pcm = (audio * 32767.0).astype('<i2')
    bio = io.BytesIO()
    with wave.open(bio, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(int(sample_rate))
        wf.writeframes(pcm.tobytes())
    bio.seek(0)
    return bio.getvalue()


def _vps_url(endpoint=None):
    """Monta URL da VPS. v74 bloqueia /transcribe porque ele alucinou/ecoou prompt."""
    allowed = ("/transcribe-fastwhisper",)
    old_ep = "/transcribe-" + "funasr"
    if endpoint is None:
        explicit = config_usuario.get('whisper_vps_url') or CONFIG.get('whisper_vps_url')
        if explicit:
            explicit = str(explicit).replace(old_ep, "/transcribe-fastwhisper")
            if explicit.endswith(allowed):
                return explicit
        endpoint = config_usuario.get('whisper_vps_endpoint') or CONFIG.get('whisper_vps_endpoint', '/transcribe-fastwhisper')
    base = (config_usuario.get('whisper_vps_base_url') or CONFIG.get('whisper_vps_base_url') or '').rstrip('/')
    endpoint = str(endpoint or '').strip().replace(old_ep, "/transcribe-fastwhisper")
    if endpoint.startswith('http://') or endpoint.startswith('https://'):
        if endpoint.endswith(old_ep):
            endpoint = endpoint.replace(old_ep, "/transcribe-fastwhisper")
        if endpoint.endswith(allowed):
            return endpoint
        return base + "/transcribe-fastwhisper" if base else "http://2.25.157.230:8000/transcribe-fastwhisper"
    if not endpoint.startswith('/'):
        endpoint = '/' + endpoint
    if endpoint not in allowed:
        endpoint = '/transcribe-fastwhisper'
    return base + endpoint

def _vps_headers(extra_plain=False):
    token = config_usuario.get('whisper_vps_token') or CONFIG.get('whisper_vps_token')
    header_name = config_usuario.get('vps_auth_header') or CONFIG.get('vps_auth_header', 'x-api-key')
    headers = {}
    if token:
        # Header obrigatorio da VPS OBS ASR + IA.
        headers[str(header_name)] = token
        # Compatibilidade opcional com builds antigos. A VPS atual usa x-api-key.
        if extra_plain:
            headers['x-api-key'] = token
            headers['Authorization'] = f'Bearer {token}'
            headers['X-API-Key'] = token
            headers['X-FrameZero-Key'] = token
    return headers


def _extrair_transcricao_vps(resp):
    """Aceita respostas da fase 1 e também formatos comuns de APIs ASR."""
    if not isinstance(resp, dict):
        return str(resp or '').strip(), []
    texto = (resp.get('text') or resp.get('texto') or resp.get('transcription') or
             resp.get('transcricao') or resp.get('result') or resp.get('resultado') or '').strip()
    segmentos = resp.get('segments') or resp.get('segmentos') or resp.get('chunks') or []
    if not texto and isinstance(segmentos, list):
        texto = ' '.join(str(x.get('text') or x.get('texto') or '').strip() for x in segmentos if isinstance(x, dict)).strip()
    return texto, segmentos if isinstance(segmentos, list) else []


def _poll_job_vps(job_id):
    """Suporte futuro para Fase 2: /jobs/{id} com status em background."""
    if not job_id or not config_usuario.get('vps_poll_jobs', CONFIG.get('vps_poll_jobs', True)):
        return '', []
    import time as _time
    jobs_ep = config_usuario.get('whisper_vps_jobs_endpoint') or CONFIG.get('whisper_vps_jobs_endpoint', '/jobs')
    url = _vps_url(str(jobs_ep).rstrip('/') + '/' + str(job_id))
    timeout_total = float(config_usuario.get('vps_job_timeout_seg', CONFIG.get('vps_job_timeout_seg', 180)))
    deadline = _time.time() + timeout_total
    while _time.time() < deadline:
        r = requests.get(url, headers=_vps_headers(True), timeout=15)
        r.raise_for_status()
        data = r.json()
        status = str(data.get('status') or data.get('estado') or '').lower()
        if status in ('concluido', 'concluído', 'completed', 'done', 'ok', 'success') or data.get('text') or data.get('texto') or data.get('segments'):
            return _extrair_transcricao_vps(data)
        if status in ('erro', 'error', 'failed', 'falhou'):
            raise RuntimeError(f"job VPS falhou: {data}")
        _time.sleep(2.0)
    raise TimeoutError('timeout aguardando job da VPS atual')


def transcrever_vps(audio):
    """Envia um bloco WAV para a VPS atual e devolve (texto, segmentos).
    Compatível com a API OBS faster-whisper:
      POST /transcribe multipart/form-data campo file
      retorno: {text/texto, segments/segmentos}
    Também já suporta uma futura Fase 2 com job_id + /jobs/{id}.
    """
    if requests is None:
        raise RuntimeError("biblioteca requests nao instalada")
    url = _vps_url()
    if not url:
        raise RuntimeError("whisper_vps_url/base_url nao configurada")

    wav = audio_para_wav_bytes(audio, CONFIG['sample_rate'])
    files = {'file': ('framezero_live.wav', wav, 'audio/wav')}
    data = {
        'language': whisper_language_atual(),
        'task': 'transcribe',
        'format': 'json',
        'timestamps': 'true',
        'source': 'framezero_obs',
        'engine': config_usuario.get('transcription_engine', CONFIG.get('transcription_engine', 'whisper')),
    }
    timeout = float(config_usuario.get('vps_timeout_seg', CONFIG.get('vps_timeout_seg', 60)))
    r = requests.post(url, headers=_vps_headers(False), files=files, data=data, timeout=timeout)
    if r.status_code in (401, 403):
        # tenta outro formato comum de token antes de desistir
        r = requests.post(url, headers=_vps_headers(True), files=files, data=data, timeout=timeout)
    r.raise_for_status()

    try:
        resp = r.json()
    except Exception:
        txt = (r.text or '').strip()
        return txt, []

    # Fase 2: se a API devolver job_id em vez do texto na hora, o cliente já sabe aguardar.
    job_id = resp.get('job_id') or resp.get('id') if isinstance(resp, dict) else None
    status = str(resp.get('status') or resp.get('estado') or '').lower() if isinstance(resp, dict) else ''
    if job_id and status in ('aguardando', 'queued', 'processando', 'processing', 'pending'):
        return _poll_job_vps(job_id)

    return _extrair_transcricao_vps(resp)


def testar_vps_whisper():
    """Teste leve opcional. Nao trava se /health ainda nao existir na Fase 1."""
    if requests is None:
        return False, 'requests nao instalado'
    health = config_usuario.get('whisper_vps_health_endpoint') or CONFIG.get('whisper_vps_health_endpoint', '/health')
    try:
        r = requests.get(_vps_url(health), headers=_vps_headers(True), timeout=5)
        if r.status_code == 404:
            return True, 'API sem /health ainda, usando /transcribe-fastwhisper'
        r.raise_for_status()
        try:
            data = r.json()
            modelo = data.get('deepseek_model') or data.get('model') or data.get('modelo') or ''
            whisper = data.get('whisper') or ''
            whisper = data.get('whisper') or data.get('engine') or data.get('transcription_engine') or ''
            msg = 'VPS online'
            if modelo:
                msg += f' • IA: {modelo}'
            if whisper:
                msg += f' • Whisper: {whisper}'
            if whisper:
                msg += f' • Whisper: {whisper}'
            return True, msg
        except Exception:
            return True, 'VPS online'
    except Exception as e:
        return False, str(e)


def _parse_json_possivel(valor):
    """A API /analyze-text pode devolver analysis como string contendo JSON.
    Esta função tenta limpar markdown/think tags e transformar em dict.
    """
    if isinstance(valor, (dict, list)):
        return valor
    if valor is None:
        return None
    txt = str(valor).strip()
    if not txt:
        return None
    # remove blocos markdown e tags de raciocinio que modelos locais às vezes retornam
    txt = re.sub(r"```(?:json)?", "", txt, flags=re.I).replace("```", "").strip()
    txt = re.sub(r"<think>.*?</think>", "", txt, flags=re.I|re.S).strip()
    try:
        return json.loads(txt)
    except Exception:
        pass
    # tenta extrair o maior objeto JSON dentro do texto
    ini = txt.find('{'); fim = txt.rfind('}')
    if ini >= 0 and fim > ini:
        try:
            return json.loads(txt[ini:fim+1])
        except Exception:
            return None
    return None



def _parse_analysis_texto_livre(txt, t_ref=0, texto_base=""):
    """A VPS pode retornar analysis como texto simples:
    Título: ...\nHook: ...\nMotivo: ...\nScore: ...\nLegenda: ...\nCapa: ...
    Transforma isso em um corte padrao.
    """
    txt = str(txt or "").strip()
    if not txt:
        return None
    def campo(nomes):
        for nome in nomes:
            m = re.search(rf"(?im)^\s*{nome}\s*[:\-]\s*(.+)$", txt)
            if m:
                return m.group(1).strip()
        return ""
    score_txt = campo(["Score", "Pontuação", "Pontuacao"])
    mscore = re.search(r"\d{1,3}", score_txt or txt)
    score = int(mscore.group(0)) if mscore else 0
    if score <= 0:
        # Se a IA respondeu texto útil mas sem score, não cria corte automático.
        return None
    titulo = campo(["Título", "Titulo", "Title"]) or titulo_local(texto_base or txt, "fé", "impacto")
    hook = campo(["Hook", "Gancho"])
    motivo = campo(["Motivo", "Reason", "Razão", "Razao"]) or "análise da IA local da VPS"
    legenda = campo(["Legenda", "Caption", "Suggested caption"])
    capa = campo(["Capa", "Cover"])
    return {
        "trecho": hook or (texto_base[:260] if texto_base else txt[:260]),
        "score": max(0, min(score, 100)),
        "titulo": titulo,
        "razao": motivo,
        "emocao": "fé",
        "funcao": "viral/emocional",
        "tempo": float(t_ref or 0),
        "suggested_caption": legenda,
        "hook": hook,
        "capa": capa,
    }

def _normalizar_cortes_vps(data, t_ref=0, texto_base=""):
    """Aceita formatos atuais/futuros da VPS e devolve lista padrão de cortes."""
    if not data:
        return []
    if isinstance(data, str):
        data = _parse_json_possivel(data)
    if not isinstance(data, dict):
        return []

    # /analyze-text atual pode ser:
    # {success, analysis:{...}} OU {success, analysis:"JSON"} OU {success, analysis:"Título: ... Score: ..."}
    if 'analysis' in data:
        valor_analysis = data.get('analysis')
        analisado = _parse_json_possivel(valor_analysis)
        if isinstance(analisado, dict):
            data = analisado
        else:
            corte_txt = _parse_analysis_texto_livre(valor_analysis, t_ref, texto_base)
            if corte_txt:
                return [corte_txt]

    bruto = data.get('cuts') or data.get('cortes') or data.get('moments') or data.get('momentos') or []
    # /analyze-live-chunk futuro pode devolver um único corte
    if not bruto and any(k in data for k in ('is_good_cut','score','title','titulo','hook')):
        if data.get('is_good_cut', True):
            bruto = [data]
    if isinstance(bruto, dict):
        bruto = [bruto]
    if not isinstance(bruto, list):
        return []

    out=[]
    for c in bruto:
        if not isinstance(c, dict):
            continue
        score = c.get('score') or c.get('viral_score') or c.get('pontuacao') or 0
        try: score = int(float(score))
        except Exception: score = 0
        if score <= 0:
            continue
        trecho = (c.get('trecho') or c.get('text') or c.get('texto') or c.get('quote') or c.get('hook') or texto_base[:260]).strip()
        titulo = (c.get('title') or c.get('titulo') or c.get('suggested_title') or c.get('sugestao_titulo') or titulo_local(trecho, c.get('emocao','fé'), c.get('funcao','impacto'))).strip()
        razao = (c.get('reason') or c.get('motivo') or c.get('razao') or c.get('razão') or 'análise da IA local da VPS').strip()
        emocao = (c.get('emotion') or c.get('emocao') or c.get('emoção') or 'fé').strip()
        funcao = (c.get('function') or c.get('funcao') or c.get('função') or c.get('narrative_function') or 'impacto').strip()
        ts = c.get('start_time') or c.get('inicio') or c.get('inicio_seg') or c.get('tempo') or t_ref
        try: ts = float(ts)
        except Exception: ts = float(t_ref or 0)
        # se veio tempo relativo ao bloco, soma t_ref quando fizer sentido
        if ts < 10 and t_ref > 10:
            ts = float(t_ref) + ts
        out.append({
            'trecho': trecho,
            'score': score,
            'titulo': titulo,
            'razao': razao,
            'emocao': emocao,
            'funcao': funcao,
            'tempo': ts,
            'suggested_caption': c.get('suggested_caption') or c.get('caption') or c.get('legenda') or '',
            'hook': c.get('hook') or ''
        })
    return out


PROMPT_GEMINI_CORTE = """Você é um diretor de edição de cortes para redes sociais em português brasileiro, especializado em pregação, culto, podcast e entrevista.

Sua função NÃO é transcrever. Você recebe texto já transcrito e decide se existe UM corte útil para post, Reels, TikTok ou Shorts.

REGRA PRINCIPAL DA v81e-score60:
- O limite/rating de corte em tempo real é 60+.
- Se algum trecho tiver score 60 ou mais, retorne clip_ready.
- Não espere score 90. Score 90+ é raro; score 60-69 já pode ser um corte simples, de contexto, gancho ou história.
- Não seja rígido demais: corte bom para rede social nem sempre tem conclusão teológica completa; pode ser uma abertura curiosa, uma ilustração, uma história, uma pergunta ou o começo de um assunto interessante.

Critérios para aceitar score 60+:
- Faz sentido sozinho para quem não viu o vídeo completo OU apresenta claramente um assunto/história.
- Tem começo compreensível e uma ideia central clara.
- Pode virar post por curiosidade, identificação, humor, ensino, exemplo, história, autoridade, emoção ou gancho.
- Exemplo válido: uma fala sobre pessoas persistentes, negociação, barganha, 25 de Março, ou uma ilustração cotidiana que prepara uma mensagem. Isso deve virar corte 60-75, mesmo antes da aplicação final.

Critérios para NÃO cortar:
- Só boas-vindas, repetição de capítulo/versículo, microfrase solta ou ruído de transcrição.
- Trecho confuso sem assunto claro.
- Continuação que começa no meio de uma ideia sem contexto.

Regras de duração:
- Prefira cortes de 20 a 60 segundos.
- Pode sugerir até 75 segundos se for o mesmo assunto.
- Se tiver uma janela de 30-60s com ideia clara e score 60+, retorne clip_ready.
- Use wait_more apenas quando NÃO existir nenhum trecho aproveitável com score 60+.

Escala de score:
- 60-69: corte aproveitável/simples, bom gancho, contexto ou história.
- 70-79: bom corte para post.
- 80-89: corte forte.
- 90-95: corte excepcional.

Responda APENAS em JSON válido, sem markdown.

Formatos aceitos:
1) Sem corte aproveitável:
{"status":"ignore","reason":"trecho sem assunto claro ou só boas-vindas/repetição","cortes":[]}

2) Possível corte, mas ainda incompleto e abaixo de 60:
{"status":"wait_more","reason":"tema começou, mas ainda não existe corte aproveitável 60+","topic":"tema detectado","suggested_wait_seconds":30,"cortes":[]}

3) Corte pronto:
{"status":"clip_ready","cortes":[{"trecho":"trecho exato completo","score":60,"titulo":"título curto","razao":"por que esse trecho já serve para post","emocao":"emoção","funcao":"gancho|aplicacao|virada|climax|historia|ensino|contexto","inicio_relativo":0,"fim_relativo":60,"mesmo_assunto":true,"frases_de_impacto":["frase forte do trecho"],"versiculos":["Lucas 18"]}]}

4) Deve juntar com trecho anterior:
{"status":"merge_previous","cortes":[{"trecho":"trecho completo juntando o assunto","score":60,"titulo":"título curto","razao":"motivo","inicio_relativo":0,"fim_relativo":75,"mesmo_assunto":true,"frases_de_impacto":["frase forte do trecho"],"versiculos":["referência bíblica citada, se houver"]}]}

Sempre que possível, preencha:
- frases_de_impacto: 1 a 5 frases fortes, compartilháveis ou chamativas dentro do próprio corte.
- versiculos: referências bíblicas citadas ou claramente usadas no trecho, como "Lucas 18", "João 3:16", "Salmo 23". Se não houver, use lista vazia.
"""

def _extrair_json_obj(txt):
    bruto = str(txt or "").strip()
    if not bruto:
        return {}
    bruto = re.sub(r"^```(?:json)?\s*", "", bruto, flags=re.I).strip()
    bruto = re.sub(r"\s*```$", "", bruto).strip()
    try:
        return json.loads(bruto)
    except Exception:
        m = re.search(r"\{.*\}", bruto, flags=re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                return {}
    return {}

def analisar_com_gemini(texto, t_ref=0, t_fim=None):
    """Gemini API Free como cérebro de cortes: analisa contexto acumulado e sugere cortes virais.
    Não transcreve áudio. Só avalia texto já transcrito, para economizar cota/créditos.
    """
    if requests is None:
        return None
    if not bool(config_usuario.get("gemini_enabled", CONFIG.get("gemini_enabled", False))):
        return None
    chave = str(config_usuario.get("gemini_api_key", CONFIG.get("gemini_api_key", "")) or "").strip()
    if not chave:
        return None
    texto = limpar_texto_transcricao(texto)
    if len(texto) < int(config_usuario.get("gemini_min_chars", CONFIG.get("gemini_min_chars", 1200))):
        return []
    modelo = str(config_usuario.get("gemini_model", CONFIG.get("gemini_model", "gemini-2.5-flash-lite"))).strip() or "gemini-2.5-flash-lite"
    max_chars = int(config_usuario.get("gemini_max_chars", CONFIG.get("gemini_max_chars", 9000)) or 9000)
    timeout = float(config_usuario.get("gemini_timeout_seg", CONFIG.get("gemini_timeout_seg", 35.0)))
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent?key={chave}"
    tipo_conteudo = tipo_conteudo_atual(texto)
    limiar_atual = current_limiar()
    instrucoes_rodada = (
        f"\n\nLIMIAR DESTA RODADA: score {limiar_atual}+. "
        f"Qualquer corte com score >= {limiar_atual} deve ser retornado como clip_ready. "
        "Não responda wait_more se já existir um gancho, história, exemplo ou assunto aproveitável para post."
    )
    payload = {
        "contents": [{"role":"user", "parts":[{"text": prompt_global_cortes() + "\n\n" + PROMPT_GEMINI_CORTE + instrucoes_rodada + "\n\nTipo provável: " + tipo_conteudo + "\nIdioma/perfil: " + perfil_id_atual() + " / saída: " + ai_language_atual() + "\nJanela: " + fmt(t_ref) + " até " + fmt(t_fim or t_ref) + "\n\nTRANSCRIÇÃO:\n" + texto[-max_chars:]}]}],
        "generationConfig": {
            "temperature": 0.2,
            "topP": 0.85,
            "maxOutputTokens": 1100,
            "responseMimeType": "application/json"
        }
    }
    try:
        r = requests.post(url, headers={"Content-Type":"application/json"}, json=payload, timeout=timeout)
        if r.status_code in (400,401,403):
            print(f"[gemini] chave/conta recusada ({r.status_code}). Confira a chave no painel.")
            return None
        if r.status_code == 429:
            print("[gemini] limite da chave atingido. Usando detector local nesta rodada.")
            return None
        r.raise_for_status()
        data = r.json()
        text_out = ""
        try:
            cand = data.get("candidates", [])[0]
            parts = cand.get("content", {}).get("parts", [])
            text_out = "\n".join(str(x.get("text", "")) for x in parts if x.get("text"))
        except Exception:
            text_out = ""
        obj = _extrair_json_obj(text_out)
        status = str(obj.get("status", "") if isinstance(obj, dict) else "").strip().lower()
        cortes = obj.get("cortes", []) if isinstance(obj, dict) else []
        # Alguns modelos respondem wait_more, mas ainda devolvem um corte 60+.
        # Na v81e-score60, se veio corte com rating suficiente, processamos mesmo assim.
        if status in ("ignore", "wait_more") and not cortes:
            if status == "wait_more":
                print(f"[gemini] aguardando mais contexto: {obj.get('reason') or obj.get('razao') or obj.get('topic') or ''}")
            return []
        if not cortes and status in ("clip_ready", "merge_previous") and isinstance(obj, dict):
            cortes = [obj]
        norm = []
        for c in cortes[:2]:
            try:
                score = int(float(c.get("score", 0)))
            except Exception:
                score = 0
            # Gemini só reforça corte bom. Não deixa score inflado virar 100 fácil.
            if score >= 98:
                score = 95
            if score < 60:
                continue
            trecho = str(c.get("trecho") or "").strip()
            if len(trecho) < 30:
                continue
            ts = c.get("inicio_relativo", c.get("inicio", c.get("tempo", 0)))
            try: ts = float(ts)
            except Exception: ts = 0.0
            if ts < 120:
                ts = float(t_ref or 0) + ts
            norm.append({
                "trecho": trecho,
                "score": score,
                "titulo": str(c.get("titulo") or titulo_local(trecho, c.get("emocao","fé"), c.get("funcao","impacto"))).strip(),
                "razao": str(c.get("razao") or "Gemini analisou contexto e potencial viral.").strip(),
                "emocao": str(c.get("emocao") or "fé").strip(),
                "funcao": str(c.get("funcao") or "impacto").strip(),
                "tempo": ts,
                "frases_de_impacto": c.get("frases_de_impacto") or c.get("frases_impacto") or c.get("frase_impacto") or c.get("impact_phrases") or [],
                "versiculos": c.get("versiculos") or c.get("versiculos_biblicos") or c.get("referencias_biblicas") or c.get("bible_verses") or [],
            })
        if norm:
            print(f"[gemini] {len(norm)} candidato(s) forte(s) encontrados.")
        return norm
    except Exception as e:
        if not globals().get('_avisou_gemini_falha', False):
            globals()['_avisou_gemini_falha'] = True
            print(f"[gemini] indisponível. Usando detector local: {e}")
        return None


def analisar_com_vps(texto, t_ref=0, t_fim=None):
    """Usa a IA local da VPS via /analyze-text para sugerir cortes.
    Retorna lista de cortes normalizada ou None quando falhar.
    """
    if requests is None:
        return None
    if not config_usuario.get('vps_analisar_com_ia_local', CONFIG.get('vps_analisar_com_ia_local', True)):
        return None
    texto = limpar_texto_transcricao(texto)
    min_chars = int(config_usuario.get('vps_analyze_min_chars', CONFIG.get('vps_analyze_min_chars', 220)))
    if len(texto) < min_chars:
        return []
    timeout = float(config_usuario.get('vps_analyze_timeout_seg', CONFIG.get('vps_analyze_timeout_seg', 60)))

    # Endpoint futuro recomendado no README. Mantido desligado por padrão.
    if config_usuario.get('vps_tentar_analyze_live_chunk', CONFIG.get('vps_tentar_analyze_live_chunk', False)):
        try:
            ep_live = config_usuario.get('vps_analyze_live_endpoint', CONFIG.get('vps_analyze_live_endpoint', '/analyze-live-chunk'))
            tipo_conteudo = tipo_conteudo_atual(texto)
            payload = {"start_time": float(t_ref or 0), "end_time": float(t_fim or t_ref or 0), "text": texto, "content_type": tipo_conteudo}
            r = requests.post(_vps_url(ep_live), headers={**_vps_headers(True), 'Content-Type':'application/json'}, json=payload, timeout=timeout)
            if r.status_code != 404:
                r.raise_for_status()
                return _normalizar_cortes_vps(r.json(), t_ref, texto)
        except Exception as e:
            print(f"[vps-ia] analyze-live-chunk falhou, usando analyze-text: {e}")

    try:
        ep = config_usuario.get('whisper_vps_analyze_endpoint', CONFIG.get('whisper_vps_analyze_endpoint', '/analyze-text'))
        tipo_conteudo = tipo_conteudo_atual(texto)
        if tipo_conteudo == "musica":
            usar_letra_online = bool(config_usuario.get("musica_usar_letra_online", CONFIG.get("musica_usar_letra_online", True)))
            contexto_ia = "culto cristao brasileiro; trecho identificado como musica/louvor; priorizar refrao, ponte, climax emocional, partes bonitas e frases cantaveis; nao exigir aplicacao de pregacao"
            if usar_letra_online:
                contexto_ia += "; Ollama/VPS tem acesso a internet: pode buscar letra semelhante online para entender o que esta sendo cantado, mas a internet apenas sugere; o audio/transcricao manda"
            regras_ia = {
                "content_type": "musica",
                "prefer_chorus": True,
                "prefer_bridge": True,
                "prefer_emotional_peak": True,
                "min_score_for_cut": 80,
                "strong_cut_score": 90,
                "allow_web_search": usar_letra_online,
                "internet_connected": bool(config_usuario.get("ollama_internet_conectado", CONFIG.get("ollama_internet_conectado", True))),
                "lyrics_reference_online": usar_letra_online,
                "lyrics_reference_policy": "internet_sugere_audio_manda",
                "do_not_replace_if_low_confidence": True,
                "minimum_lyrics_confidence": float(config_usuario.get("musica_confianca_minima_letra", CONFIG.get("musica_confianca_minima_letra", 0.82))),
                "preserve_spontaneous_worship": True,
                "do_not_invent_lyrics": True,
                "do_not_output_audio_labels": True
            }
        else:
            contexto_ia = "pregacao crista brasileira; priorizar palavra direcionada, aplicacao e contexto fechado; nao sugerir corte que termine no meio de historia ou frase"
            regras_ia = {"content_type": "pregacao", "avoid_unfinished_story": True, "prefer_direct_word": True, "min_score_for_cut": 80, "strong_cut_score": 90}
        payload = {"text": texto, "start_time": float(t_ref or 0), "end_time": float(t_fim or t_ref or 0),
                   "content_type": tipo_conteudo, "context": contexto_ia, "rules": regras_ia}
        if tipo_conteudo == "musica":
            payload.update({
                "mode": "music_lyrics_refinement",
                "allow_web_search": bool(config_usuario.get("musica_usar_letra_online", CONFIG.get("musica_usar_letra_online", True))),
                "internet_connected": bool(config_usuario.get("ollama_internet_conectado", CONFIG.get("ollama_internet_conectado", True))),
                "lyrics_reference_source": config_usuario.get("lyrics_reference_source", CONFIG.get("lyrics_reference_source", "web_via_ollama_vps")),
                "lyrics_reference_policy": "internet_sugere_audio_manda",
                "minimum_lyrics_confidence": float(config_usuario.get("musica_confianca_minima_letra", CONFIG.get("musica_confianca_minima_letra", 0.82))),
                "preserve_spontaneous_worship": True,
                "instructions": [
                    "Procure letra online apenas como referencia quando o trecho parecer musica/louvor.",
                    "Nao substitua a legenda se a confianca for baixa.",
                    "Nao copie letra inteira; use apenas para corrigir palavras provaveis do trecho cantado.",
                    "Se for espontaneo ou improvisado, preserve o que foi ouvido.",
                    "Nunca escreva marcadores como Musica, Louvor ou Instrumental no SRT."
                ]
            })
        r = requests.post(_vps_url(ep), headers={**_vps_headers(True), 'Content-Type':'application/json'}, json=payload, timeout=timeout)
        if r.status_code == 404:
            # Nem toda VPS tem /analyze-text ainda. Nao deixar isso poluir o terminal
            # nem parecer erro para o usuario: cai no detector local automaticamente.
            if not globals().get('_avisou_analyze_404', False):
                globals()['_avisou_analyze_404'] = True
                print("[vps-ia] /analyze-text nao existe nesta VPS. Usando detector local de cortes sem IA da VPS.")
            return None
        r.raise_for_status()
        return _normalizar_cortes_vps(r.json(), t_ref, texto)
    except Exception as e:
        if not globals().get('_avisou_analyze_falha', False):
            globals()['_avisou_analyze_falha'] = True
            print(f"[vps-ia] indisponivel. Usando detector local de cortes: {e}")
        return None



def modelo_mlx_atual():
    perfil = str(config_usuario.get("whisper_local_perfil", CONFIG.get("whisper_local_perfil", "leve"))).lower().strip()
    if perfil == "pro":
        return config_usuario.get("whisper_local_modelo_pro", CONFIG.get("whisper_local_modelo_pro", "mlx-community/whisper-large-v3"))
    return config_usuario.get("whisper_local_modelo_leve", CONFIG.get("whisper_local_modelo_leve", "mlx-community/whisper-large-v3-turbo"))

class SegmentoASR:
    def __init__(self, start, end, text):
        self.start = float(start or 0)
        self.end = float(end or 0)
        self.text = text or ""

def prompt_transcricao_atual():
    """Prompt mínimo para o ASR conforme o idioma escolhido no Modo Global.
    Não usamos modo automático: o painel define o perfil de idioma.
    Prompts longos podem vazar para a legenda, então o prompt é curto.
    """
    tipo = str(config_usuario.get("tipo_conteudo", CONFIG.get("tipo_conteudo", "pregacao"))).lower()
    perfil = perfil_idioma_atual()
    lang = ai_language_atual()
    if tipo == "musica":
        return None
    return f"{lang}. Christian sermon. Bible references. Pastor speaking."


def limpar_tags_asr(txt):
    """Remove tags internas de ASR antigo que não podem aparecer em legenda."""
    t = str(txt or "")
    # Formatos reais: <|en|>, < | en | >, <|EMO_UNKNOWN|>, < | S pe ech | > etc.
    t = re.sub(r"<\s*\|[^>]{0,80}\|\s*>", " ", t)
    t = re.sub(r"<\s*\|?\s*(?:en|zh|ja|ko|yue|pt|EMO[_\s-]*UNKNOWN|Speech|S\s*pe\s*ech|withitn|withi\s*tn)\s*\|?\s*>", " ", t, flags=re.I)
    t = re.sub(r"\b(?:EMO\s*_\s*UNKNOWN|S\s*pe\s*ech|withi\s*tn|Speech)\b", " ", t, flags=re.I)
    return re.sub(r"\s+", " ", t).strip()

def texto_whisper_invalido(txt, origem="local"):
    """Bloqueia lixo de ASR antes de virar SRT/corte.

    MLX Whisper local em chunks curtos pode alucinar inglês, japonês/chinês
    ou palavras quebradas como "N oji io C to". Em PT-BR isso nunca deve virar
    legenda nem acionar corte.
    """
    raw = str(txt or "")
    if not raw.strip():
        return True

    # Tags internas de ASR antigo ou pedaços delas.
    if re.search(r"<\s*\|", raw) or re.search(r"EMO\s*_\s*UNKNOWN|S\s*pe\s*ech|withi\s*tn|Speech", raw, re.I):
        return True

    # Caracteres CJK/Japonês/Koreano quase sempre são alucinação neste fluxo PT-BR.
    if re.search(r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uac00-\ud7af]", raw):
        return True

    limpo = limpar_tags_asr(raw).strip()
    if len(limpo) < 3:
        return True

    # Regras anti-lixo muito agressivas foram criadas para PT-BR.
    # No Modo Global, para idiomas diferentes de português, mantemos apenas os bloqueios universais
    # acima (tags internas, CJK indevido, texto vazio) para não descartar inglês/espanhol/etc.
    if whisper_language_atual() not in ("pt", "pt-BR", "pt-PT"):
        return False

    low = limpo.lower()
    norm_low = _norm(limpo)

    # Se o ASR repetir instrução/prompt do sistema, descarta.
    if ("o audio e de uma pregacao" in norm_low or
        "culto podcast ou aula biblica" in norm_low or
        "transcricao fiel em portugues brasileiro" in norm_low or
        "nao invente palavras" in norm_low or
        "nao traduza" in norm_low):
        return True

    # Padrões reais vistos no Mac: letras soltas e sílabas sem sentido.
    if re.search(r"\b[a-z]\s+[a-z]{1,4}\s+[a-z]{1,4}\s+[a-z]\s+[a-z]{1,4}\b", low, re.I):
        return True

    tokens = re.findall(r"[A-Za-zÀ-ÿ]+", limpo)
    if tokens:
        single = [w for w in tokens if len(w) == 1]
        short = [w for w in tokens if len(w) <= 3]
        long_words = [w for w in tokens if len(w) >= 11]

        # Ex.: "N oji io C to", "C ont do H esh pe".
        if len(tokens) <= 8 and (len(single) >= 2 or len(short) >= max(3, len(tokens)-1)):
            return True

        portugues_sinais = re.findall(r"\b(que|de|do|da|dos|das|não|nao|você|voce|pra|para|com|uma|um|ele|ela|deus|senhor|jesus|gente|agora|aqui|ali|porque|então|entao|família|familia|igreja|vida|hoje|quando|meu|minha|nosso|nossa)\b", low)
        ingles_sinais = re.findall(r"\b(the|and|but|with|within|now|home|give|failed|simple|day|their|shot|speech|recommendations|recommendation|philosophy|philosophysopher|cont|esh|inch|gsc)\b", low)
        lixo_sinais = re.findall(r"\b(oji|philosophysopher|recommendations|gsc|inch|esh|withitn|spech|hesh|tepi)\b", low)

        if lixo_sinais:
            return True
        if len(ingles_sinais) >= 1 and len(portugues_sinais) == 0 and len(tokens) <= 10:
            return True
        if long_words and len(portugues_sinais) == 0 and len(tokens) <= 6:
            return True

        # Texto quase todo ASCII/inglês sem nenhuma palavra portuguesa comum em PT-BR.
        tem_acento = bool(re.search(r"[áàâãéêíóôõúçÁÀÂÃÉÊÍÓÔÕÚÇ]", limpo))
        if not tem_acento and len(portugues_sinais) == 0 and len(tokens) <= 7:
            # Bloqueia frases curtas sem cara de português.
            vogais_pt = sum(1 for c in low if c in "aeiouáàâãéêíóôõú")
            if len(tokens) >= 2 and vogais_pt <= max(2, len("".join(tokens)) * 0.35):
                return True

    # Repetição curta sem sentido.
    if re.fullmatch(r"(?:[A-Za-z]{1,4}\s*){1,8}[.,!?]?", limpo) and len(limpo.split()) <= 8:
        return True
    return False

def _wav_temp_from_audio(audio):
    audio = preparar_audio_whisper(audio).astype(np.float32)
    wav_path = tempfile.NamedTemporaryFile(delete=False, suffix=".wav").name
    pcm = np.clip(audio, -1.0, 1.0)
    pcm16 = (pcm * 32767.0).astype(np.int16)
    with wave.open(wav_path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(int(CONFIG.get("sample_rate", 16000)))
        wf.writeframes(pcm16.tobytes())
    return wav_path, audio

def _transcrever_faster(modelo, audio):
    if not TEM_FASTER_WHISPER or WhisperModel is None:
        raise RuntimeError("faster-whisper não instalado no Windows.")
    audio = preparar_audio_whisper(audio).astype(np.float32)
    idioma = whisper_language_atual()
    model_name = "small"
    if isinstance(modelo, dict):
        model_name = modelo.get("modelo") or modelo.get("model") or model_name
    # Cache simples do modelo para evitar recarregar a cada bloco.
    global _FASTER_MODEL_CACHE
    try:
        cache = _FASTER_MODEL_CACHE
    except NameError:
        cache = _FASTER_MODEL_CACHE = {}
    key = str(model_name)
    if key not in cache:
        print(f"[faster-whisper] carregando modelo={model_name} device=cpu compute=int8")
        cache[key] = WhisperModel(model_name, device="cpu", compute_type="int8")
    wav_path, _ = _wav_temp_from_audio(audio)
    try:
        segments, info = cache[key].transcribe(
            wav_path,
            language=idioma,
            task="transcribe",
            vad_filter=True,
            beam_size=1,
            condition_on_previous_text=False,
            word_timestamps=False,
        )
        textos=[]
        segs_lista=[]
        for sg in segments:
            txt=(getattr(sg,"text","") or "").strip()
            if txt:
                textos.append(txt)
                segs_lista.append(SegmentoASR(float(getattr(sg,"start",0) or 0), float(getattr(sg,"end",0) or 0), txt))
        texto=limpar_texto_transcricao(limpar_tags_asr(" ".join(textos).strip()))
        if texto_whisper_invalido(texto, origem="faster-local"):
            raise RuntimeError("faster-whisper retornou texto invalido; bloqueado para nao gerar SRT/corte errado.")
        return texto, segs_lista
    finally:
        try:
            os.remove(wav_path)
        except Exception:
            pass

def transcrever_local(modelo, audio):
    """Transcrição local: MLX no Mac Apple Silicon; Faster-Whisper no Windows."""
    if isinstance(modelo, dict) and str(modelo.get("engine","")).lower().startswith("faster"):
        return _transcrever_faster(modelo, audio)
    if (platform.system().lower().startswith("win") or not TEM_MLX) and TEM_FASTER_WHISPER:
        return _transcrever_faster(modelo, audio)
    if not TEM_MLX or mlx_whisper is None:
        raise RuntimeError("Nenhum motor local disponível. No Windows use faster-whisper; no Mac Apple Silicon use mlx-whisper.")

    audio = preparar_audio_whisper(audio).astype(np.float32)
    idioma = whisper_language_atual()
    modelo_nome = modelo_mlx_atual()

    result = mlx_whisper.transcribe(
        audio,
        path_or_hf_repo=modelo_nome,
        language=idioma,
        task="transcribe",
        condition_on_previous_text=False,
        initial_prompt=None,
        word_timestamps=False,
        verbose=False,
    )

    segmentos_raw = result.get("segments") or [] if isinstance(result, dict) else []
    segs_lista = []
    textos = []
    for sg in segmentos_raw:
        if isinstance(sg, dict):
            txt = (sg.get("text") or sg.get("texto") or "").strip()
            st = sg.get("start", sg.get("inicio", 0))
            en = sg.get("end", sg.get("fim", 0))
        else:
            txt = (getattr(sg, "text", "") or "").strip()
            st = getattr(sg, "start", 0)
            en = getattr(sg, "end", 0)
        if txt:
            textos.append(txt)
            segs_lista.append(SegmentoASR(st, en, txt))

    texto = " ".join(textos).strip()
    if not texto and isinstance(result, dict):
        texto = (result.get("text") or result.get("transcription") or "").strip()
        if texto:
            dur = float(len(audio) / max(1, CONFIG.get("sample_rate", 16000)))
            segs_lista = [SegmentoASR(0, dur, texto)]

    texto = limpar_texto_transcricao(limpar_tags_asr(texto))
    if texto_whisper_invalido(texto, origem="mlx-local"):
        raise RuntimeError("MLX Whisper retornou texto invalido; bloqueado para nao gerar SRT/corte errado.")
    return texto, segs_lista


def _resample_linear(audio, src_rate=16000, dst_rate=24000):
    audio = np.asarray(audio, dtype=np.float32).flatten()
    if src_rate == dst_rate:
        return audio
    if len(audio) < 2:
        return audio
    dur = len(audio) / float(src_rate)
    x_old = np.linspace(0, dur, num=len(audio), endpoint=False)
    x_new = np.linspace(0, dur, num=max(1, int(dur * dst_rate)), endpoint=False)
    return np.interp(x_new, x_old, audio).astype(np.float32)


def _pcm16_b64(audio_float):
    audio_float = np.clip(np.asarray(audio_float, dtype=np.float32).flatten(), -1.0, 1.0)
    pcm = (audio_float * 32767.0).astype(np.int16).tobytes()
    return base64.b64encode(pcm).decode("ascii")


async def _openai_realtime_transcribe_async(audio, timeout_seg=45):
    chave = (config_usuario.get("openai_api_key") or config_usuario.get("openai_key") or "").strip()
    if not chave:
        raise RuntimeError("Modo Turbo precisa da chave OpenAI nas configuracoes.")
    modelo = str(config_usuario.get("openai_realtime_model", CONFIG.get("openai_realtime_model", "gpt-realtime-whisper")))
    delay = str(config_usuario.get("openai_realtime_delay", CONFIG.get("openai_realtime_delay", "high"))).lower().strip()
    if delay not in ("minimal", "low", "medium", "high", "xhigh"):
        delay = "high"

    audio24 = _resample_linear(preparar_audio_whisper(audio), CONFIG.get("sample_rate", 16000), 24000)
    audio_b64 = _pcm16_b64(audio24)
    url = f"wss://api.openai.com/v1/realtime?model={modelo}"
    headers = {
        "Authorization": f"Bearer {chave}",
        "OpenAI-Beta": "realtime=v1",
    }

    async def _connect():
        try:
            return await websockets.connect(url, additional_headers=headers, max_size=20_000_000)
        except TypeError:
            return await websockets.connect(url, extra_headers=headers, max_size=20_000_000)

    async with await _connect() as ws_openai:
        await ws_openai.send(json.dumps({
            "type": "session.update",
            "session": {
                "type": "transcription",
                "audio": {
                    "input": {
                        "format": {"type": "audio/pcm", "rate": 24000},
                        "transcription": {
                            "model": modelo,
                            "language": whisper_language_atual(),
                            "delay": delay,
                        },
                        "turn_detection": None,
                    }
                }
            }
        }))
        await ws_openai.send(json.dumps({"type": "input_audio_buffer.append", "audio": audio_b64}))
        await ws_openai.send(json.dumps({"type": "input_audio_buffer.commit"}))

        partes = []
        final = ""
        fim = time.time() + timeout_seg
        while time.time() < fim:
            try:
                msg = await asyncio.wait_for(ws_openai.recv(), timeout=5)
            except asyncio.TimeoutError:
                continue
            ev = json.loads(msg)
            tipo = ev.get("type", "")
            if tipo == "conversation.item.input_audio_transcription.delta":
                delta = ev.get("delta") or ""
                if delta:
                    partes.append(delta)
            elif tipo == "conversation.item.input_audio_transcription.completed":
                final = (ev.get("transcript") or "").strip()
                break
            elif tipo == "error":
                erro = ev.get("error") or ev
                raise RuntimeError(f"OpenAI Realtime erro: {erro}")
        texto = final or "".join(partes).strip()
        return texto


def transcrever_openai_realtime(audio):
    """Modo Turbo: usa OpenAI Realtime Transcription com chave do usuario.
    A chamada e por chunk para manter compatibilidade com o pipeline atual de cortes.
    """
    texto = asyncio.run(_openai_realtime_transcribe_async(audio))
    texto = limpar_texto_transcricao(limpar_tags_asr(texto))
    if texto_whisper_invalido(texto, origem="openai-turbo"):
        raise RuntimeError("OpenAI Realtime retornou texto invalido/vazio")
    dur = float(len(audio) / max(1, CONFIG.get("sample_rate", 16000)))
    return texto, [SegmentoASR(0, dur, texto)]

def traduzir_texto_ao_vivo(texto):
    """AI Boost opcional: traduz uma linha ao vivo usando Gemini ou OpenAI.
    Desligado por padrão para manter o FrameZero leve.
    """
    texto = str(texto or "").strip()
    if not texto or not live_translation_ativa():
        return ""
    alvo = str(config_usuario.get("live_translation_target", CONFIG.get("live_translation_target", "en")) or "en")
    prov = str(config_usuario.get("live_translation_provider", CONFIG.get("live_translation_provider", "gemini"))).lower().strip()
    try:
        if prov == "openai":
            cl = cliente_openai()
            if cl is None:
                return ""
            r = cl.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role":"system","content":f"Translate the text to {alvo}. Keep it natural for sermon captions. Return only the translation."},
                          {"role":"user","content":texto}],
                temperature=0.1,
            )
            return (r.choices[0].message.content or "").strip()
        # Gemini
        if requests is None:
            return ""
        chave = str(config_usuario.get("gemini_api_key", CONFIG.get("gemini_api_key", "")) or "").strip()
        if not chave:
            return ""
        modelo = str(config_usuario.get("gemini_model", CONFIG.get("gemini_model", "gemini-2.5-flash-lite"))).strip() or "gemini-2.5-flash-lite"
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent?key={chave}"
        payload = {"contents":[{"role":"user", "parts":[{"text": f"Translate this sermon caption line to {alvo}. Return only the translation, no notes.\n\n{texto}"}]}], "generationConfig":{"temperature":0.1,"maxOutputTokens":220}}
        r = requests.post(url, headers={"Content-Type":"application/json"}, json=payload, timeout=30)
        r.raise_for_status()
        data = r.json()
        parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
        return " ".join(str(p.get("text", "")) for p in parts if p.get("text")).strip()
    except Exception as e:
        if not globals().get('_avisou_traducao_live_falha', False):
            globals()['_avisou_traducao_live_falha'] = True
            print(f"[global-ai] tradução ao vivo indisponível nesta rodada: {e}")
        return ""

def enviar_audio_status(ok=None, nome=None, rms=None, msg=None, origem=None):
    """Atualiza e envia status de áudio para o painel/Terminal."""
    global audio_status_atual, ultimo_status_audio_envio
    if ok is not None: audio_status_atual["ok"] = bool(ok)
    if nome is not None: audio_status_atual["nome"] = nome
    if rms is not None: audio_status_atual["rms"] = round(float(rms), 5)
    if msg is not None: audio_status_atual["msg"] = msg
    if origem is not None: audio_status_atual["origem"] = origem
    now = time.time()
    # evita flood no websocket
    if now - ultimo_status_audio_envio > 1.5:
        ultimo_status_audio_envio = now
        enviar({"tipo":"audio_status", **audio_status_atual})

def enviar_vps_status(ok=None, msg=None, modo=None, url=None):
    """Atualiza e envia status da VPS atual para o painel/Terminal."""
    global vps_status_atual, ultimo_status_vps_envio
    if ok is not None: vps_status_atual["ok"] = bool(ok)
    if msg is not None: vps_status_atual["msg"] = str(msg)
    if modo is not None: vps_status_atual["modo"] = str(modo)
    if url is not None: vps_status_atual["url"] = str(url)
    now = time.time()
    if now - ultimo_status_vps_envio > 1.0:
        ultimo_status_vps_envio = now
        enviar({"tipo":"vps_status", **vps_status_atual})

def callback_audio(indata, frames, t, status):
    if status: print(f"[audio] {status}")
    copia = indata.copy()
    fila_audio.put(copia)
    try:
        _fz_nations_audio_hook(copia, CONFIG.get("sample_rate", 16000))
    except Exception:
        pass

def listar_dispositivos_entrada():
    """Devolve a lista de dispositivos que conseguem CAPTURAR audio (entrada)."""
    saida = []
    if sd is None:
        return saida
    try:
        devs = sd.query_devices()
        padrao = sd.default.device[0] if sd.default.device else None
        for i, d in enumerate(devs):
            if d.get("max_input_channels", 0) > 0:
                saida.append({
                    "id": i,
                    "nome": d.get("name", f"Dispositivo {i}"),
                    "padrao": (i == padrao),
                })
    except Exception as e:
        print(f"[audio] erro ao listar: {e}")
    return saida


def encontrar_blackhole():
    return None, None

def abrir_audio(dispositivo):
    """Abre (ou reabre) o stream de captura no dispositivo escolhido.
    dispositivo = None usa o padrao do sistema; ou um indice inteiro."""
    global stream_audio
    if sd is None:
        msg = f"sounddevice/PortAudio indisponivel: {SOUNDDEVICE_ERROR}"
        print(f"[audio] {msg}")
        enviar_audio_status(ok=False, nome="audio local indisponivel", rms=0.0, msg=msg, origem="sem-sounddevice")
        return False, msg
    if stream_audio is not None:
        try: stream_audio.stop(); stream_audio.close()
        except Exception: pass
        stream_audio = None
    try:
        stream_audio = sd.InputStream(
            samplerate=CONFIG["sample_rate"], channels=CONFIG["canais"],
            dtype="float32", device=dispositivo, callback=callback_audio)
        stream_audio.start()
        # esvazia o buffer pra nao misturar audio do dispositivo antigo
        with fila_audio.mutex:
            fila_audio.queue.clear()
        nome = "padrao do sistema"
        if dispositivo is not None:
            try: nome = sd.query_devices(dispositivo).get("name", str(dispositivo))
            except Exception: nome = str(dispositivo)
        print(f"[audio] capturando de: {nome}")
        enviar_audio_status(ok=True, nome=nome, rms=0.0, msg="áudio conectado; aguardando sinal", origem="blackhole" if "blackhole" in str(nome).lower() else "dispositivo")
        return True, nome
    except Exception as e:
        print(f"[audio] falha ao abrir dispositivo {dispositivo}: {e}")
        enviar_audio_status(ok=False, nome=str(dispositivo), rms=0.0, msg=f"falha ao abrir áudio: {e}")
        return False, str(e)

def fmt(s):
    h=int(s//3600); m=int((s%3600)//60); x=int(s%60)
    return f"{h:02d}:{m:02d}:{x:02d}"

def fmt_srt(s):
    h=int(s//3600); m=int((s%3600)//60); x=int(s%60); ms=int((s-int(s))*1000)
    return f"{h:02d}:{m:02d}:{x:02d},{ms:03d}"


def _cfg_int(nome, padrao):
    try:
        return int(config_usuario.get(nome, CONFIG.get(nome, padrao)))
    except Exception:
        return padrao

def _cfg_bool(nome, padrao):
    v = config_usuario.get(nome, CONFIG.get(nome, padrao))
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("1", "true", "sim", "yes", "on")

def quebrar_texto_srt_ptbr(texto, limite=None, linha_unica=None):
    """Quebra legenda em português brasileiro para o padrão do projeto.
    Padrão: 37 caracteres e linha única. Se o texto passar disso, vira novos cues,
    não segunda linha dentro do mesmo cue.
    """
    limite = limite or _cfg_int("srt_caracteres_por_linha", 37)
    linha_unica = _cfg_bool("srt_linha_unica", True) if linha_unica is None else linha_unica
    texto = corrigir_legenda_por_contexto(re.sub(r"\s+", " ", str(texto or "")).strip())
    if not texto:
        return []
    palavras = texto.split(" ")
    partes = []
    atual = ""
    for palavra in palavras:
        if not atual:
            if len(palavra) <= limite:
                atual = palavra
            else:
                # palavra muito grande: corta em pedaços para nunca passar do limite
                for i in range(0, len(palavra), limite):
                    pedaco = palavra[i:i+limite]
                    if len(pedaco) == limite:
                        partes.append(pedaco)
                    else:
                        atual = pedaco
        elif len(atual) + 1 + len(palavra) <= limite:
            atual += " " + palavra
        else:
            partes.append(atual)
            if len(palavra) <= limite:
                atual = palavra
            else:
                for i in range(0, len(palavra), limite):
                    pedaco = palavra[i:i+limite]
                    if len(pedaco) == limite:
                        partes.append(pedaco)
                    else:
                        atual = pedaco
    if atual:
        partes.append(atual)
    # linha única: cada item é uma única linha. Se um dia desligar, ainda mantemos seguro.
    if linha_unica:
        return partes
    return partes

def adicionar_cues_srt(out, indice, inicio, fim, texto):
    """Adiciona cues respeitando pt-BR, 37 caracteres e linha única."""
    partes = quebrar_texto_srt_ptbr(texto)
    if not partes:
        return indice
    dur = max(0.7, float(fim) - float(inicio))
    passo = dur / max(1, len(partes))
    for n, parte in enumerate(partes):
        a = float(inicio) + passo * n
        b = float(inicio) + passo * (n + 1)
        if n == len(partes) - 1:
            b = float(fim)
        if b <= a:
            b = a + 0.7
        out += [str(indice), f"{fmt_srt(a)} --> {fmt_srt(b)}", parte, ""]
        indice += 1
    return indice

def fmt_ass(s):
    """Tempo ASS: H:MM:SS.cc"""
    s = max(0.0, float(s or 0))
    h = int(s // 3600)
    m = int((s % 3600) // 60)
    x = int(s % 60)
    cs = int(round((s - int(s)) * 100))
    if cs >= 100:
        x += 1
        cs = 0
    return f"{h}:{m:02d}:{x:02d}.{cs:02d}"


def ass_escape(txt):
    txt = re.sub(r"\s+", " ", str(txt or "")).strip()
    return txt.replace("{", "(").replace("}", ")")


def ass_header():
    """Legenda estilizada equivalente ao preset, sem depender do arquivo .preset."""
    font = config_usuario.get("subtitle_font_family", CONFIG.get("subtitle_font_family", "Poppins"))
    size = _cfg_int("subtitle_font_size", 13)
    bold = -1 if _cfg_bool("subtitle_bold", True) else 0
    alignment = _cfg_int("subtitle_alignment", 2)
    primary = config_usuario.get("subtitle_primary_color_ass", CONFIG.get("subtitle_primary_color_ass", "&H00FFFFFF"))
    outline_color = config_usuario.get("subtitle_outline_color_ass", CONFIG.get("subtitle_outline_color_ass", "&H00000000"))
    back = config_usuario.get("subtitle_back_color_ass", CONFIG.get("subtitle_back_color_ass", "&H80000000"))
    outline = _cfg_int("subtitle_outline", 2)
    shadow = _cfg_int("subtitle_shadow", 0)
    return f"""[Script Info]
ScriptType: v4.00+
WrapStyle: 2
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: GAB USA Subtitle,{font},{size},{primary},&H000000FF,{outline_color},{back},{bold},0,0,0,100,100,0,0,1,{outline},{shadow},{alignment},80,80,120,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


def ass_from_srt(srt_text):
    """Converte o SRT gerado (37 caracteres, linha única) em ASS com estilo Poppins/Bold."""
    events = []
    blocks = re.split(r"\n\s*\n", str(srt_text or "").strip())
    for block in blocks:
        lines_block = [x.strip() for x in block.splitlines() if x.strip()]
        if len(lines_block) < 3:
            continue
        tempo = None
        texto_linhas = []
        for ln in lines_block:
            if "-->" in ln:
                tempo = ln
            elif not ln.isdigit():
                texto_linhas.append(ln)
        if not tempo or not texto_linhas:
            continue
        try:
            ini, fim = [x.strip() for x in tempo.split("-->")]
            def parse_srt_time(t):
                hms, ms = t.split(',')
                h, m, sec = hms.split(':')
                return int(h)*3600 + int(m)*60 + int(sec) + int(ms)/1000
            a = parse_srt_time(ini)
            b = parse_srt_time(fim)
            texto = ass_escape(" ".join(texto_linhas))
            events.append(f"Dialogue: 0,{fmt_ass(a)},{fmt_ass(b)},GAB USA Subtitle,,0,0,0,,{texto}")
        except Exception:
            continue
    return ass_header() + "\n".join(events) + "\n"

# ----------------------------- OBS -----------------------------

def descobrir_senha_obs():
    """
    Le a senha e a porta do WebSocket direto da config do OBS, pra pessoa nao
    precisar copiar na mao. O OBS guarda isso em texto. Procura nos locais
    conhecidos (varia por versao/sistema). Devolve (senha, porta) ou (None, None).

    Prioridade: senha que o usuario tenha colado em config.json > config do OBS.
    """
    # 1. se a pessoa ja salvou manualmente, respeita
    manual = config_usuario.get("obs_senha", "").strip()
    if manual and manual != "TROQUE_AQUI":
        return manual, config_usuario.get("obs_porta", CONFIG["obs_porta"])

    home = Path.home()
    # locais possiveis da config do plugin websocket, Mac e Windows
    candidatos = []
    if os.name == "nt":
        appdata = os.environ.get("APPDATA", "")
        base = Path(appdata) / "obs-studio"
    else:
        base = home / "Library" / "Application Support" / "obs-studio"
    # arquivo novo (plugin proprio) e o antigo (global.ini)
    candidatos += [
        base / "plugin_config" / "obs-websocket" / "config.json",
        base / "global.ini",
    ]

    import configparser
    for arq in candidatos:
        try:
            if not arq.exists():
                continue
            if arq.suffix == ".json":
                dados = json.loads(arq.read_text(encoding="utf-8"))
                senha = dados.get("server_password") or dados.get("ServerPassword")
                porta = dados.get("server_port") or dados.get("ServerPort") or CONFIG["obs_porta"]
                ativo = dados.get("server_enabled", dados.get("ServerEnabled", True))
                if senha and ativo:
                    print(f"[obs] senha lida automaticamente de {arq.name}")
                    return str(senha), int(porta)
            else:  # global.ini
                cp = configparser.ConfigParser()
                cp.read(arq, encoding="utf-8")
                if cp.has_section("OBSWebSocket"):
                    senha = cp.get("OBSWebSocket", "ServerPassword", fallback="")
                    porta = cp.getint("OBSWebSocket", "ServerPort", fallback=CONFIG["obs_porta"])
                    if senha:
                        print(f"[obs] senha lida automaticamente de {arq.name}")
                        return senha, porta
        except Exception as e:
            print(f"[obs] nao deu pra ler {arq.name}: {e}")
    return None, None


def replay_status_ativo():
    """Retorna True se o Replay Buffer do OBS ja estiver rodando."""
    if obs_req is None:
        return False
    try:
        st = obs_req.get_replay_buffer_status()
        for attr in ("output_active", "outputActive", "replay_buffer_active", "replayBufferActive"):
            if hasattr(st, attr):
                return bool(getattr(st, attr))
        # obsws-python costuma devolver um objeto com attrs; fallback por string/dict
        if isinstance(st, dict):
            return bool(st.get("outputActive") or st.get("output_active"))
    except Exception:
        pass
    return False

def garantir_replay_buffer(silencioso=False):
    """Liga o Replay Buffer quando possivel.
    OBS pode retornar erro 500 quando o buffer ja esta rodando; nesse caso tratamos como OK.
    """
    if obs_req is None:
        return False
    if replay_status_ativo():
        if not silencioso:
            print("[obs] Replay Buffer ja estava ativo.")
        return True
    try:
        obs_req.start_replay_buffer()
        time.sleep(0.4)
        if replay_status_ativo():
            if not silencioso:
                print("[obs] Replay Buffer iniciado.")
            return True
        # em alguns OBS o status demora; assume OK se nao explodiu
        if not silencioso:
            print("[obs] Replay Buffer solicitado.")
        return True
    except Exception as e:
        # code 500 normalmente significa 'ja ativo' ou estado invalido temporario.
        if replay_status_ativo():
            if not silencioso:
                print("[obs] Replay Buffer ja estava ativo.")
            return True
        if not silencioso:
            print(f"[obs] Replay Buffer nao iniciou: {e}")
        return False

def iniciar_obs(senha_manual=None, porta_manual=None):
    global obs_req, obs_conectado
    # ordem: senha manual (do painel) > descoberta automatica > config padrao
    if senha_manual:
        senha = senha_manual
        porta = porta_manual or CONFIG["obs_porta"]
        print("[obs] usando senha informada no painel.")
    else:
        senha_auto, porta_auto = descobrir_senha_obs()
        senha = senha_auto if senha_auto else CONFIG["obs_senha"]
        porta = porta_auto if porta_auto else CONFIG["obs_porta"]
        if senha_auto:
            print("[obs] usando senha do WebSocket descoberta automaticamente.")
    # cliente de eventos (escuta inicio/fim de gravacao e replay salvo)
    try:
        ev = obs.EventClient(host=CONFIG["obs_host"], port=porta, password=senha)
        obs_req = obs.ReqClient(host=CONFIG["obs_host"], port=porta,
                                password=senha, timeout=3)
    except Exception as e:
        obs_conectado = False
        print(f"[obs] nao conectou ({e}). Segue em modo manual, sem clipe automatico.")
        print("[obs] Dica: abra o OBS, ative o WebSocket (Ferramentas) e rode de novo.")
        return False

    def zerar(motivo):
        global gravando, inicio_gravacao, linhas, cortes, texto_desde_ia, texto_contexto_ia, ultima_ia
        gravando = True; inicio_gravacao = time.time()
        linhas = []; cortes = []; texto_desde_ia = []; texto_contexto_ia = []; ultima_ia = time.time()
        # liga o replay buffer pra ja estar guardando o trecho recente.
        rb_ok = garantir_replay_buffer(silencioso=True)
        print(f"[obs] {motivo} -> 00:00:00" + (" + replay buffer ativo" if rb_ok else " + replay buffer pendente"))
        enviar({"tipo":"status","gravando":True,"motivo":motivo,"transcricao_ativa":bool(config_usuario.get("transcricao_ativa", CONFIG.get("transcricao_ativa", True)))})

    def parar(motivo):
        global gravando
        gravando = False
        print(f"[obs] {motivo}")
        enviar({"tipo":"status","gravando":False,"motivo":motivo,"transcricao_ativa":bool(config_usuario.get("transcricao_ativa", CONFIG.get("transcricao_ativa", True)))})

    def on_record_state_changed(d):
        global gravacao_completa
        e = getattr(d,"output_state","")
        if "STARTED" in e: zerar("Gravacao iniciada")
        elif "STOPPED" in e:
            # o evento de parada ja traz o caminho do arquivo gravado
            caminho = getattr(d,"output_path","") or getattr(d,"outputPath","")
            if caminho: gravacao_completa = caminho
            parar("Gravacao encerrada")
            enviar({"tipo":"gravacao_pronta","caminho":gravacao_completa})

    def on_stream_state_changed(d):
        e = getattr(d,"output_state","")
        if "STARTED" in e: zerar("Transmissao iniciada")
        elif "STOPPED" in e: parar("Transmissao encerrada")

    def on_replay_buffer_saved(d):
        caminho = getattr(d,"saved_replay_path","") or getattr(d,"savedReplayPath","")
        finalizar_clipe(caminho)

    ev.callback.register([on_record_state_changed, on_stream_state_changed,
                          on_replay_buffer_saved])
    obs_conectado = True
    print("[obs] conectado.")
    return True

def nome_seguro(texto, limite=50):
    """Slug curto para compatibilidade com arquivos antigos."""
    t = str(texto or "").strip().lower()
    t = re.sub(r"\s+", "-", t)
    t = re.sub(r"[^a-z0-9\-áàâãéêíóôõúç]", "", t)
    t = re.sub(r"-+", "-", t).strip("-")
    return (t[:limite].strip("-") or "momento")

def titulo_arquivo_seguro(texto, limite=90):
    """Nome legível para pasta/arquivo, preservando título e funcionando no Windows/macOS."""
    t = str(texto or "").strip()
    t = re.sub(r'[<>:"/\\|?*\x00-\x1F]', "", t)
    t = re.sub(r"\s+", " ", t).strip(" ._-–—")
    if not t:
        t = "Momento"
    if len(t) > limite:
        t = t[:limite].rstrip(" ._-–—")
    return t or "Momento"

def titulo_corte_limpo(c):
    return titulo_arquivo_seguro((c or {}).get("titulo") or "Momento", 90)

def nome_video_corte(c, prop=None):
    titulo = titulo_corte_limpo(c)
    if prop:
        return f"{titulo} - {str(prop).replace(':', 'x')}.mp4"
    return f"{titulo}.mp4"


def titulo_hashtag(t):
    return re.sub(r"[^a-zA-Z0-9áàâãéêíóôõúçÁÀÂÃÉÊÍÓÔÕÚÇ\s]", "", t).strip()

def hashtags_padrao(c):
    perfil = perfil_idioma_atual()
    tags = list(perfil.get("hashtags") or ["#sermon", "#faith", "#Jesus", "#church"])
    emocao = _norm(c.get("emocao", ""))
    if perfil_id_atual().startswith("pt"):
        if "quebrant" in emocao: tags += ["#quebrantamento", "#arrependimento"]
        if "esper" in emocao: tags += ["#esperança", "#recomeço"]
        if "urg" in emocao: tags += ["#palavradedeus", "#hoje"]
        if "hist" in _norm(c.get("funcao", "")): tags += ["#historia", "#biblia"]
    elif perfil_id_atual() == "en":
        if "hope" in emocao: tags += ["#hope", "#encouragement"]
        if "story" in _norm(c.get("funcao", "")): tags += ["#bible", "#story"]
    elif perfil_id_atual() == "es":
        if "esper" in emocao: tags += ["#esperanza", "#palabradedios"]
        if "hist" in _norm(c.get("funcao", "")): tags += ["#biblia", "#historia"]
    return " ".join(dict.fromkeys(tags))

def legenda_instagram(c):
    titulo = titulo_hashtag(c.get("titulo") or "Sermon moment")
    frase = (c.get("texto") or "").strip()
    frase_curta = frase if len(frase) <= 180 else frase[:177].rstrip() + "..."
    pid = perfil_id_atual()
    if pid == "en":
        return (f"{titulo}\n\n{frase_curta}\n\nA message like this can strengthen your faith and speak to someone right on time. Save this clip and share it with someone who needs encouragement today.\n\nScore: {c.get('score', 0)}/100\nEmotion: {c.get('emocao') or 'faith'}\nClip type: {c.get('funcao') or 'impact'}\n\n{hashtags_padrao(c)}")
    if pid == "es":
        return (f"{titulo}\n\n{frase_curta}\n\nA veces Dios usa una palabra para fortalecer la fe de alguien. Guarda este corte y compártelo con alguien que necesite escucharlo hoy.\n\nScore: {c.get('score', 0)}/100\nEmoción: {c.get('emocao') or 'fe'}\nFunción del corte: {c.get('funcao') or 'impacto'}\n\n{hashtags_padrao(c)}")
    return (
        f"{titulo}\n\n"
        f"{frase_curta}\n\n"
        "Às vezes Deus usa uma frase para alinhar tudo de novo por dentro. "
        "Salva esse corte para assistir de novo e envia para alguém que precisa ouvir isso hoje.\n\n"
        f"Score viral: {c.get('score', 0)}/100\n"
        f"Emoção: {c.get('emocao') or 'fé'}\n"
        f"Função do corte: {c.get('funcao') or 'impacto'}\n\n"
        f"{hashtags_padrao(c)}"
    )

def legenda_tiktok(c):
    titulo = titulo_hashtag(c.get("titulo") or "Sermon clip")
    frase = (c.get("texto") or "").strip()
    frase_curta = frase if len(frase) <= 120 else frase[:117].rstrip() + "..."
    pid = perfil_id_atual()
    if pid == "en":
        return f"{titulo}\n\n{frase_curta}\n\nWatch this to the end. This word has a strong turn.\n\n{hashtags_padrao(c)}"
    if pid == "es":
        return f"{titulo}\n\n{frase_curta}\n\nMíralo hasta el final. Esta palabra tiene una vuelta fuerte.\n\n{hashtags_padrao(c)}"
    return (
        f"{titulo}\n\n"
        f"{frase_curta}\n\n"
        "Assiste até o final. Essa palavra tem uma virada forte.\n\n"
        f"{hashtags_padrao(c)}"
    )


def texto_do_corte(c):
    """Texto principal do corte, usando o melhor campo disponível."""
    c = c or {}
    return str(
        c.get("texto_final_corte")
        or c.get("texto")
        or c.get("trecho")
        or c.get("quote")
        or c.get("hook")
        or ""
    ).strip()


def _lista_strings(valor):
    """Normaliza campos vindos da IA em lista de strings limpas."""
    if valor is None:
        return []
    if isinstance(valor, (list, tuple, set)):
        bruto = list(valor)
    else:
        txt = str(valor).strip()
        if not txt:
            return []
        bruto = re.split(r"\n|;|\|", txt)
    out = []
    for item in bruto:
        if isinstance(item, dict):
            item = item.get("texto") or item.get("frase") or item.get("referencia") or item.get("versiculo") or item.get("title") or ""
        item = re.sub(r"\s+", " ", str(item or "").strip(" -–—•\t"))
        if item and item not in out:
            out.append(item)
    return out


def _sentencas(texto):
    texto = re.sub(r"\s+", " ", str(texto or "")).strip()
    if not texto:
        return []
    partes = re.split(r"(?<=[.!?…])\s+", texto)
    # quando o Whisper vem sem pontuação, quebra em blocos de até ~24 palavras.
    if len(partes) <= 1 and len(texto.split()) > 28:
        palavras = texto.split()
        partes = [" ".join(palavras[i:i+24]) for i in range(0, len(palavras), 24)]
    return [p.strip(" \t\n\r-–—") for p in partes if len(p.strip()) >= 12]


def extrair_frases_de_impacto(c, limite=5):
    """Extrai frases fortes do corte. Usa a resposta da IA quando houver e aplica fallback local."""
    c = c or {}
    campos = [
        c.get("frases_de_impacto"), c.get("frases_impacto"), c.get("frase_impacto"),
        c.get("impact_phrases"), c.get("frases"), c.get("hook")
    ]
    frases = []
    for campo in campos:
        frases.extend(_lista_strings(campo))
    texto = texto_do_corte(c)
    # Fallback: frases com força emocional, ensino, contraste, pergunta ou fechamento.
    gatilhos = re.compile(
        r"\b(verdade|segredo|ningu[eé]m|n[aã]o desista|Deus|Jesus|f[eé]|promessa|processo|"
        r"persist|ora[cç][aã]o|milagre|mudou tudo|entendi|aprendi|problema|por isso|"
        r"sabe|quem conhece|o que|por qu[eê]|quando|mas|s[oó] que|quanto mais|nunca|sempre)\b",
        re.I,
    )
    for sent in _sentencas(texto):
        limpa = re.sub(r"\s+", " ", sent).strip()
        if len(limpa) < 30 or len(limpa) > 240:
            continue
        if gatilhos.search(limpa) or "?" in limpa or "!" in limpa:
            frases.append(limpa)
    # Se ainda não tem nada, pega a primeira frase usável do corte.
    if not frases:
        for sent in _sentencas(texto):
            limpa = re.sub(r"\s+", " ", sent).strip()
            if 30 <= len(limpa) <= 220:
                frases.append(limpa)
                break
    out = []
    for frase in frases:
        frase = re.sub(r"\s+", " ", str(frase or "")).strip(" \"'“”‘’.-–—")
        if not frase:
            continue
        if len(frase) > 260:
            frase = frase[:257].rstrip() + "..."
        if frase not in out:
            out.append(frase)
        if len(out) >= limite:
            break
    return out


def extrair_versiculos(c):
    """Extrai referências bíblicas no idioma escolhido, sem inventar versículo."""
    c = c or {}
    refs = []
    for campo in (
        c.get("versiculos"), c.get("versiculos_biblicos"), c.get("referencias_biblicas"),
        c.get("bible_verses"), c.get("referencias")
    ):
        refs.extend(_lista_strings(campo))
    texto = texto_do_corte(c)
    livros = bible_books_regex_atual()
    padrao = re.compile(
        rf"\b((?:{livros})\s*(?:chapter\s*|cap[ií]tulo\s*)?\d{{1,3}}(?:\s*[:.]\s*\d{{1,3}}(?:\s*[-–]\s*\d{{1,3}})?)?)\b",
        re.I,
    )
    for m in padrao.finditer(texto):
        refs.append(m.group(1))
    out = []
    for ref in refs:
        ref = re.sub(r"\s+", " ", str(ref or "")).strip(" .,;:-–—")
        if not ref or not re.search(r"\d", ref):
            continue
        if ref not in out:
            out.append(ref)
    return out


def texto_frases_de_impacto(c):
    frases = extrair_frases_de_impacto(c)
    titulo = (c or {}).get("titulo") or "Momento"
    linhas_out = [f"FRASES DE IMPACTO — {titulo}", ""]
    if not frases:
        linhas_out.append("Nenhuma frase de impacto detectada neste corte.")
    else:
        for i, frase in enumerate(frases, 1):
            linhas_out.append(f"{i:02d}. {frase}")
    linhas_out.append("")
    return "\n".join(linhas_out)


def texto_versiculos(c):
    versiculos = extrair_versiculos(c)
    titulo = (c or {}).get("titulo") or "Momento"
    linhas_out = [f"VERSÍCULOS / REFERÊNCIAS BÍBLICAS — {titulo}", ""]
    if not versiculos:
        linhas_out.append("Nenhum versículo detectado neste corte.")
    else:
        for i, ref in enumerate(versiculos, 1):
            linhas_out.append(f"{i:02d}. {ref}")
    linhas_out.append("")
    return "\n".join(linhas_out)


def texto_briefing_corte(c):
    frases = extrair_frases_de_impacto(c)
    versiculos = extrair_versiculos(c)
    return "\n".join([
        f"TÍTULO: {c.get('titulo','Momento')}",
        f"SCORE: {c.get('score',0)}/100",
        f"TIMESTAMP: {c.get('timestamp','00:00:00')}",
        f"EMOÇÃO: {c.get('emocao','')}",
        f"FUNÇÃO NARRATIVA: {c.get('funcao','')}",
        f"RAZÃO DO CORTE: {c.get('razao','')}",
        f"FRASES DE IMPACTO: {len(frases)}",
        f"VERSÍCULOS DETECTADOS: {len(versiculos)}",
        "",
        "TRECHO:",
        texto_do_corte(c),
        "",
        "PRINCIPAIS FRASES:",
        "\n".join([f"- {x}" for x in frases]) if frases else "Nenhuma frase de impacto detectada.",
        "",
        "VERSÍCULOS / REFERÊNCIAS:",
        "\n".join([f"- {x}" for x in versiculos]) if versiculos else "Nenhum versículo detectado.",
        "",
        "LEGENDA INSTAGRAM:",
        legenda_instagram(c),
        "",
        "LEGENDA TIKTOK:",
        legenda_tiktok(c),
        "",
    ])

def pasta_principal(base_dir, tipo="final"):
    global pasta_cortes_ao_vivo, pasta_cortes_finais
    nome = config_usuario.get("pasta_principal_cortes", CONFIG.get("pasta_principal_cortes", "FrameZero_Cortes"))
    if tipo == "ao_vivo":
        if not pasta_cortes_ao_vivo:
            pasta_cortes_ao_vivo = os.path.join(base_dir, f"{nome}_AoVivo_" + time.strftime("%Y-%m-%d_%H-%M"))
            os.makedirs(pasta_cortes_ao_vivo, exist_ok=True)
        return pasta_cortes_ao_vivo
    if not pasta_cortes_finais:
        pasta_cortes_finais = os.path.join(base_dir, f"{nome}_Finais_" + time.strftime("%Y-%m-%d_%H-%M"))
        os.makedirs(pasta_cortes_finais, exist_ok=True)
    return pasta_cortes_finais

def pasta_do_corte(pasta_mae, c):
    """Cria pasta do corte com o título em primeiro lugar, para ficar fácil achar."""
    ts = (c.get("timestamp") or "00:00:00").replace(":", "-")
    titulo = titulo_arquivo_seguro(c.get("titulo") or "Momento", 72)
    score = str(int(float(c.get("score", 0) or 0))).zfill(3)
    nome = f"{titulo} - {ts} - score {score}"
    pasta = os.path.join(pasta_mae, nome)
    n = 2
    while os.path.exists(pasta):
        pasta = os.path.join(pasta_mae, f"{nome} ({n})"); n += 1
    os.makedirs(pasta, exist_ok=True)
    return pasta

def salvar_arquivos_corte(pasta, c, video_path=None, srt_text=None, videos=None):
    # Arquivos de apoio para editor/social media.
    try:
        meta = dict(c)
        meta["srt_idioma"] = config_usuario.get("srt_idioma", CONFIG.get("srt_idioma", "pt-BR"))
        meta["srt_caracteres_por_linha"] = _cfg_int("srt_caracteres_por_linha", 37)
        meta["srt_linha_unica"] = _cfg_bool("srt_linha_unica", True)
        meta["subtitle_style"] = {
            "formato": "SRT",
            "arquivo": "legenda.srt",
            "fonte_recomendada": config_usuario.get("subtitle_font_family", CONFIG.get("subtitle_font_family", "Poppins")),
            "tamanho_recomendado": _cfg_int("subtitle_font_size", 13),
            "bold_recomendado": _cfg_bool("subtitle_bold", True),
            "observacao": "v81j: legenda.ass removida; a legenda principal fica em legenda.srt."
        }
        frases_impacto = extrair_frases_de_impacto(meta)
        versiculos = extrair_versiculos(meta)
        meta["frases_de_impacto"] = frases_impacto
        meta["versiculos"] = versiculos
        if video_path:
            meta["video"] = os.path.basename(video_path)
        if videos:
            meta["videos"] = {k: os.path.relpath(v, pasta) for k, v in videos.items()}
        Path(os.path.join(pasta, "metadata.json")).write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        Path(os.path.join(pasta, "resumo-do-corte.txt")).write_text(texto_briefing_corte(meta), encoding="utf-8")
        Path(os.path.join(pasta, "frases-de-impacto.txt")).write_text(texto_frases_de_impacto(meta), encoding="utf-8")
        Path(os.path.join(pasta, "versiculos.txt")).write_text(texto_versiculos(meta), encoding="utf-8")
        legendas_sociais = "\n".join([
            "LEGENDA INSTAGRAM",
            "=================",
            legenda_instagram(c),
            "",
            "LEGENDA TIKTOK",
            "==============",
            legenda_tiktok(c),
            "",
        ])
        Path(os.path.join(pasta, "legendas-redes-sociais.txt")).write_text(legendas_sociais, encoding="utf-8")
        if srt_text is not None:
            Path(os.path.join(pasta, "legenda.srt")).write_text(srt_text, encoding="utf-8")
    except Exception as e:
        print(f"[corte] falhou ao salvar arquivos sociais: {e}")

def finalizar_clipe(caminho_original):
    """
    Chamado quando o OBS termina de salvar um replay.
    Renomeia o arquivo com o titulo do momento e gera um .srt daquele trecho.
    """
    if not caminho_original or not os.path.exists(caminho_original):
        print(f"[clipe] salvo, mas caminho nao encontrado: {caminho_original}")
        enviar({"tipo":"clipe_salvo","caminho":caminho_original,"nome":""})
        return

    # pega o momento pendente associado a este save (FIFO)
    try:
        info = clipes_pendentes.get_nowait()
    except queue.Empty:
        info = {"titulo":"momento","timestamp":fmt(0),"inicio":0,"fim":0}

    pasta_gravacao = os.path.dirname(caminho_original)
    # Janela exata do corte em tempo da gravação/live.
    inicio_real, fim_real, dur_real = normalizar_janela_corte(info.get("inicio", 0), info.get("fim", 0), pico=info.get("fim", 0))
    c_meta = {
        "titulo": info.get("titulo", "Momento"),
        "timestamp": info.get("timestamp", fmt(fim_real)),
        "inicio": inicio_real,
        "fim": fim_real,
        "inicio_exato": inicio_real,
        "fim_exato": fim_real,
        "duracao_exata": dur_real,
        "tempo": fim_real,
        "score": info.get("score", 0),
        "texto": info.get("texto", info.get("titulo", "")),
        "razao": info.get("razao", "clipe automático ao vivo"),
        "emocao": info.get("emocao", "fé"),
        "funcao": info.get("funcao", "impacto"),
        "origem": info.get("origem", "ao_vivo"),
    }
    pasta_mae = pasta_principal(pasta_gravacao, "ao_vivo")
    pasta_corte = pasta_do_corte(pasta_mae, c_meta)
    novo_video = ""
    videos_gerados = {}

    # O OBS salva o Replay Buffer inteiro (ex: 120s). Aqui cortamos esse arquivo bruto
    # e já entregamos as duas versões automáticas: 16x9 e 9x16.
    recorte_ok = False
    if caminho_ffmpeg():
        try:
            dur_replay = duracao_video_seg(caminho_original)
            if not dur_replay:
                dur_replay = float(config_usuario.get("segundos_clipe", CONFIG.get("segundos_clipe", 120)))
            # O final do arquivo de Replay Buffer é o momento em que pedimos SaveReplayBuffer,
            # não necessariamente o timestamp do pico. Isso evita corte deslocado ou bruto de 2min.
            fim_buffer_timeline = float(info.get("replay_solicitado_em", fim_real) or fim_real)
            inicio_buffer = max(0.0, fim_buffer_timeline - float(dur_replay))
            offset = max(0.0, inicio_real - inicio_buffer)
            dur_saida = min(dur_real, max(0.5, float(dur_replay) - offset))
            videos_gerados = gerar_versoes_do_corte(caminho_original, pasta_corte, c_meta, inicio=offset, duracao=dur_saida, timeout=240)
            recorte_ok = bool(videos_gerados)
            # usa 9x16 como preview principal quando existir; senão 16x9.
            novo_video = videos_gerados.get("9x16") or videos_gerados.get("16x9") or next(iter(videos_gerados.values()), "")
            if recorte_ok:
                dur_out = duracao_video_seg(novo_video)
                _mn_chk, _mx_chk = duracao_cortes_config()
                if dur_out and dur_out > (_mx_chk + 2.0):
                    print(f"[clipe] recorte saiu maior que o maximo configurado ({dur_out:.1f}s > {_mx_chk}s).")
                try: os.remove(caminho_original)
                except Exception: pass
            else:
                print("[clipe] ffmpeg nao conseguiu gerar versões 16x9/9x16; vou manter arquivo original como bruto.")
        except Exception as e:
            print(f"[clipe] falhou ao recortar Replay Buffer: {e}")
    if not recorte_ok:
        # Fallback: preserva o replay bruto, mas deixa claro no nome.
        ext = os.path.splitext(caminho_original)[1] or ".mov"
        bruto = os.path.join(pasta_corte, "replay-buffer-bruto" + ext)
        try:
            shutil.move(caminho_original, bruto)
            novo_video = bruto
        except Exception as e:
            print(f"[clipe] nao deu pra mover replay bruto ({e}), mantendo caminho original")
            novo_video = caminho_original
            pasta_corte = os.path.dirname(novo_video)

    # gera o .srt só da janela exata, com timecode reiniciado em 00:00:00.
    srt = gerar_srt_corte_preciso(inicio_real, fim_real)
    salvar_arquivos_corte(pasta_corte, c_meta, video_path=novo_video, srt_text=srt, videos=videos_gerados)

    nome = os.path.basename(pasta_corte)
    print(f"[clipe] salvo na pasta: {nome}  (16x9 + 9x16 na mesma pasta + srt + legendas sociais unificadas)")
    enviar({"tipo":"clipe_salvo","caminho":novo_video,"nome":nome})

def salvar_clipe(titulo="Momento", timestamp=None, inicio=None, fim=None, motivo="manual", texto="", score=0, razao="", emocao="", funcao="", origem=""):
    """Pede pro OBS cuspir o trecho recente do Replay Buffer, guardando o titulo
    pra renomear o arquivo quando o save terminar."""
    if obs_req is None:
        enviar({"tipo":"aviso","texto":"OBS nao conectado, nao deu pra clipar."})
        return
    # tempo atual da live se nao veio especificado (clipe manual)
    agora = (time.time() - inicio_gravacao) if inicio_gravacao else 0
    fim_real = fim if fim is not None else agora
    if inicio is None:
        _mn, _mx = duracao_cortes_config()
        ini_real = max(0, fim_real - _mx)
    else:
        ini_real = inicio
    ini_real, fim_real, _dur_real = normalizar_janela_corte(ini_real, fim_real, pico=fim_real)
    clipes_pendentes.put({
        "titulo": titulo,
        "timestamp": timestamp or fmt(fim_real),
        "inicio": ini_real,
        "fim": fim_real,
        "replay_solicitado_em": agora,
        "texto": texto or titulo,
        "score": score,
        "razao": razao,
        "emocao": emocao,
        "funcao": funcao,
        "origem": origem or motivo,
    })
    try:
        if not replay_status_ativo():
            garantir_replay_buffer(silencioso=True)
            time.sleep(0.6)
        obs_req.save_replay_buffer()
        print(f"[clipe] disparado ({motivo}) - {titulo}")
    except Exception as e:
        # Tenta uma vez iniciar o buffer e salvar novamente.
        try:
            garantir_replay_buffer(silencioso=True)
            time.sleep(1.0)
            obs_req.save_replay_buffer()
            print(f"[clipe] disparado apos ativar replay ({motivo}) - {titulo}")
            return
        except Exception as e2:
            print(f"[clipe] falhou: {e2}")
            try: clipes_pendentes.get_nowait()
            except queue.Empty: pass
            enviar({"tipo":"aviso","texto":"Replay Buffer nao esta rodando no OBS. Ative em Controles > Iniciar buffer de repetição."})

# ----------------------------- PREVIEW + TRACKING -----------------------------

preview_ativo = False
vertical_ativo = bool(config_usuario.get("vertical_ativo", CONFIG["vertical_ativo"]))

def nome_cena_programa():
    """Nome da cena atual/programa no OBS."""
    if obs_req is None:
        return None
    try:
        cur = obs_req.get_current_program_scene()
        return getattr(cur, "current_program_scene_name", None) or getattr(cur, "scene_name", None)
    except Exception as e:
        print(f"[obs] nao consegui ler cena atual: {e}")
        return None

def configurar_cena_vertical(ligar=True):
    """
    Ativa/desativa o Modo Vertical dentro do FrameZero.

    O que ele faz:
      - salva 9:16 como proporcao padrao dos cortes;
      - tenta criar uma cena auxiliar 'FrameZero Vertical' no OBS com a cena atual
        aninhada, sem preview do corte.

    O painel/canvas vertical real fica por conta do Aitum Vertical instalado no OBS.
    """
    global vertical_ativo
    vertical_ativo = bool(ligar)
    config_usuario["vertical_ativo"] = vertical_ativo
    config_usuario["proporcao_corte"] = "9:16"
    salvar_config_usuario({"vertical_ativo": vertical_ativo, "proporcao_corte": "9:16"})

    if not vertical_ativo:
        print("[vertical] modo vertical desligado")
        return True, "Modo Vertical desligado"

    if obs_req is None:
        return False, "Modo Vertical ligado no painel, mas OBS nao conectado"

    cena_vertical = config_usuario.get("vertical_cena", CONFIG["vertical_cena"])
    cena_programa = nome_cena_programa()
    try:
        try:
            cenas = obs_req.get_scene_list()
            lista = getattr(cenas, "scenes", []) or []
            nomes = []
            for c in lista:
                if isinstance(c, dict):
                    nomes.append(c.get("sceneName") or c.get("scene_name"))
                else:
                    nomes.append(getattr(c, "scene_name", None) or getattr(c, "sceneName", None))
            if cena_vertical not in nomes:
                obs_req.create_scene(cena_vertical)
                print(f"[vertical] cena criada: {cena_vertical}")
        except Exception as e:
            print(f"[vertical] nao consegui verificar/criar cena: {e}")

        if cena_programa and cena_programa != cena_vertical:
            try:
                itens = obs_req.get_scene_item_list(cena_vertical)
                lista_itens = getattr(itens, "scene_items", []) or []
                ja_tem = False
                for it in lista_itens:
                    nome_fonte = (it.get("sourceName") if isinstance(it, dict) else getattr(it, "source_name", None))
                    if nome_fonte == cena_programa:
                        ja_tem = True
                        break
                if not ja_tem:
                    obs_req.create_scene_item(cena_vertical, cena_programa, True)
                    print(f"[vertical] fonte adicionada: {cena_programa} -> {cena_vertical}")
            except Exception as e:
                print(f"[vertical] nao consegui adicionar fonte/cena aninhada: {e}")

        return True, f"Modo Vertical ligado. Cena auxiliar sem preview: {cena_vertical}"
    except Exception as e:
        print(f"[vertical] falhou: {e}")
        return False, "Modo Vertical ligado no painel; cena auxiliar nao foi criada"

def obter_screenshot_obs():
    """Pega um screenshot da cena atual do OBS via WebSocket (base64 jpg)."""
    if obs_req is None:
        return None
    try:
        # cena atual
        nome_cena = nome_cena_programa()
        if not nome_cena:
            return None
        # screenshot em jpg, largura modesta pra nao pesar
        r = obs_req.get_source_screenshot(nome_cena, "jpg", 640, 360, 60)
        return getattr(r, "image_data", None)  # data:image/jpg;base64,...
    except Exception as e:
        print(f"[preview] falhou: {e}")
        return None

def loop_preview():
    """Enquanto o preview estiver ativo, manda frames da cena do OBS ao painel."""
    while True:
        if preview_ativo and obs_req is not None:
            img = obter_screenshot_obs()
            if img:
                enviar({"tipo": "preview_frame", "img": img})
            time.sleep(0.6)  # ~1.6 fps: leve, suficiente pra conferir enquadramento
        else:
            time.sleep(0.3)

def face_tracker_instalado():
    """Confere se o plugin Face Tracker existe nos caminhos padrao do OBS no macOS."""
    possiveis = [
        Path.home() / "Library/Application Support/obs-studio/plugins/obs-face-tracker.plugin",
        Path("/Library/Application Support/obs-studio/plugins/obs-face-tracker.plugin"),
    ]
    return any(p.exists() for p in possiveis)

def _extrair_nome_item(item):
    if isinstance(item, dict):
        return item.get("sourceName") or item.get("source_name") or item.get("inputName") or item.get("input_name")
    return (getattr(item, "source_name", None) or getattr(item, "sourceName", None) or
            getattr(item, "input_name", None) or getattr(item, "inputName", None))

def _fontes_da_cena_atual():
    nomes = []
    try:
        cena = nome_cena_programa()
        if not cena:
            return nomes
        itens = obs_req.get_scene_item_list(cena)
        lista = getattr(itens, "scene_items", []) or getattr(itens, "sceneItems", []) or []
        for it in lista:
            nome = _extrair_nome_item(it)
            if nome and nome not in nomes:
                nomes.append(nome)
        if cena not in nomes:
            nomes.append(cena)
    except Exception as e:
        print(f"[tracking] nao consegui listar fontes da cena: {e}")
    return nomes

def ligar_tracking(ligar):
    """
    Liga/desliga o filtro Face Tracker se ele ja estiver em alguma fonte da cena.

    Importante: o Face Tracker e um FILTRO da fonte da camera, nao da cena inteira.
    Antes o sistema tentava ligar o filtro na cena e avisava errado que o plugin
    nao estava adicionado. Agora ele procura o filtro nas fontes da cena e, se
    nao encontrar, avisa corretamente que o plugin esta instalado, mas o filtro
    ainda precisa ser colocado uma vez na camera.
    """
    if obs_req is None:
        return False, "OBS nao conectado"

    instalado = face_tracker_instalado()
    fontes = _fontes_da_cena_atual()
    candidatos = []

    # 1) Procura filtros existentes nas fontes da cena
    for fonte in fontes:
        try:
            resp = obs_req.get_source_filter_list(fonte)
            filtros = getattr(resp, "filters", []) or getattr(resp, "source_filters", []) or []
            for f in filtros:
                if isinstance(f, dict):
                    nome_filtro = f.get("filterName") or f.get("filter_name") or f.get("name")
                    tipo_filtro = f.get("filterKind") or f.get("filter_kind") or f.get("kind") or ""
                else:
                    nome_filtro = (getattr(f, "filter_name", None) or getattr(f, "filterName", None) or getattr(f, "name", None))
                    tipo_filtro = (getattr(f, "filter_kind", None) or getattr(f, "filterKind", None) or getattr(f, "kind", None) or "")
                texto = f"{nome_filtro or ''} {tipo_filtro or ''}".lower()
                if "face" in texto and "tracker" in texto:
                    candidatos.append((fonte, nome_filtro or "Face Tracker"))
        except Exception:
            pass

    # 2) Tenta nomes comuns como fallback
    for fonte in fontes:
        for nome_filtro in ("Face Tracker", "face-tracker", "Face Tracker Filter"):
            if (fonte, nome_filtro) in candidatos:
                continue
            try:
                obs_req.set_source_filter_enabled(fonte, nome_filtro, ligar)
                return True, f"Face Tracker {'ligado' if ligar else 'desligado'} em {fonte}"
            except Exception:
                pass

    # 3) Liga/desliga candidatos encontrados
    if candidatos:
        fonte, filtro = candidatos[0]
        try:
            obs_req.set_source_filter_enabled(fonte, filtro, ligar)
            return True, f"Face Tracker {'ligado' if ligar else 'desligado'} em {fonte}"
        except Exception as e:
            print(f"[tracking] falhou ao alternar {filtro} em {fonte}: {e}")

    if instalado:
        return False, "Face Tracker instalado. Falta adicionar o filtro uma vez na fonte da camera: Filtros > Filtros de Efeito > + > Face Tracker."
    return False, "Face Tracker nao instalado ou OBS nao carregou o plugin."

# ----------------------------- IA (OpenAI) -----------------------------

def cliente_openai():
    chave = config_usuario.get("openai_key", "").strip()
    if not chave or OpenAI is None:
        return None
    try:
        return OpenAI(api_key=chave)
    except Exception:
        return None

PROMPT_CORTE = """Voce analisa a transcricao de um culto cristao brasileiro e identifica
os MELHORES momentos para cortes de video curtos (Reels/Shorts).

Primeiro entenda se o trecho é PREGAÇÃO ou MÚSICA/LOUVOR.

Se for PREGAÇÃO:
- Priorize frase de impacto citavel, climax emocional, historia fechada,
  palavra direcionada, aplicacao, ministracao ou ensino claro.
- NAO marque apenas uma historia pela metade.
- Prefira o ponto onde a história vira aplicacao para quem esta ouvindo.

Se for MÚSICA/LOUVOR:
- Priorize refrão, ponte, clímax emocional, repetição bonita, subida da música,
  parte cantável e frase forte de adoração.
- Não exija explicação ou aplicação como em pregação.
- O corte pode ser um trecho bonito, emocional e completo do refrão/ponte.

Para CADA momento, avalie:
- tipo_conteudo: pregacao ou musica.
- score (0-100): potencial viral. 90+ = excepcional, 80-89 = forte.
- emocao: a emocao dominante.
- funcao: ex: gancho, climax, declaracao, chamada, historia, ensino,
  palavra_direcionada, refrao, ponte, climax_musical.
- contexto_fechado: se o corte teria sentido sozinho, com começo compreensivel
  e fim sem deixar frase/ideia musical pela metade.

Responda APENAS em JSON valido, sem texto fora dele, no formato:
{"cortes":[{"trecho":"a frase exata","score":0-100,"titulo":"titulo curto",
"razao":"por que corta","emocao":"emocao dominante","funcao":"funcao narrativa",
"tipo_conteudo":"pregacao ou musica"}]}
Se nao houver momento bom no texto, responda {"cortes":[]}."""

PROMPT_CAPITULOS = """Voce recebe a transcricao COMPLETA de uma pregacao crista
com timestamps. Divida ela em capitulos tematicos (ex: Abertura, Leitura biblica,
Desenvolvimento, Ilustracao, Ministracao, Chamada).

Responda APENAS em JSON valido, no formato:
{"capitulos":[{"inicio_seg":0,"titulo":"titulo do capitulo","tema":"tema resumido"}]}
Use o segundo de inicio de cada capitulo. Maximo 8 capitulos."""

def analisar_com_ia(texto, t_ref):
    cl = cliente_openai()
    if cl is None:
        return None
    try:
        r = cl.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role":"system","content":PROMPT_CORTE},
                      {"role":"user","content":texto}],
            temperature=0.3,
            response_format={"type":"json_object"},
        )
        dados = json.loads(r.choices[0].message.content)
        return dados.get("cortes", [])
    except Exception as e:
        print(f"[ia] erro ({e}) -> usando heuristica nesta rodada")
        return None

def gerar_capitulos_ia():
    """Gera capitulos tematicos da pregacao inteira (chamado no fim do culto)."""
    cl = cliente_openai()
    if cl is None or not linhas:
        return []
    # monta a transcricao com timestamps em segundos
    txt = "\n".join(f"[{int(l['inicio'])}s] {l['texto']}" for l in linhas)
    try:
        r = cl.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role":"system","content":PROMPT_CAPITULOS},
                      {"role":"user","content":txt[:12000]}],
            temperature=0.3,
            response_format={"type":"json_object"},
        )
        caps = json.loads(r.choices[0].message.content).get("capitulos", [])
        for c in caps:
            c["timestamp"] = fmt(c.get("inicio_seg", 0))
        return caps
    except Exception as e:
        print(f"[ia] capitulos falharam: {e}")
        return []

# ----------------------------- TRANSCRICAO -----------------------------

pendencia_transcricao = ""

def _regex_replace_ci(txt, pattern, repl):
    return re.sub(pattern, repl, txt, flags=re.IGNORECASE)


def remover_vazamento_prompt_e_hallucinacao(txt):
    """Remove frases que são instruções internas do sistema e não fala/canto real.
    Isso evita aparecer no SRT coisas como: "Não troque palavras cantadas...".
    Também reduz loops curtos típicos de Whisper em áudio musical/ruidoso.
    """
    t = str(txt or "")
    if not t.strip():
        return t
    frases_banidas = [
        "não troque palavras cantadas",
        "nao troque palavras cantadas",
        "não troque palavras por palavras parecidas",
        "nao troque palavras por palavras parecidas",
        "transcrição fiel em português brasileiro",
        "transcricao fiel em portugues brasileiro",
        "o áudio é de uma pregação",
        "o audio e de uma pregacao",
        "pregação culto podcast ou aula bíblica",
        "pregacao culto podcast ou aula biblica",
        "culto podcast ou aula bíblica",
        "culto podcast ou aula biblica",
        "a pregação, culto, podcast ou aula bíblica",
        "a pregacao culto podcast ou aula biblica",
        "não traduza",
        "nao traduza",
        "não invente palavras",
        "nao invente palavras",
        "preserve o que a pessoa falou",
        "conteúdo atual:",
        "conteudo atual:",
        "reconheça refrões",
        "reconheca refroes",
        "nomes bíblicos",
        "nomes biblicos",
    ]
    partes = re.split(r"(?<=[.!?…])\s+|\n+", t)
    limpas = []
    for parte in partes:
        p = parte.strip()
        if not p:
            continue
        n = _norm(p)
        if any(b in n for b in frases_banidas):
            continue
        # Whisper às vezes descreve áudio musical como "Música" ao invés de transcrever canto.
        # Isso NÃO é letra e não deve entrar no SRT.
        palavras_norm = [w for w in re.findall(r"[a-zà-ÿ]+", n) if w]
        if palavras_norm and all(w in {"musica", "música", "music", "song", "louvor", "canto"} for w in palavras_norm) and len(palavras_norm) <= 4:
            continue
        if re.fullmatch(r"(?:m[uú]sica|music|song|louvor|canto)(?:[.,!?:;\s-]*(?:m[uú]sica|music|song|louvor|canto)){1,}.*", p, flags=re.IGNORECASE):
            continue
        # Remove loops absurdos de filler em chunk curto, mas não remove refrão real longo.
        palavras = [w for w in re.findall(r"[A-Za-zÀ-ÿ]+", n) if w]
        if len(palavras) >= 5:
            unicas = set(palavras)
            if len(unicas) <= 2 and len(palavras) >= 6:
                continue
        # Ex.: "E aí, aí, aí, aí..." normalmente é hallucinação/filler.
        if re.fullmatch(r"(?:e\s+)?(?:ai|aí)(?:[,\s.?!…-]*(?:ai|aí)){3,}.*", n):
            continue
        limpas.append(p)
    return " ".join(limpas).strip()

def corrigir_legenda_por_contexto(txt):
    """Correção leve de legenda antes de salvar/transmitir.
    Não muda timecode. Só corrige palavras que o Whisper costuma errar em pregação
    e nomes bíblicos pelo contexto, evitando SRT com 'a Braão', 'serba', etc.
    """
    if not _cfg_bool("corrigir_legenda_contexto", True):
        return str(txt or "")
    t = remover_vazamento_prompt_e_hallucinacao(str(txt or ""))
    if not t.strip():
        return t

    # Em modo música, não aplicar correções de pregação/bíblia que podem trocar letra cantada.
    # Música deve preservar o que foi cantado; a IA só usa isso para escolher refrão/clímax.
    tipo = str(config_usuario.get("tipo_conteudo", CONFIG.get("tipo_conteudo", "pregacao"))).lower()
    if tipo == "musica":
        t = re.sub(r"\s+", " ", t).strip()
        return t.replace(" ,", ",").replace(" .", ".").replace(" ?", "?").replace(" !", "!")

    # Correções leves por idioma do Modo Global.
    perfil = perfil_idioma_atual()
    for original, correto in (perfil.get("god_terms") or {}).items():
        try:
            t = _regex_replace_ci(t, rf"\b{re.escape(original)}\b", correto)
        except Exception:
            pass

    # As regras contextuais pesadas abaixo são específicas de português.
    if whisper_language_atual() not in ("pt", "pt-BR", "pt-PT"):
        t = re.sub(r"\s+", " ", t).strip()
        return t.replace(" ,", ",").replace(" .", ".").replace(" ?", "?").replace(" !", "!")

    # nomes bíblicos e termos comuns em pregações
    regras = [
        (r"\b(?:a|à)\s+braão\b", "Abraão"),
        (r"\bbraão\b", "Abraão"),
        (r"\babr[aã]o\b", "Abraão"),
        (r"\ba\s+br[aã]o\b", "Abraão"),
        (r"\bsar[aá]\b", "Sara"),
        (r"\bagar\b", "Agar"),
        (r"\bismael\b", "Ismael"),
        (r"\bno[eé]\b", "Noé"),
        (r"\barca de no[eé]\b", "Arca de Noé"),
        (r"\bserba\b", "serva"),
        (r"\bserva!", "serva!"),
        (r"\bo senhor\b", "o Senhor"),
        (r"\bdo senhor\b", "do Senhor"),
        (r"\bsenhor\b", "Senhor"),
        (r"\bdeus\b", "Deus"),
    ]
    for pat, rep in regras:
        t = _regex_replace_ci(t, pat, rep)

    # correções contextuais vistas no SRT enviado pelo usuário
    contextuais = [
        (r"Ela est[aá] sendo criada", "Ela está sendo guiada"),
        (r"est[aá] sendo criada", "está sendo guiada"),
        (r"garantia de ser andou", "garantia dizendo"),
        (r"garantia de ser ando", "garantia dizendo"),
        (r"ser andou", "dizendo"),
        (r"para Abraão, n[aã]o deu\s+para ela, mas deu para Abraão", "para Abraão; não deu para ela, mas deu para Abraão"),
        (r"filho dela, agora", "filho dela. Agora"),
        (r"falou isso com ela\? N[aã]o, mas falou\s+com Abraão", "falou isso com ela? Não, mas falou com Abraão"),
        (r"A Arca de Noé, que n[aã]o tinha\.", "A Arca de Noé, que não tinha..."),
        (r"O Timão\?", "O timão?"),
        (r"n[aã]o tinha Timão", "não tinha timão"),
    ]
    for pat, rep in contextuais:
        t = _regex_replace_ci(t, pat, rep)

    # limpeza final de pontuação e espaços
    t = re.sub(r"\s+", " ", t).strip()
    t = t.replace(" ,", ",").replace(" .", ".").replace(" ?", "?").replace(" !", "!")
    t = t.replace("..", ".") if "..." not in t else t
    return t

def limpar_texto_transcricao(txt):
    txt = re.sub(r"\s+", " ", (txt or "")).strip()
    # Corrige alguns artefatos comuns de chunks pequenos/ruidosos.
    txt = txt.replace(" ,", ",").replace(" .", ".").replace(" ?", "?").replace(" !", "!")
    txt = corrigir_legenda_por_contexto(txt)
    return txt

def dividir_linhas_continuas(txt, max_chars=360):
    """Quebra o bloco em linhas mais naturais, sem deixar cada segmento do ASR virar uma frase picotada."""
    txt = limpar_texto_transcricao(txt)
    if not txt:
        return []
    partes = re.split(r"(?<=[.!?…])\s+", txt)
    linhas_out = []
    atual = ""
    for parte in partes:
        parte = parte.strip()
        if not parte:
            continue
        if not atual:
            atual = parte
        elif len(atual) + 1 + len(parte) <= max_chars:
            atual += " " + parte
        else:
            linhas_out.append(atual.strip())
            atual = parte
    if atual:
        linhas_out.append(atual.strip())
    # Se o Whisper não pontuou, não fatiar em micro pedaços: só quebra se estiver enorme.
    final = []
    for linha in linhas_out:
        if len(linha) <= max_chars + 80:
            final.append(linha)
        else:
            palavras = linha.split()
            buf = ""
            for w in palavras:
                if len(buf) + len(w) + 1 > max_chars:
                    final.append(buf.strip())
                    buf = w
                else:
                    buf = (buf + " " + w).strip()
            if buf:
                final.append(buf.strip())
    return [x for x in final if len(x.strip()) >= 8]

def registrar_corte(texto, score, titulo, razao, t, emocao="", funcao="", origem="local"):
    nivel = "forte" if int(score) >= 90 else ("possivel" if int(score) >= 80 else "baixo")
    corte = {"tipo":"corte","texto":texto,"score":score,"titulo":titulo,
             "razao":razao,"emocao":emocao,"funcao":funcao,"origem":origem,
             "nivel": nivel,
             "tempo":round(t,1),"timestamp":fmt(t)}
    if bool(config_usuario.get("corte_exato_automatico", CONFIG.get("corte_exato_automatico", True))):
        corte = enriquecer_corte_com_janela(corte)
    cortes.append(corte)
    enviar(corte)
    if corte.get("inicio_exato") is not None and corte.get("fim_exato") is not None:
        print(f"[CORTE {corte.get('score', score)} {nivel.upper()}] {fmt(t)} - {titulo} | exato {fmt(corte['inicio_exato'])} até {fmt(corte['fim_exato'])} ({corte.get('duracao_exata')}s)")
    else:
        print(f"[CORTE {score} {nivel.upper()}] {fmt(t)} - {titulo} ({emocao})")
    # dispara clipe automatico se passar do limiar
    if score >= current_limiar():
        if corte_local_repetido(texto, t):
            print(f"[CORTE] duplicado/cooldown ignorado: {fmt(t)}")
            return
        antes = int(config_usuario.get("margem_antes_corte", CONFIG.get("margem_antes_corte", 10)))
        depois = int(config_usuario.get("margem_depois_corte", CONFIG.get("margem_depois_corte", 8)))
        ini_clip = corte.get("inicio_exato", max(0, t - antes))
        fim_clip = corte.get("fim_exato", t + depois)
        ini_clip, fim_clip, _dur_clip = normalizar_janela_corte(ini_clip, fim_clip, pico=t)
        salvar_clipe(titulo=titulo, timestamp=fmt(t), inicio=ini_clip,
                     fim=fim_clip, motivo=f"{origem}: {titulo}", texto=texto,
                     score=score, razao=razao, emocao=emocao, funcao=funcao, origem=origem)



def cortes_contextuais_score60(linhas_ref):
    """Fallback leve para a v81e-score60.
    Quando Gemini fica conservador demais, detecta blocos de assunto/história já úteis
    para post com rating 60+, sem exigir frase viral perfeita.
    """
    if not linhas_ref:
        return []
    try:
        limiar = current_limiar()
    except Exception:
        limiar = 60
    if limiar > 60:
        return []
    # Usa uma janela recente de até 75s, pulando boas-vindas/repetição bíblica quando possível.
    pares = [(float(tt or 0), (tx or '').strip()) for tt, tx in linhas_ref if (tx or '').strip()]
    if not pares:
        return []
    end_t = pares[-1][0]
    candidatos_inicio = []
    gatilhos_inicio = re.compile(r"\b(voc[eê] sabe|existem algumas pessoas|quem conhece|tem uma|tem um|eu lembro|sabe aquela|uma vez|quando eu|par[aá]bola|hist[oó]ria|olha|presta aten[cç][aã]o)\b", re.I)
    lixo_inicio = re.compile(r"\b(muito bom estar aqui|boa noite|receber todos|abra a sua b[ií]blia|lucas cap[ií]tulo|lucas 18|am[eé]m)\b", re.I)
    for idx, (tt, tx) in enumerate(pares):
        if end_t - tt > 80:
            continue
        if gatilhos_inicio.search(tx) and not lixo_inicio.search(tx):
            candidatos_inicio.append(idx)
    start_idx = candidatos_inicio[0] if candidatos_inicio else 0
    # Se começou com boas-vindas/bíblia, avança até o primeiro trecho mais narrativo.
    while start_idx < len(pares) - 1 and lixo_inicio.search(pares[start_idx][1]):
        start_idx += 1
    trecho_pares = pares[start_idx:]
    if not trecho_pares:
        return []
    start_t = trecho_pares[0][0]
    if end_t - start_t < 22:
        return []
    if end_t - start_t > 75:
        # Mantém os últimos 60-70s do mesmo assunto se a janela ficou grande demais.
        trecho_pares = [(tt, tx) for tt, tx in trecho_pares if end_t - tt <= 70]
        if not trecho_pares:
            return []
        start_t = trecho_pares[0][0]
    texto = " ".join(tx for _, tx in trecho_pares).strip()
    normal = _norm(texto)
    palavras = [p for p in normal.split() if p]
    if len(palavras) < 45:
        return []
    # Pontuação de assunto: não busca viral perfeito; busca post aproveitável.
    score = 55
    razoes = []
    if re.search(r"\b(quem conhece|voc[eê] sabe|existem algumas pessoas|tem gente|algumas pessoas)\b", normal):
        score += 8; razoes.append("gancho de identificação")
    if re.search(r"\b(persist|negoci|barganh|conseguir o que quer|talento natural)\b", normal):
        score += 10; razoes.append("assunto claro")
    if re.search(r"\b(eu lembro|quando eu|uma vez|historia|história|25 de mar[cç]o|s[aã]o paulo)\b", normal):
        score += 8; razoes.append("exemplo/história")
    if re.search(r"\b(n[aã]o importa|at[eé] conseguir|sempre|natural|interessante|justa)\b", normal):
        score += 5; razoes.append("tensão/curiosidade")
    if re.search(r"\b(muito bom estar aqui|abra a sua b[ií]blia|lucas 18)\b", normal) and not re.search(r"\b(persist|negoci|barganh|hist[oó]ria|quem conhece)\b", normal):
        return []
    score = min(78, max(60, score))
    if score < limiar:
        return []
    titulo = "Pessoas persistentes conseguem o que querem" if re.search(r"\b(persist|negoci|barganh)\b", normal) else titulo_local(texto, "curiosidade", "gancho")
    return [{
        "trecho": texto,
        "score": score,
        "titulo": titulo,
        "razao": ", ".join(razoes) if razoes else "assunto com contexto suficiente para post",
        "emocao": "curiosidade",
        "funcao": "gancho/contexto",
        "tempo": start_t,
    }]

def processar_analise_cortes(bloco_txt, t_ref, t_fim, linhas_ref=None):
    """Analisa cortes sem travar a transcrição ao vivo.

    v81b: quando Gemini está ativo, ele vira o diretor de edição.
    Ou seja: o detector local não dispara primeiro; o Gemini observa contexto maior
    e só libera corte quando entender que o raciocínio está fechado.
    Se Gemini falhar/limitar, o detector local entra como fallback.
    """
    linhas_ref = linhas_ref or []
    gemini_pronto = bool(config_usuario.get("gemini_enabled", CONFIG.get("gemini_enabled", False))) and bool(str(config_usuario.get("gemini_api_key", "") or "").strip())

    if gemini_pronto:
        try:
            cortes_ia = analisar_com_gemini(bloco_txt, t_ref, t_fim)
            # None = falha/sem internet/limite/chave ruim -> fallback local.
            # [] = Gemini analisou e decidiu não cortar/aguaradar -> não faz nada.
            if cortes_ia is not None:
                if len(cortes_ia) == 0 and current_limiar() <= 60:
                    # Gemini pode ser conservador em introduções de pregação.
                    # Com rating 60+, liberamos também blocos de assunto/história úteis para post.
                    cortes_ia = cortes_contextuais_score60(linhas_ref)
                if len(cortes_ia) > 0:
                    limite_ia = current_limiar()
                    for c in cortes_ia[:1]:
                        if int(c.get("score", 0) or 0) < limite_ia:
                            continue
                        t_corte = float(c.get("tempo", t_ref))
                        trecho_ref = (c.get("trecho") or "")[:18].lower()
                        if trecho_ref:
                            for (tt, tx) in linhas_ref:
                                if trecho_ref in tx.lower():
                                    t_corte = tt; break
                        registrar_corte(c.get("trecho", ""), int(c.get("score", 0)),
                                        c.get("titulo", "Momento"), c.get("razao", ""), t_corte,
                                        emocao=c.get("emocao", ""), funcao=c.get("funcao", ""), origem="gemini-score60")
                return
        except Exception as e:
            print(f"[gemini] analise falhou; usando fallback local: {e}")

    # Fallback / modo sem Gemini: detector local respeitando o modo escolhido.
    disparou_local = False
    try:
        modo_corte = corte_modo_atual()
        candidatos_locais = cortes_locais(linhas_ref)
        if candidatos_locais:
            limite = current_limiar()
            max_itens = 2 if modo_corte == "fast" else 1
            origem = "fast-local" if modo_corte == "fast" else "corte-seguro"
            for c in candidatos_locais[:max_itens]:
                if int(c.get("score", 0)) < limite:
                    continue
                registrar_corte(c["trecho"], int(c["score"]), c["titulo"], c["razao"], c["tempo"],
                                emocao=c.get("emocao", ""), funcao=c.get("funcao", ""), origem=origem)
                disparou_local = True
                if modo_corte == "standard":
                    break
    except Exception as e:
        print(f"[local] analise de cortes falhou: {e}")

    # VPS/IA local antiga fica apenas como refino quando Gemini não está ativo.
    if not gemini_pronto:
        try:
            cortes_ia = analisar_com_vps(bloco_txt, t_ref, t_fim)
            if cortes_ia is not None and len(cortes_ia) > 0:
                modo_corte = corte_modo_atual()
                limite_ia = current_limiar() if modo_corte == "standard" else max(60, current_limiar() - 4)
                for c in cortes_ia[:(1 if modo_corte == "standard" else 2)]:
                    if int(c.get("score", 0) or 0) < limite_ia:
                        continue
                    t_corte = float(c.get("tempo", t_ref))
                    registrar_corte(c.get("trecho", ""), int(c.get("score", 0)),
                                    c.get("titulo", "Momento"), c.get("razao", ""), t_corte,
                                    emocao=c.get("emocao", ""), funcao=c.get("funcao", ""), origem="vps-refino")
                return
        except Exception as e:
            print(f"[vps-ia] analise async falhou: {e}")

    if not disparou_local:
        pass

def worker_analise_cortes():
    while True:
        item = fila_analise.get()
        if item is None:
            continue
        try:
            processar_analise_cortes(*item)
        except Exception as e:
            print(f"[analise] worker falhou: {e}")


def whisper_local_disponivel():
    """v75: transcrição local oficial é MLX Whisper no Apple Silicon."""
    return bool(TEM_MLX)

def modo_transcricao_efetivo(modo):
    """v75: tudo roda local/offline com MLX Whisper.
    Se o painel antigo mandar hibrido/vps, aceitamos a escolha visual,
    mas o áudio nunca vai para VPS nem /transcribe.
    """
    modo = str(modo or 'local').lower().strip()
    if modo not in ('local', 'hibrido', 'vps'):
        modo = 'local'
    if modo in ('hibrido', 'vps'):
        print(f"[config] painel pediu {modo}, mas esta versão usa transcrição local/offline quando possível. Transcrevendo local.")
    if not (TEM_MLX or TEM_FASTER_WHISPER):
        print("[asr] Nenhum motor local instalado. No Windows instale faster-whisper; no Mac Apple Silicon instale mlx-whisper.")
    return 'local'

def cuda_disponivel_local():
    return False

def modelo_faster_atual():
    perfil = str(config_usuario.get("whisper_local_perfil", CONFIG.get("whisper_local_perfil", "leve"))).lower().strip()
    # Modelos compatíveis com faster-whisper no Windows.
    return "large-v3-turbo" if perfil == "pro" else "small"

def escolher_whisper_local_runtime():
    perfil = str(config_usuario.get("whisper_local_perfil", CONFIG.get("whisper_local_perfil", "leve"))).lower().strip()
    if perfil not in ("leve", "pro"):
        perfil = "leve"
    if platform.system().lower().startswith("win") or (not TEM_MLX and TEM_FASTER_WHISPER):
        modelo = modelo_faster_atual()
        return modelo, "faster-whisper", "cpu", perfil, False
    modelo = modelo_mlx_atual()
    return modelo, "mlx-metal", "metal", perfil, True

def loop_transcricao():
    global ultima_ia, texto_desde_ia, texto_contexto_ia, pendencia_transcricao
    modo_configurado = str(config_usuario.get("transcricao_modo", CONFIG.get("transcricao_modo", "hibrido"))).lower().strip()
    modo_transcricao = modo_transcricao_efetivo(modo_configurado)
    modelo = None

    def carregar_modelo_local():
        nonlocal modelo
        if modelo is None:
            if not (TEM_MLX or TEM_FASTER_WHISPER):
                raise RuntimeError("Nenhum motor local instalado. Windows: faster-whisper. Mac Apple Silicon: mlx-whisper.")
            nome_modelo, device, compute, perfil, tem_gpu = escolher_whisper_local_runtime()
            engine = "faster-whisper" if device == "faster-whisper" else "mlx-whisper"
            modelo = {"engine":engine, "modelo":nome_modelo, "perfil":perfil}
            if engine == "faster-whisper":
                print(f"[faster-local] perfil={perfil} modelo={nome_modelo} device=CPU compute=int8")
                print("[faster-local] pronto. Na primeira vez o modelo pode baixar do Hugging Face.")
            else:
                print(f"[mlx-local] perfil={perfil} modelo={nome_modelo} device=Apple Silicon/Metal")
                print("[mlx-local] pronto. Na primeira vez o modelo pode baixar do Hugging Face.")
        return modelo

    if modo_transcricao in ("vps", "hibrido"):
        print(f"[vps-asr] usando API: {_vps_url()}")
        print(f"[vps-ia] usando analise local DeepSeek: {_vps_url(config_usuario.get('whisper_vps_analyze_endpoint', CONFIG.get('whisper_vps_analyze_endpoint', '/analyze-text')))}")
        ok_vps, msg_vps = testar_vps_whisper()
        print(f"[vps-asr] health: {msg_vps}")
        modo_status = "hibrido" if modo_transcricao == "hibrido" else "vps"
        enviar_vps_status(ok=ok_vps, msg=("VPS online para analise/refino" if modo_transcricao == "hibrido" and ok_vps else msg_vps), modo=modo_status, url=_vps_url())
        if modo_transcricao == "vps":
            if config_usuario.get("vps_fallback_local", CONFIG.get("vps_fallback_local", False)):
                print("[vps-asr] fallback local ativo se a VPS falhar.")
            else:
                print("[vps-asr] modo VPS puro: MLX Whisper local NAO sera carregado.")
        if modo_transcricao == "hibrido":
            print("[tempo-real] modo hibrido: Whisper LOCAL transcreve ao vivo; VPS/Ollama refina texto/contexto e decide cortes. Audio nao vai para /transcribe.")
            carregar_modelo_local()
    else:
        enviar_vps_status(ok=True, msg=("Faster-Whisper local/offline" if platform.system().lower().startswith("win") else "MLX local/offline"), modo="local", url="")
        carregar_modelo_local()

    # v79: Padrao = MLX Corte Seguro; Turbo = OpenAI Realtime.
    transcricao_motor = str(config_usuario.get("transcricao_motor", CONFIG.get("transcricao_motor", "padrao"))).lower().strip()
    if transcricao_motor not in ("padrao", "turbo"):
        transcricao_motor = "padrao"
    if transcricao_motor == "turbo":
        bloco_segundos_atual = float(config_usuario.get("openai_realtime_commit_segundos", CONFIG.get("openai_realtime_commit_segundos", 12.0)))
        print(f"[turbo] OpenAI Realtime ativo: chunks de {bloco_segundos_atual:.1f}s delay={config_usuario.get('openai_realtime_delay','high')}")
    else:
        bloco_segundos_atual = float(config_usuario.get("bloco_segundos_corte_seguro", config_usuario.get("bloco_segundos", 15.0)))
        print(f"[padrao] MLX Corte Seguro: blocos de {bloco_segundos_atual:.1f}s")
    amostras = int(CONFIG["sample_rate"]*bloco_segundos_atual)
    buffer = np.zeros((0,CONFIG["canais"]),dtype=np.float32)

    while True:
        try: chunk = fila_audio.get(timeout=1.0)
        except queue.Empty: continue

        if not gravando:
            buffer = np.zeros((0,CONFIG["canais"]),dtype=np.float32); continue
        if not bool(config_usuario.get("transcricao_ativa", CONFIG.get("transcricao_ativa", True))):
            buffer = np.zeros((0,CONFIG["canais"]),dtype=np.float32); continue

        buffer = np.concatenate([buffer,chunk],axis=0)
        if len(buffer) < amostras: continue

        bloco = buffer[:amostras]; buffer = buffer[amostras:]
        audio = preparar_audio_whisper(bloco[:,0])
        rms = float(np.sqrt(np.mean(np.square(audio)))) if len(audio) else 0.0
        volume_historico.append(rms)
        if len(volume_historico) > 60:
            del volume_historico[:-60]
        base_vol = float(np.median(volume_historico)) if volume_historico else rms
        pico_bloco = bool(rms > max(0.025, base_vol * 1.45))
        min_rms = float(config_usuario.get("audio_min_rms_para_status", CONFIG.get("audio_min_rms_para_status", 0.006)))
        if rms >= min_rms:
            enviar_audio_status(ok=True, rms=rms, msg="áudio entrando", origem="captura")
        else:
            enviar_audio_status(ok=False, rms=rms, msg="áudio muito baixo ou sem sinal. Confira OBS > Monitoring Device = BlackHole e Monitor and Output.", origem="captura")
        t0 = (time.time()-bloco_segundos_atual) - inicio_gravacao
        if t0 < 0: t0 = 0

        # Modo pode ser alterado pelo painel: padrao ou turbo.
        modo_configurado = str(config_usuario.get("transcricao_modo", CONFIG.get("transcricao_modo", "local"))).lower().strip()
        modo_transcricao = modo_transcricao_efetivo(modo_configurado)
        transcricao_motor = str(config_usuario.get("transcricao_motor", CONFIG.get("transcricao_motor", "padrao"))).lower().strip()
        if transcricao_motor not in ("padrao", "turbo"):
            transcricao_motor = "padrao"
        if modo_transcricao == "vps" and modelo is not None and not config_usuario.get("vps_fallback_local", CONFIG.get("vps_fallback_local", False)):
            modelo = None
            gc.collect()
            print("[mlx-local] descarregado: modo VPS puro ativo.")
        origem_transcricao = modo_transcricao
        try:
            if transcricao_motor == "turbo":
                texto_bloco, segs_lista = transcrever_openai_realtime(audio)
                origem_transcricao = "openai-turbo"
            elif modo_transcricao == "vps" and config_usuario.get("vps_enviar_audio_ao_vivo", CONFIG.get("vps_enviar_audio_ao_vivo", False)):
                texto_vps, segmentos_vps = transcrever_vps(audio)
                enviar_vps_status(ok=True, msg="VPS respondeu", modo="vps", url=_vps_url())
                texto_bloco = limpar_texto_transcricao(limpar_tags_asr(texto_vps))
                if texto_whisper_invalido(texto_bloco, origem="vps"):
                    raise RuntimeError("VPS retornou texto invalido; bloqueado para nao gerar SRT/corte errado")
                # adapta segmentos da VPS para o mesmo formato usado pelo ASR local
                class SegObj:
                    def __init__(self, start, end, text):
                        self.start = float(start or 0)
                        self.end = float(end or bloco_segundos_atual)
                        self.text = text or ""
                segs_lista = []
                for sg in segmentos_vps:
                    if isinstance(sg, dict):
                        segs_lista.append(SegObj(sg.get('start', sg.get('inicio', 0)), sg.get('end', sg.get('fim', bloco_segundos_atual)), sg.get('text', sg.get('texto', ''))))
                if not segs_lista:
                    segs_lista = [SegObj(0, bloco_segundos_atual, texto_bloco)]
            else:
                texto_bloco, segs_lista = transcrever_local(carregar_modelo_local(), audio)
                origem_transcricao = "local"
        except Exception as e:
            erro = str(e)
            if transcricao_motor == "turbo":
                print(f"[turbo] falhou: {e}. Voltando para Padrao/MLX neste bloco.")
                try:
                    texto_bloco, segs_lista = transcrever_local(carregar_modelo_local(), audio)
                    origem_transcricao = "local-fallback-turbo"
                except Exception as e2:
                    print(f"[turbo] fallback MLX tambem falhou: {e2}")
                    continue
            elif modo_transcricao != "vps" and ("MLX Whisper local" in erro or "whisper" in erro.lower() or "texto invalido" in erro.lower()):
                print(f"[mlx-local] indisponivel: {e}. Use modo VPS ou instale MLX Whisper local no venv.")
                enviar_vps_status(ok=True, msg="MLX Whisper local indisponivel; usando VPS atual", modo="vps", url=_vps_url())
                try:
                    texto_vps, segmentos_vps = transcrever_vps(audio)
                    texto_bloco = limpar_texto_transcricao(limpar_tags_asr(texto_vps))
                    if texto_whisper_invalido(texto_bloco, origem="vps"):
                        raise RuntimeError("VPS retornou texto invalido; bloqueado para nao gerar SRT/corte errado")
                    class SegObj:
                        def __init__(self, start, end, text):
                            self.start = float(start or 0); self.end = float(end or bloco_segundos_atual); self.text = text or ""
                    segs_lista = [SegObj(0, bloco_segundos_atual, texto_bloco)]
                    origem_transcricao = "vps"
                except Exception as e2:
                    print(f"[vps-asr] falhou depois do fallback automatico para VPS: {e2}")
                    enviar_vps_status(ok=False, msg=f"VPS falhou: {e2}", modo="vps", url=_vps_url())
                    continue
            else:
                print(f"[vps-asr] falhou: {e}")
                usar_fallback = bool(config_usuario.get("vps_fallback_local", CONFIG.get("vps_fallback_local", False)))
                enviar_vps_status(ok=False, msg=f"VPS falhou: {e}", modo="fallback" if usar_fallback else "vps", url=_vps_url())
                if usar_fallback and str(config_usuario.get("transcricao_modo", CONFIG.get("transcricao_modo", "vps"))).lower() != "vps":
                    texto_bloco, segs_lista = transcrever_local(carregar_modelo_local(), audio)
                    origem_transcricao = "local-fallback"
                else:
                    print("[vps-asr] VPS falhou, mas fallback local esta desligado. Nao vou carregar MLX Whisper local.")
                    continue
        if pendencia_transcricao:
            texto_bloco = limpar_texto_transcricao(pendencia_transcricao + " " + texto_bloco)
            pendencia_transcricao = ""

        # Segurança final: nada de lixo do ASR no painel, SRT ou gatilho de corte.
        if texto_whisper_invalido(texto_bloco, origem=origem_transcricao):
            print(f"[whisper-{origem_transcricao}] bloco descartado: texto invalido/sem PT-BR confiavel")
            continue

        # No modo VPS tempo real, mostra a fala assim que chega para não parecer travado.
        # No modo local/refinado, ainda pode segurar frase incompleta para juntar melhor.
        segurar_incompleta = bool(config_usuario.get("segurar_frase_incompleta_ao_vivo", CONFIG.get("segurar_frase_incompleta_ao_vivo", False)))
        if segurar_incompleta and texto_bloco and not re.search(r"[.!?…]$", texto_bloco) and len(texto_bloco) < 260:
            pendencia_transcricao = texto_bloco
            texto_bloco = ""

        linhas_bloco = dividir_linhas_continuas(texto_bloco)
        if linhas_bloco:
            seg_start = segs_lista[0].start if segs_lista else 0
            seg_end = segs_lista[-1].end if segs_lista else bloco_segundos_atual
            dur = max(1.0, float(seg_end - seg_start))
            for idx, txt in enumerate(linhas_bloco):
                frac = idx / max(1, len(linhas_bloco))
                t = t0 + float(seg_start) + dur * frac
                linha = {"tipo":"linha","texto":txt,"inicio":round(t,2),
                         "fim":round(min(t0+seg_end, t + dur/max(1,len(linhas_bloco))),2),"timestamp":fmt(t),
                         "volume_rms":round(rms,4),"pico_voz":pico_bloco,"transcricao_origem":origem_transcricao,
                         "language_profile":perfil_id_atual()}
                if live_translation_ativa():
                    trad = traduzir_texto_ao_vivo(txt)
                    if trad:
                        linha["traducao"] = trad
                        linha["traducao_idioma"] = config_usuario.get("live_translation_target", "en")
                volume_picos[round(t,1)] = pico_bloco
                # limpa mapa antigo para não crescer indefinidamente
                for kk in list(volume_picos.keys()):
                    try:
                        if t - float(kk) > 900:
                            volume_picos.pop(kk, None)
                    except Exception:
                        pass
                linhas.append(linha); enviar(linha)
                try:
                    nations_ingest_line(linha)
                except Exception as e:
                    print(f"[nations] ingest falhou: {e}")
                texto_desde_ia.append((t,txt))
                texto_contexto_ia.append((t,txt))
                janela_ctx = float(config_usuario.get("gemini_janela_contexto_seg", CONFIG.get("gemini_janela_contexto_seg", 180.0)) or 180.0)
                texto_contexto_ia = [(tt,tx) for (tt,tx) in texto_contexto_ia if t - float(tt) <= janela_ctx]
                print(f"[{linha['timestamp']}] {txt}")

        # de tempos em tempos, manda o acumulado pra análise de cortes SEM travar a transcrição.
        # A análise da VPS/DeepSeek pode demorar; o texto ao vivo não pode ficar esperando isso.
        gemini_pronto = bool(config_usuario.get("gemini_enabled", CONFIG.get("gemini_enabled", False))) and bool(str(config_usuario.get("gemini_api_key", "") or "").strip())
        intervalo_analise = float(config_usuario.get("gemini_intervalo_seg", CONFIG.get("gemini_intervalo_seg", 60.0)) if gemini_pronto else config_usuario.get("intervalo_ia_seg", CONFIG.get("intervalo_ia_seg", 15)))
        if phrase_ai_ativa():
            # AI Boost opcional: analisa mais perto do tempo real. Pode consumir mais API.
            intervalo_analise = 4.0 if gemini_pronto else 6.0
        elif corte_modo_atual() == "standard":
            intervalo_analise = max(30.0 if gemini_pronto else 15.0, intervalo_analise)
        else:
            intervalo_analise = min(intervalo_analise, 8.0) if not gemini_pronto else max(30.0, intervalo_analise)
        base_analise = texto_contexto_ia if gemini_pronto else texto_desde_ia
        if time.time()-ultima_ia >= intervalo_analise and base_analise:
            bloco_txt = " ".join(x[1] for x in base_analise)
            t_ref = base_analise[0][0]
            t_fim = base_analise[-1][0] if base_analise else t_ref
            linhas_ref = list(base_analise)
            try:
                if bool(config_usuario.get("vps_analyze_async", CONFIG.get("vps_analyze_async", True))):
                    fila_analise.put((bloco_txt, t_ref, t_fim, linhas_ref))
                else:
                    processar_analise_cortes(bloco_txt, t_ref, t_fim, linhas_ref)
            except Exception as e:
                print(f"[analise] nao conseguiu enfileirar: {e}")
            texto_desde_ia = []; ultima_ia = time.time()




# ----------------------------- WEBSOCKET -----------------------------








# ----------------------------- FRAMEZERO NATIONS CONSOLIDATED CORE V48 -----------------------------
# Bloco consolidado, sem patch incremental por indentação.
# Responsável por: status WS, pareamento, heartbeat remoto, logs, languages_live e hook da transcrição.
import uuid as _fz_nations_uuid
import socket as _fz_nations_socket
import subprocess as _fz_nations_subprocess
import urllib.request as _fz_nations_urlrequest
import urllib.error as _fz_nations_urlerror

NATIONS_VERSION = "0.1.54-core"
NATIONS_BRIDGE_SECRET_DEFAULT = "150824@nations"
NATIONS_LANGUAGE_CATALOG = [
    {"code":"pt-BR","name":"Português (Brasil)","flag":"🇧🇷","engine":"piper"},
    {"code":"pt-PT","name":"Português (Portugal)","flag":"🇵🇹","engine":"piper"},
    {"code":"en-US","name":"Inglês","flag":"🇺🇸","engine":"piper"},
    {"code":"es-ES","name":"Espanhol","flag":"🇪🇸","engine":"piper"},
    {"code":"fr-FR","name":"Francês","flag":"🇫🇷","engine":"piper"},
    {"code":"de-DE","name":"Alemão","flag":"🇩🇪","engine":"piper"},
    {"code":"it-IT","name":"Italiano","flag":"🇮🇹","engine":"piper"},
    {"code":"nl-NL","name":"Holandês","flag":"🇳🇱","engine":"piper"},
    {"code":"pl-PL","name":"Polonês","flag":"🇵🇱","engine":"piper"},
    {"code":"ru-RU","name":"Russo","flag":"🇷🇺","engine":"piper"},
    {"code":"uk-UA","name":"Ucraniano","flag":"🇺🇦","engine":"piper"},
    {"code":"ar-SA","name":"Árabe","flag":"🇸🇦","engine":"piper"},
    {"code":"zh-CN","name":"Mandarim","flag":"🇨🇳","engine":"piper"},
    {"code":"hi-IN","name":"Hindi","flag":"🇮🇳","engine":"piper"},
    {"code":"ja-JP","name":"Japonês","flag":"🇯🇵","engine":"piper"},
    {"code":"ko-KR","name":"Coreano","flag":"🇰🇷","engine":"piper"},
    {"code":"id-ID","name":"Indonésio","flag":"🇮🇩","engine":"piper"},
    {"code":"vi-VN","name":"Vietnamita","flag":"🇻🇳","engine":"piper"},
    {"code":"tl-PH","name":"Tagalog","flag":"🇵🇭","engine":"piper"},
    {"code":"sw-KE","name":"Suaíli","flag":"🇰🇪","engine":"piper"},
]
NATIONS_ALL_LANGUAGE_CODES = [x["code"] for x in NATIONS_LANGUAGE_CATALOG]


NATIONS_ROOT = Path(__file__).resolve().parent.parent
NATIONS_DIR = NATIONS_ROOT / "nations"
NATIONS_DIR.mkdir(parents=True, exist_ok=True)
NATIONS_CONFIG_PATH = NATIONS_DIR / "nations_config.json"
NATIONS_LOGS = []
NATIONS_QUEUE = queue.Queue(maxsize=2000)
NATIONS_AUDIO_QUEUE = queue.Queue(maxsize=120)
NATIONS_TTS_QUEUE = queue.Queue(maxsize=120)
NATIONS_TTS_LAST_TEXT = {"text":"", "at":0}
NATIONS_AUDIO_BUFFER = np.zeros((0,), dtype=np.float32)
NATIONS_AUDIO_SEQ = {"original": 0, "translated": 0}
NATIONS_AUDIO_LAST_LOG = {"original": 0, "translated": 0}
NATIONS_STARTED_AT = time.time()

nations_runtime = {
    "installed": True,
    "running": False,
    "paired": False,
    "remote_connected": False,
    "processed_lines": 0,
    "generated_audio_blocks": 0,
    "listeners": 0,
    "last_text": "",
    "last_text_at": None,
    "last_heartbeat_at": None,
    "last_heartbeat_ok": False,
    "last_heartbeat_error": "",
    "last_heartbeat_status": None,
    "tts_provider_current": None,
    "tts_generation": 0,
}

def _fz_nations_queue_clear(q):
    try:
        while True:
            q.get_nowait()
    except Exception:
        pass

def _fz_nations_tts_provider_from_cfg(cfg=None):
    try:
        cfg = cfg or _fz_nations_load_config()
        tts = cfg.get("tts") or cfg.get("tts_config") or {}
        if isinstance(tts, dict):
            item = tts.get("en-US") or tts.get("en") or {}
            if isinstance(item, dict):
                p = item.get("provider") or item.get("voice_provider") or item.get("engine")
                if p:
                    return str(p).lower().strip()
        p = cfg.get("voice_provider") or cfg.get("voice_engine") or cfg.get("engine")
        return str(p or "local").lower().strip()
    except Exception:
        return "local"

def _fz_nations_switch_tts_provider_if_needed(new_provider):
    try:
        new_provider = str(new_provider or "local").lower().strip()
        if new_provider in ("eleven", "11labs"):
            new_provider = "elevenlabs"
        if new_provider in ("piper", "say", "macos", "system"):
            new_provider = "local"
        old = nations_runtime.get("tts_provider_current")
        if old is None:
            nations_runtime["tts_provider_current"] = new_provider
            return
        if str(old).lower().strip() != new_provider:
            nations_runtime["tts_generation"] = int(nations_runtime.get("tts_generation") or 0) + 1
            _fz_nations_queue_clear(NATIONS_TTS_QUEUE)
            NATIONS_TTS_LAST_TEXT["text"] = ""
            NATIONS_TTS_LAST_TEXT["at"] = 0
            nations_runtime["tts_provider_current"] = new_provider
            _fz_nations_log(f"provider mudou {old} -> {new_provider}; fila TTS limpa; geração={nations_runtime['tts_generation']}", level="warn", echo=True)
    except Exception as e:
        _fz_nations_log(f"falha ao trocar provider TTS: {e}", level="warn", echo=True)

def _fz_nations_tts_generation():
    try:
        return int(nations_runtime.get("tts_generation") or 0)
    except Exception:
        return 0

def _fz_nations_log(message, level="info", echo=True):
    item = {"level": str(level or "info"), "message": str(message), "ts": time.time()}
    NATIONS_LOGS.append(item)
    del NATIONS_LOGS[:-100]
    if echo:
        print(f"[nations] {message}")
    return item


def _fz_nations_app_config_path():
    try:
        return Path(__file__).resolve().parent / "config.json"
    except Exception:
        return Path("config.json")

def _fz_nations_app_enabled_value():
    """Lê o config principal do FrameZero. Se o usuário instalou somente Clips, deve ser False."""
    try:
        p = _fz_nations_app_config_path()
        if not p.exists():
            return None
        c = json.loads(p.read_text(encoding="utf-8"))
        for k in ("nations_enabled", "nations_active"):
            if k in c:
                v = c.get(k)
                if v is False:
                    return False
                if str(v).lower() in ("0", "false", "no", "nao", "não", "off", "disabled"):
                    return False
                if v is True or str(v).lower() in ("1", "true", "yes", "sim", "on", "enabled"):
                    return True
    except Exception:
        pass
    return None

def _fz_nations_load_config():
    cfg = {}
    try:
        if NATIONS_CONFIG_PATH.exists():
            cfg = json.loads(NATIONS_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        cfg = {}
    changed = False
    if not cfg.get("device_id"):
        cfg["device_id"] = "fz-" + uuid.uuid4().hex
        changed = True
    app_enabled = _fz_nations_app_enabled_value()
    if app_enabled is False:
        cfg["enabled"] = False
        cfg["nations_enabled"] = False
        cfg["active"] = False
        changed = True
    elif "enabled" not in cfg:
        cfg["enabled"] = bool(app_enabled) if app_enabled is not None else True
        changed = True
    if not cfg.get("device_name"):
        cfg["device_name"] = _fz_nations_socket.gethostname()
        changed = True
    if not cfg.get("heartbeat_url"):
        cfg["heartbeat_url"] = "https://nations.framezeroai.com.br/api/public/device-heartbeat"
        changed = True
    if not cfg.get("remote_ws_url"):
        cfg["remote_ws_url"] = "wss://nations.framezeroai.com.br/device"
        changed = True
    if not cfg.get("bridge_secret"):
        cfg["bridge_secret"] = os.environ.get("NATIONS_BRIDGE_SECRET") or NATIONS_BRIDGE_SECRET_DEFAULT
        changed = True
    if not cfg.get("source_language"):
        cfg["source_language"] = "pt-BR"
        changed = True
    if not cfg.get("active_languages"):
        cfg["active_languages"] = ["en-US"]
        changed = True
    if not cfg.get("installed_languages"):
        cfg["installed_languages"] = list(NATIONS_ALL_LANGUAGE_CODES)
        changed = True
    if not cfg.get("voice_languages"):
        cfg["voice_languages"] = list(NATIONS_ALL_LANGUAGE_CODES)
        changed = True
    if not cfg.get("available_languages"):
        cfg["available_languages"] = list(NATIONS_ALL_LANGUAGE_CODES)
        changed = True
    if not cfg.get("mode"):
        cfg["mode"] = "single"
        changed = True
    if "delay_seconds" not in cfg:
        cfg["delay_seconds"] = 60
        changed = True
    if not cfg.get("voice_engine"):
        cfg["voice_engine"] = "piper"
        changed = True
    if not cfg.get("voice_profile"):
        cfg["voice_profile"] = "intelligent"
        changed = True
    if changed:
        _fz_nations_save_config(cfg, replace=True)
    nations_runtime["paired"] = _fz_nations_has_remote_identity(cfg) if "_fz_nations_has_remote_identity" in globals() else (bool(cfg.get("church_slug") or cfg.get("church_id")) and bool(cfg.get("user_id") or cfg.get("email") or cfg.get("user_email") or cfg.get("token") or cfg.get("pairing_token")))
    return cfg

def _fz_nations_save_config(updates, replace=False):
    if replace:
        cfg = dict(updates or {})
    else:
        cfg = _fz_nations_load_config()
        cfg.update({k: v for k, v in dict(updates or {}).items() if v is not None})
    NATIONS_DIR.mkdir(parents=True, exist_ok=True)
    NATIONS_CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    nations_runtime["paired"] = _fz_nations_has_remote_identity(cfg) if "_fz_nations_has_remote_identity" in globals() else (bool(cfg.get("church_slug") or cfg.get("church_id")) and bool(cfg.get("user_id") or cfg.get("email") or cfg.get("user_email") or cfg.get("token") or cfg.get("pairing_token")))
    return cfg


def _fz_nations_is_enabled(cfg=None):
    """Quando Nations estiver desativado, o Core não envia heartbeat, audio-ingest nem TTS remoto."""
    try:
        if str(os.environ.get("FRAMEZERO_NATIONS_DISABLED", "")).lower() in ("1", "true", "yes", "sim"):
            return False
        app_enabled = _fz_nations_app_enabled_value()
        if app_enabled is False:
            return False
        cfg = cfg or _fz_nations_load_config()
        for key in ("enabled", "nations_enabled", "active"):
            if key in cfg and cfg.get(key) is False:
                return False
            if str(cfg.get(key, "")).lower() in ("0", "false", "no", "nao", "não", "off", "disabled"):
                return False
        return bool(app_enabled is True or cfg.get("enabled") is True or cfg.get("nations_enabled") is True)
    except Exception:
        return False

def _fz_nations_has_remote_identity(cfg=None):
    """Evita HTTP 400: não chama API remota sem igreja + usuário/email/token."""
    try:
        cfg = cfg or _fz_nations_load_config()
        has_church = bool(cfg.get("church_id") or cfg.get("church_slug"))
        has_user = bool(cfg.get("user_id") or cfg.get("email") or cfg.get("user_email") or cfg.get("token") or cfg.get("pairing_token"))
        return has_church and has_user
    except Exception:
        return False

def _fz_nations_remote_allowed(cfg=None):
    """Só permite heartbeat/config/TTS remoto quando Nations está ativo, iniciado e pareado corretamente."""
    try:
        cfg = cfg or _fz_nations_load_config()
        return _fz_nations_is_enabled(cfg) and bool(nations_runtime.get("running")) and _fz_nations_has_remote_identity(cfg)
    except Exception:
        return False

def _fz_nations_cpu_percent():
    try:
        out = _fz_nations_subprocess.check_output(["ps", "-p", str(os.getpid()), "-o", "%cpu="], text=True, timeout=1).strip()
        return round(float(out or 0), 1)
    except Exception:
        return 0.0

def _fz_nations_ram_mb():
    try:
        import resource
        r = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        # macOS reports bytes, Linux often KB. Normalize roughly.
        if r > 10_000_000:
            return round(r / (1024 * 1024), 1)
        return round(r / 1024, 1)
    except Exception:
        return None

def _fz_nations_os_name():
    try:
        return platform.system() or "macOS"
    except Exception:
        return "macOS"

def _fz_nations_os_version():
    try:
        return platform.platform()
    except Exception:
        return ""

def _fz_nations_installed_tts_languages():
    """Detecta os pacotes de voz/TTS instalados localmente.
    O painel Nations lê isso para liberar os idiomas no ar.
    Suporta vozes em: nations/voices/<code>/, nations/voices/*.onnx e config.
    """
    voices = NATIONS_DIR / "voices"
    installed = []
    aliases = {
        "pt_BR": "pt-BR", "pt-br": "pt-BR", "pt_BR_faber": "pt-BR",
        "en_US": "en-US", "en-us": "en-US", "en_US-lessac": "en-US",
        "es_ES": "es-ES", "es-es": "es-ES",
        "fr_FR": "fr-FR", "fr-fr": "fr-FR",
        "de_DE": "de-DE", "de-de": "de-DE",
        "it_IT": "it-IT", "it-it": "it-IT",
    }
    def add(code):
        if not code:
            return
        s = str(code).strip()
        for k, v in aliases.items():
            if k in s:
                s = v
                break
        # remove variantes de arquivo quando possível
        if len(s) >= 5 and (s[2] in "-_"):
            s = s[:2].lower() + "-" + s[3:5].upper()
        if s and s not in installed and s != "pt-PT":
            installed.append(s)
    try:
        if voices.exists():
            for p in voices.rglob("*"):
                if p.is_dir():
                    has_model = any(x.suffix.lower() in (".onnx", ".json") for x in p.iterdir() if x.is_file())
                    if has_model:
                        add(p.name)
                elif p.suffix.lower() in (".onnx", ".json"):
                    add(p.stem)
    except Exception:
        pass
    cfg = _fz_nations_load_config()
    for key in ("tts_installed", "installed_languages", "voice_languages", "downloaded_languages"):
        extra = cfg.get(key) or []
        if isinstance(extra, str):
            extra = [extra]
        if isinstance(extra, list):
            for x in extra:
                add(x)
    return installed

def _fz_nations_public_url(cfg=None):
    cfg = cfg or _fz_nations_load_config()
    base = str(cfg.get("public_base_url") or "https://nations.framezeroai.com.br").rstrip("/")
    slug = str(cfg.get("church_slug") or "").strip("/")
    return f"{base}/live/{slug}" if slug else f"{base}/live"

def _fz_nations_status_payload():
    cfg = _fz_nations_load_config()
    cpu = _fz_nations_cpu_percent()
    ram = _fz_nations_ram_mb()
    running = bool(nations_runtime.get("running"))
    active = cfg.get("active_languages") or ["en-US"]
    if isinstance(active, str):
        active = [active]
    installed_tts = _fz_nations_installed_tts_languages()
    paired = bool(cfg.get("church_slug") or cfg.get("church_id")) and bool(cfg.get("user_id") or cfg.get("bridge_secret"))
    nations_runtime["paired"] = paired
    uptime = max(0, int(time.time() - NATIONS_STARTED_AT))
    payload = {
        "tipo": "nations_status",
        "ok": True,
        "core_online": True,
        "core_connected": True,
        "coreConnected": True,
        "core_conectado": True,
        "websocket_connected": True,
        "obs_connected": bool(globals().get("obs_conectado", False)),
        "obsConnected": bool(globals().get("obs_conectado", False)),
        "obs_conectado": bool(globals().get("obs_conectado", False)),
        "usuario_conectado": bool(cfg.get("user_id")),
        "igreja_vinculada": bool(cfg.get("church_slug") or cfg.get("church_id")),
        "nations_installed": True,
        "nations_running": running,
        "running": running,
        "status": "translating" if running else "online",
        "paired": paired,
        "version": NATIONS_VERSION,
        "nations_version": NATIONS_VERSION,
        "versao_instalada": NATIONS_VERSION,
        "device_id": cfg.get("device_id"),
        "device_name": cfg.get("device_name"),
        "church_slug": cfg.get("church_slug"),
        "church_id": cfg.get("church_id"),
        "public_url": _fz_nations_public_url(cfg),
        "languages_live": active if running else [],
        "tts_installed": installed_tts,
        "installed_languages": installed_tts,
        "voice_languages": installed_tts,
        "language_packages": [{"code": c, "installed": True, "engine": "piper"} for c in installed_tts],
        "voice_packages": [{"code": c, "installed": True, "engine": "piper"} for c in installed_tts],
        "available_languages": NATIONS_LANGUAGE_CATALOG,
        "language_catalog": NATIONS_LANGUAGE_CATALOG,
        "all_language_codes": list(NATIONS_ALL_LANGUAGE_CODES),
        "available_languages": NATIONS_LANGUAGE_CATALOG,
        "language_catalog": NATIONS_LANGUAGE_CATALOG,
        "all_language_codes": list(NATIONS_ALL_LANGUAGE_CODES),
        "logs": list(NATIONS_LOGS[-20:]),
        "transcription_ingest": {
            "ok": bool(nations_runtime.get("last_ingest_ok")),
            "last_at": nations_runtime.get("last_ingest_at"),
            "last_status": nations_runtime.get("last_ingest_status"),
            "last_error": nations_runtime.get("last_ingest_error", ""),
        },
        "audio_ingest": {
            "ok": bool(nations_runtime.get("last_audio_ingest_ok")),
            "last_at": nations_runtime.get("last_audio_ingest_at"),
            "last_lang": nations_runtime.get("last_audio_ingest_lang"),
            "last_type": nations_runtime.get("last_audio_ingest_type"),
            "last_error": nations_runtime.get("last_audio_ingest_error", ""),
            "chunks_sent": int(nations_runtime.get("audio_chunks_sent") or 0),
        },
        "dispositivo": {
            "device_id": cfg.get("device_id"),
            "device_name": cfg.get("device_name"),
            "name": cfg.get("device_name"),
            "os": _fz_nations_os_name(),
            "os_version": _fz_nations_os_version(),
            "core_version": NATIONS_VERSION,
            "nations_version": NATIONS_VERSION,
            "status": "online",
            "ultima_conexao": int(time.time()),
        },
        "estatisticas": {
            "cpu": cpu,
            "ram": ram,
            "ram_mb": ram,
            "gpu": "Apple Silicon/Metal" if _fz_nations_os_name() == "Darwin" else "",
            "ouvintes": int(nations_runtime.get("listeners") or 0),
            "listeners": int(nations_runtime.get("listeners") or 0),
            "uptime_seconds": uptime,
            "tempo_online": uptime,
            "processed_lines": int(nations_runtime.get("processed_lines") or 0),
            "generated_audio_blocks": int(nations_runtime.get("generated_audio_blocks") or 0),
        },
        "traducao": {
            "source_language": cfg.get("source_language") or "pt-BR",
            "mode": cfg.get("mode") or "single",
            "active_languages": active,
            "languages": active,
            "delay_seconds": int(cfg.get("delay_seconds") or 60),
            "running": running,
        },
        "translation": {
            "languages": active if running else [],
            "source_language": cfg.get("source_language") or "pt-BR",
        },
        "voz": {
            "engine": cfg.get("voice_engine") or "piper",
            "profile": cfg.get("voice_profile") or "intelligent",
            "elevenlabs_connected": bool(cfg.get("elevenlabs_api_key")),
            "voice": cfg.get("voice") or "default",
            "gender": cfg.get("voice_gender") or "auto",
            "voice_id": cfg.get("voice_id") or cfg.get("voice") or "default",
            "status": "ready",
            "installed_languages": installed_tts,
        },
    }
    return payload

async def _fz_nations_ws_send(ws, payload):
    try:
        await ws.send(json.dumps(payload, ensure_ascii=False))
    except Exception:
        pass

def _fz_nations_flatten_request(req):
    data = {}
    if isinstance(req, dict):
        data.update(req)
        for key in ("payload", "data", "config", "body"):
            if isinstance(req.get(key), dict):
                data.update(req.get(key))
    return data

async def _fz_nations_handle_ws(ws, req):
    if not isinstance(req, dict):
        return False
    acao = str(req.get("tipo") or req.get("acao") or req.get("action") or "").strip()
    if not acao.startswith("nations"):
        return False
    data = _fz_nations_flatten_request(req)
    if not _fz_nations_is_enabled() and acao not in ("nations_status", "nations:status"):
        await _fz_nations_ws_send(ws, {"tipo":"nations_disabled", "ok": False, "enabled": False})
        return True
    if acao in ("nations_status", "nations:status"):
        await _fz_nations_ws_send(ws, _fz_nations_status_payload())
        return True
    if acao in ("nations_pair", "nations:pair", "nations_pair_device"):
        aliases = {
            "userId": "user_id", "churchId": "church_id", "churchSlug": "church_slug",
            "deviceToken": "token", "pairingToken": "pairing_token", "pairing_token": "pairing_token",
            "remoteWsUrl": "remote_ws_url", "publicBaseUrl": "public_base_url",
        }
        for src, dst in aliases.items():
            if src in data and dst not in data:
                data[dst] = data[src]
        updates = {}
        for k in ("user_id", "email", "user_email", "church_id", "church_slug", "token", "pairing_token", "remote_ws_url", "public_base_url", "heartbeat_url", "bridge_secret"):
            if data.get(k) not in (None, ""):
                updates[k] = data.get(k)
        cfg = _fz_nations_save_config(updates)
        _fz_nations_log(f"pareado via painel • igreja={cfg.get('church_slug') or cfg.get('church_id')}")
        await _fz_nations_ws_send(ws, {**_fz_nations_status_payload(), "tipo": "nations_pair_ok", "ok": True})
        return True
    if acao in ("nations_config", "nations:config"):
        updates = {}
        aliases = {"sourceLanguage":"source_language", "activeLanguages":"active_languages", "voiceEngine":"voice_engine", "voiceProfile":"voice_profile", "delay":"delay_seconds", "voiceGender":"voice_gender", "voiceId":"voice_id"}
        for src, dst in aliases.items():
            if src in data:
                data[dst] = data[src]
        for k in ("source_language", "active_languages", "mode", "delay_seconds", "voice_engine", "voice_profile", "elevenlabs_api_key", "elevenlabs_enabled", "voice_gender", "voice_id"):
            if k in data:
                updates[k] = data.get(k)
        _fz_nations_save_config(updates)
        _fz_nations_log("configuração atualizada pelo painel")
        await _fz_nations_ws_send(ws, {**_fz_nations_status_payload(), "tipo":"nations_config_ok", "ok": True})
        return True
    if acao in ("nations_start", "nations:start"):
        cfg = _fz_nations_load_config()
        if not cfg.get("active_languages"):
            _fz_nations_save_config({"active_languages": ["en-US"]})
        nations_runtime["running"] = True
        nations_runtime["last_started_at"] = time.time()
        globals()["NATIONS_AUDIO_BUFFER"] = np.zeros((0,), dtype=np.float32)
        _fz_nations_log("start recebido pelo painel")
        _fz_nations_log("tradução iniciada para " + ",".join(_fz_nations_load_config().get("active_languages") or ["en-US"]))
        await _fz_nations_ws_send(ws, {**_fz_nations_status_payload(), "tipo":"nations_start_ok", "ok": True})
        return True
    if acao in ("nations_stop", "nations:stop"):
        nations_runtime["running"] = False
        _fz_nations_log("stop recebido pelo painel")
        await _fz_nations_ws_send(ws, {**_fz_nations_status_payload(), "tipo":"nations_stop_ok", "ok": True})
        return True
    if acao in ("nations_test_voice", "nations:test_voice"):
        _fz_nations_log("teste de voz recebido")
        await _fz_nations_ws_send(ws, {**_fz_nations_status_payload(), "tipo":"nations_test_voice_ok", "ok": True, "message":"Piper pronto para teste."})
        return True
    await _fz_nations_ws_send(ws, {"tipo":"nations_unknown", "ok": False, "acao": acao})
    return True


def _fz_nations_public_api_headers():
    cfg = _fz_nations_load_config()
    secret = cfg.get("bridge_secret") or os.environ.get("NATIONS_BRIDGE_SECRET") or NATIONS_BRIDGE_SECRET_DEFAULT
    return {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "x-bridge-secret": str(secret or ""),
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36 FrameZeroCore/0.1.50",
    }

def _fz_nations_post_transcription_ingest(texto, lang=None, reference=None, verse_text=None, clear_verse=False):
    """Envia legenda/versículo para o site público (/live/:slug) via transcription-ingest."""
    try:
        cfg = _fz_nations_load_config()
        if not _fz_nations_is_enabled(cfg):
            return False
        slug = cfg.get("church_slug") or cfg.get("slug")
        if not slug:
            _fz_nations_log("transcription-ingest aguardando church_slug", level="warn", echo=False)
            return False
        url = cfg.get("transcription_ingest_url") or "https://nations.framezeroai.com.br/api/public/transcription-ingest"
        body = {"church_slug": slug, "church_id": cfg.get("church_id"), "user_id": cfg.get("user_id"), "device_id": cfg.get("device_id"), "lang": _fz_nations_norm_lang(lang or "pt-BR")}
        if clear_verse:
            body["clear_verse"] = True
        elif reference or verse_text:
            body["reference"] = reference or ""
            body["verse_text"] = verse_text or ""
        else:
            body["text"] = str(texto or "")
        raw = json.dumps(body, ensure_ascii=False).encode("utf-8")
        req = _fz_nations_urlrequest.Request(url, data=raw, headers=_fz_nations_public_api_headers(), method="POST")
        with _fz_nations_urlrequest.urlopen(req, timeout=5) as resp:
            txt = resp.read(300).decode("utf-8", "ignore")
            nations_runtime["last_ingest_at"] = time.time()
            nations_runtime["last_ingest_ok"] = True
            nations_runtime["last_ingest_status"] = int(getattr(resp, "status", 200))
            return True
    except _fz_nations_urlerror.HTTPError as e:
        try:
            txt = e.read(300).decode("utf-8", "ignore")
        except Exception:
            txt = str(e)
        nations_runtime["last_ingest_ok"] = False
        nations_runtime["last_ingest_error"] = txt
        _fz_nations_log(f"transcription-ingest HTTP {getattr(e,'code','?')}: {txt[:140]}", level="warn")
        return False
    except Exception as e:
        nations_runtime["last_ingest_ok"] = False
        nations_runtime["last_ingest_error"] = str(e)
        _fz_nations_log(f"transcription-ingest pendente: {e}", level="warn", echo=False)
        return False

def _fz_nations_async_transcription_ingest(texto, lang=None):
    try:
        threading.Thread(target=_fz_nations_post_transcription_ingest, args=(texto, lang), daemon=True).start()
    except Exception:
        pass

def _fz_nations_norm_lang(code):
    c = str(code or '').strip()
    low = c.lower().replace('_','-')
    mapping = {
        'en':'en-US','en-us':'en-US','english':'en-US',
        'pt':'pt-BR','pt-br':'pt-BR','ptbr':'pt-BR',
        'es':'es-ES','es-es':'es-ES',
        'fr':'fr-FR','fr-fr':'fr-FR',
        'de':'de-DE','it':'it-IT','nl':'nl-NL','pl':'pl-PL','ru':'ru-RU','uk':'uk-UA',
        'ar':'ar-SA','zh':'zh-CN','hi':'hi-IN','ja':'ja-JP','ko':'ko-KR','id':'id-ID','vi':'vi-VN','tl':'tl-PH','sw':'sw-KE',
    }
    return mapping.get(low, c or 'en-US')

def _fz_nations_active_langs_norm():
    cfg = _fz_nations_load_config()
    active = cfg.get('active_languages') or ['en-US']
    if isinstance(active, str):
        active = [active]
    return [_fz_nations_norm_lang(x) for x in active if x]

def _fz_nations_queue_tts_for_active_languages(texto):
    try:
        if not _fz_nations_is_enabled():
            return
        if not nations_runtime.get('running'):
            return
        texto = str(texto or '').strip()
        if not texto:
            return
        now = time.time()
        if texto == NATIONS_TTS_LAST_TEXT.get('text') and now - float(NATIONS_TTS_LAST_TEXT.get('at') or 0) < 4:
            return
        NATIONS_TTS_LAST_TEXT['text'] = texto
        NATIONS_TTS_LAST_TEXT['at'] = now
        source = _fz_nations_norm_lang(_fz_nations_load_config().get('source_language') or 'pt-BR')
        for lang in _fz_nations_active_langs_norm():
            lang = _fz_nations_norm_lang(lang)
            if lang == source:
                continue
            try:
                NATIONS_TTS_QUEUE.put_nowait({'text': texto, 'source_text': texto, 'lang': lang, 'ts': now, 'provider_generation': _fz_nations_tts_generation()})
                nations_runtime['tts_jobs_queued'] = int(nations_runtime.get('tts_jobs_queued') or 0) + 1
            except Exception:
                try:
                    NATIONS_TTS_QUEUE.get_nowait()
                    NATIONS_TTS_QUEUE.put_nowait({'text': texto, 'source_text': texto, 'lang': lang, 'ts': now, 'provider_generation': _fz_nations_tts_generation()})
                except Exception:
                    pass
    except Exception as e:
        _fz_nations_log(f'tts queue erro: {e}', level='warn', echo=True)

def _fz_nations_on_payload(payload):
    try:
        if not _fz_nations_is_enabled():
            return
        if not isinstance(payload, dict):
            return
        if payload.get("tipo") != "linha":
            return
        texto = str(payload.get("texto") or "").strip()
        if not texto:
            return
        nations_runtime["processed_lines"] = int(nations_runtime.get("processed_lines") or 0) + 1
        nations_runtime["last_text"] = texto
        nations_runtime["last_text_at"] = time.time()
        try:
            NATIONS_QUEUE.put_nowait({"texto": texto, "timestamp": payload.get("timestamp"), "ts": time.time()})
        except Exception:
            pass
        if _fz_nations_is_enabled() and nations_runtime.get("running"):
            _fz_nations_log("transcrição recebida: " + texto[:110])
            _fz_nations_async_transcription_ingest(texto, "pt-BR")
            _fz_nations_queue_tts_for_active_languages(texto)
            nations_runtime["generated_audio_blocks"] = int(nations_runtime.get("generated_audio_blocks") or 0) + 1
        else:
            # Mostra só uma vez a cada poucas linhas para não poluir.
            if int(nations_runtime.get("processed_lines") or 0) % 5 == 1:
                _fz_nations_log("transcrição detectada, aguardando iniciar Nations", echo=False)
    except Exception as e:
        print(f"[nations] falha ao receber transcrição: {e}")

def nations_ingest_line(payload):
    _fz_nations_on_payload(payload)



def _fz_nations_audio_mime():
    return "audio/mpeg"

def _fz_nations_ffmpeg_path():
    """Localiza ffmpeg em PATH e locais comuns do macOS."""
    try:
        candidates = [
            shutil.which("ffmpeg"),
            "/opt/homebrew/bin/ffmpeg",
            "/usr/local/bin/ffmpeg",
            "/Applications/ffmpeg",
        ]
        for c in candidates:
            if c and Path(c).exists():
                return str(c)
    except Exception:
        pass
    return None

def _fz_nations_encode_mp3_from_float(audio, sample_rate=16000):
    """Codifica float32 mono em MP3 usando ffmpeg via stdin.
    v42: sem arquivos temporários, logs melhores e bitrate menor para Realtime.
    """
    try:
        ffmpeg = _fz_nations_ffmpeg_path()
        if not ffmpeg:
            # log com echo limitado para o operador saber por que não sai áudio
            now = time.time()
            if now - float(nations_runtime.get("last_ffmpeg_warn_at") or 0) > 20:
                nations_runtime["last_ffmpeg_warn_at"] = now
                _fz_nations_log("ffmpeg não encontrado; instale ffmpeg para enviar áudio ao /live", level="warn", echo=True)
            return None
        audio = np.asarray(audio, dtype=np.float32).reshape(-1)
        if len(audio) == 0:
            return None
        # remove DC, normaliza levemente e evita clip
        audio = audio - float(np.mean(audio))
        peak = float(np.max(np.abs(audio)) + 1e-9)
        if peak > 0:
            audio = audio / max(1.0, peak / 0.92)
        audio = np.clip(audio, -1.0, 1.0)
        pcm = (audio * 32767.0).astype('<i2').tobytes()
        cmd = [
            ffmpeg, '-hide_banner', '-loglevel', 'error', '-y',
            '-f', 's16le', '-ar', str(int(sample_rate)), '-ac', '1',
            '-i', 'pipe:0',
            '-ac', '1', '-ar', '24000',
            '-codec:a', 'libmp3lame', '-b:a', '48k',
            '-f', 'mp3', 'pipe:1'
        ]
        p = subprocess.run(cmd, input=pcm, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
        if p.returncode != 0:
            err = (p.stderr or b'').decode('utf-8','ignore')[:180]
            now = time.time()
            if now - float(nations_runtime.get("last_ffmpeg_error_at") or 0) > 10:
                nations_runtime["last_ffmpeg_error_at"] = now
                _fz_nations_log(f"ffmpeg falhou ao gerar MP3: {err}", level="warn", echo=True)
            return None
        data = p.stdout or b''
        if len(data) < 200:
            return None
        return data
    except Exception as e:
        now = time.time()
        if now - float(nations_runtime.get("last_mp3_error_at") or 0) > 10:
            nations_runtime["last_mp3_error_at"] = now
            _fz_nations_log(f"falha ao codificar MP3: {e}", level="warn", echo=True)
        return None

def _fz_nations_post_audio_ingest(audio_bytes, lang="pt-BR", audio_type="original", mime="audio/mpeg", text=None, source_text=None, final=False):
    try:
        cfg = _fz_nations_load_config()
        if not _fz_nations_is_enabled(cfg):
            return False
        slug = cfg.get("church_slug") or cfg.get("slug")
        if not slug:
            now = time.time()
            if now - float(nations_runtime.get("last_audio_no_slug_at") or 0) > 12:
                nations_runtime["last_audio_no_slug_at"] = now
                _fz_nations_log("audio-ingest aguardando pareamento/igreja para enviar áudio", level="warn", echo=True)
            return False
        if not audio_bytes:
            return False
        if len(audio_bytes) > 175000:
            _fz_nations_log(f"audio-ingest pulado: chunk grande demais ({len(audio_bytes)} bytes)", level="warn", echo=True)
            return False
        url = cfg.get("audio_ingest_url") or "https://nations.framezeroai.com.br/api/public/audio-ingest"
        NATIONS_AUDIO_SEQ[audio_type] = int(NATIONS_AUDIO_SEQ.get(audio_type, 0)) + 1
        seq = NATIONS_AUDIO_SEQ[audio_type]
        body = {
            "church_slug": slug,
            "church_id": cfg.get("church_id"),
            "user_id": cfg.get("user_id"),
            "device_id": cfg.get("device_id"),
            "lang": lang,
            "type": audio_type,
            "sequence": seq,
            "timestamp_ms": int(time.time()*1000),
            "mime": mime,
            "audio": base64.b64encode(audio_bytes).decode('ascii'),
        }
        if text is not None:
            body["text"] = str(text)
        if source_text is not None:
            body["source_text"] = str(source_text)
        if final:
            body["final"] = True
        raw = json.dumps(body, ensure_ascii=False).encode('utf-8')
        headers = _fz_nations_public_api_headers()
        headers["Content-Type"] = "application/json"
        headers["Accept"] = "application/json"
        headers["User-Agent"] = headers.get("User-Agent") or "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
        req = _fz_nations_urlrequest.Request(url, data=raw, headers=headers, method="POST")
        with _fz_nations_urlrequest.urlopen(req, timeout=8) as resp:
            resp.read(400)
        nations_runtime["last_audio_ingest_ok"] = True
        nations_runtime["last_audio_ingest_at"] = time.time()
        nations_runtime["last_audio_ingest_lang"] = lang
        nations_runtime["last_audio_ingest_type"] = audio_type
        nations_runtime["last_audio_ingest_error"] = ""
        nations_runtime["audio_chunks_sent"] = int(nations_runtime.get("audio_chunks_sent") or 0) + 1
        last = int(NATIONS_AUDIO_LAST_LOG.get(audio_type, 0))
        if seq == 1 or seq - last >= 5:
            NATIONS_AUDIO_LAST_LOG[audio_type] = seq
            _fz_nations_log(f"audio-ingest OK • {audio_type} • {lang} • chunk {seq} • {len(audio_bytes)} bytes", level="info", echo=True)
        return True
    except _fz_nations_urlerror.HTTPError as e:
        try: txt = e.read(1024 * 1024).decode('utf-8','ignore')
        except Exception: txt = str(e)
        nations_runtime["last_audio_ingest_ok"] = False
        nations_runtime["last_audio_ingest_error"] = txt
        now = time.time()
        if now - float(nations_runtime.get("last_audio_http_log_at") or 0) > 8:
            nations_runtime["last_audio_http_log_at"] = now
            _fz_nations_log(f"audio-ingest HTTP {getattr(e,'code','?')}: {txt[:220]}", level="warn", echo=True)
        return False
    except Exception as e:
        nations_runtime["last_audio_ingest_ok"] = False
        nations_runtime["last_audio_ingest_error"] = str(e)
        now = time.time()
        if now - float(nations_runtime.get("last_audio_error_log_at") or 0) > 8:
            nations_runtime["last_audio_error_log_at"] = now
            _fz_nations_log(f"audio-ingest pendente: {e}", level="warn", echo=True)
        return False

def _fz_nations_audio_worker():
    if not _fz_nations_is_enabled():
        _fz_nations_log("audio worker parado: Nations desativado", echo=True)
        return
    _fz_nations_log("audio worker v42 iniciado", echo=True)
    while True:
        try:
            item = NATIONS_AUDIO_QUEUE.get(timeout=1.0)
        except Exception:
            continue
        try:
            audio = item.get("audio")
            sr = int(item.get("sample_rate") or 16000)
            lang = item.get("lang") or "pt-BR"
            typ = item.get("type") or "original"
            mp3 = _fz_nations_encode_mp3_from_float(audio, sr)
            if mp3:
                _fz_nations_post_audio_ingest(mp3, lang=lang, audio_type=typ, mime="audio/mpeg")
        except Exception as e:
            _fz_nations_log(f"audio worker erro: {e}", level="warn", echo=True)

def _fz_nations_audio_hook(indata, sample_rate=16000):
    """Recebe áudio capturado (BlackHole/plugin) e cria chunks MP3 originais.
    v42: logs explícitos, chunks menores e detecção de silêncio.
    """
    global NATIONS_AUDIO_BUFFER
    try:
        if not nations_runtime.get("running"):
            return
        cfg = _fz_nations_load_config()
        source_lang = cfg.get("source_language") or "pt-BR"
        arr = np.asarray(indata, dtype=np.float32)
        if arr.ndim == 2:
            arr = arr.mean(axis=1)
        arr = arr.reshape(-1)
        if len(arr) == 0:
            return
        # descarta silêncio absoluto para não congestionar Realtime
        rms = float(np.sqrt(np.mean(arr * arr)) + 1e-9)
        nations_runtime["last_audio_rms"] = rms
        now = time.time()
        if now - float(nations_runtime.get("last_audio_capture_log_at") or 0) > 8:
            nations_runtime["last_audio_capture_log_at"] = now
            _fz_nations_log(f"audio original capturado • rms={rms:.4f} • fila={NATIONS_AUDIO_QUEUE.qsize()}", echo=True)
        if rms < 0.0008:
            return
        NATIONS_AUDIO_BUFFER = np.concatenate([NATIONS_AUDIO_BUFFER, arr])
        # 1 segundo de áudio por chunk reduz latência e tamanho
        target_len = max(8000, int(float(sample_rate) * 1.0))
        while len(NATIONS_AUDIO_BUFFER) >= target_len:
            chunk = NATIONS_AUDIO_BUFFER[:target_len]
            NATIONS_AUDIO_BUFFER = NATIONS_AUDIO_BUFFER[target_len:]
            try:
                NATIONS_AUDIO_QUEUE.put_nowait({
                    "audio": chunk.copy(),
                    "sample_rate": int(sample_rate),
                    "lang": source_lang,
                    "type": "original"
                })
                nations_runtime["audio_chunks_queued"] = int(nations_runtime.get("audio_chunks_queued") or 0) + 1
            except Exception:
                # se fila lotar, joga fora o mais antigo para manter tempo real
                try:
                    NATIONS_AUDIO_QUEUE.get_nowait()
                    NATIONS_AUDIO_QUEUE.put_nowait({"audio": chunk.copy(), "sample_rate": int(sample_rate), "lang": source_lang, "type": "original"})
                except Exception:
                    pass
    except Exception as e:
        now = time.time()
        if now - float(nations_runtime.get("last_audio_hook_error_at") or 0) > 8:
            nations_runtime["last_audio_hook_error_at"] = now
            _fz_nations_log(f"audio hook erro: {e}", level="warn", echo=True)



def _fz_nations_canonical_lang(code):
    return _fz_nations_norm_lang(code)

def _fz_nations_public_api_headers_json():
    headers = _fz_nations_public_api_headers()
    headers["Content-Type"] = "application/json"
    headers["Accept"] = "application/json"
    headers["User-Agent"] = headers.get("User-Agent") or "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36 FrameZeroCore/0.1.50"
    return headers

def _fz_nations_translate_via_gateway(texto, target_lang, source_lang="pt-BR"):
    """v48: toda tradução do Nations passa pelo endpoint do painel.
    Nunca usa generativelanguage.googleapis.com diretamente para TTS.
    Retorna string traduzida ou vazio para bloquear TTS.
    """
    texto = str(texto or "").strip()
    target_lang = _fz_nations_norm_lang(target_lang)
    source_lang = _fz_nations_norm_lang(source_lang or "pt-BR")
    if not texto:
        return ""
    if target_lang == source_lang:
        return texto
    cache_key = f"{source_lang}>{target_lang}:{texto[:500]}"
    cache = globals().setdefault("NATIONS_TRANSLATION_CACHE", {})
    hit = cache.get(cache_key)
    if hit:
        return hit
    cfg = _fz_nations_load_config()
    url = cfg.get("translate_url") or "https://nations.framezeroai.com.br/api/public/translate"
    model = cfg.get("translation_model") or "google/gemini-2.5-flash"
    body = {"text": texto, "from": source_lang, "to": target_lang, "model": model}
    raw = json.dumps(body, ensure_ascii=False).encode("utf-8")
    headers = _fz_nations_public_api_headers_json()
    delays = [0.5, 1.0, 2.0, 0.0]
    for attempt in range(4):
        try:
            req = _fz_nations_urlrequest.Request(url, data=raw, headers=headers, method="POST")
            with _fz_nations_urlrequest.urlopen(req, timeout=30) as resp:
                txt = resp.read(4000).decode("utf-8", "ignore")
            try:
                data = json.loads(txt)
            except Exception:
                _fz_nations_log(f"tradução gateway resposta inválida para {target_lang}: {txt[:160]}", level="warn", echo=True)
                return ""
            translated = str(data.get("text") or data.get("translated") or data.get("translation") or "").strip()
            if not translated:
                _fz_nations_log(f"tradução vazia para {target_lang}; TTS bloqueado", level="warn", echo=True)
                return ""
            # Bloqueia o caso mais perigoso: usar a própria frase em outro idioma.
            if target_lang != source_lang and translated.strip().lower() == texto.strip().lower():
                _fz_nations_log(f"tradução inválida para {target_lang}; TTS bloqueado para evitar português com voz estrangeira", level="warn", echo=True)
                return ""
            cache[cache_key] = translated
            if len(cache) > 500:
                for k in list(cache.keys())[:100]:
                    cache.pop(k, None)
            _fz_nations_log(f"texto traduzido {target_lang}: {translated[:120]}", level="info", echo=True)
            return translated
        except _fz_nations_urlerror.HTTPError as e:
            try:
                detail = e.read(700).decode("utf-8", "ignore")
            except Exception:
                detail = str(e)
            if e.code in (429, 500, 502, 503, 504) and attempt < 3:
                _fz_nations_log(f"tradução gateway {e.code} para {target_lang}; retry {attempt+1}/3", level="warn", echo=True)
                time.sleep(delays[attempt])
                continue
            _fz_nations_log(f"tradução gateway falhou para {target_lang}: HTTP {e.code} {detail[:180]}", level="warn", echo=True)
            return ""
        except Exception as e:
            if attempt < 3:
                _fz_nations_log(f"tradução gateway pendente para {target_lang}: {e}; retry {attempt+1}/3", level="warn", echo=False)
                time.sleep(delays[attempt])
                continue
            _fz_nations_log(f"tradução gateway indisponível para {target_lang}: {e}", level="warn", echo=True)
            return ""
    return ""

def _fz_nations_apply_heartbeat_config(txt):
    if not _fz_nations_remote_allowed():
        return False
    """v50: aplica config curta tts_config_json do heartbeat.
    Corrige v49: o heartbeat era lido com resp.read(500), truncando o JSON
    no meio de tts_config_json. Agora o Core lê o response completo.
    """
    try:
        raw = str(txt or "").strip()
        if not raw or not raw.startswith("{"):
            return False
        try:
            data = json.loads(raw)
        except Exception as e:
            _fz_nations_log(f"heartbeat JSON inválido; ignorando config TTS: {e}; preview={raw[:220]}", level="warn", echo=True)
            return False
        if not isinstance(data, dict):
            return False

        updates = {}
        for key in ("active_languages", "installed_languages", "published_languages"):
            val = data.get(key)
            if isinstance(val, list):
                updates[key] = [_fz_nations_norm_lang(x) for x in val if x]

        # Novo formato server-side: string JSON pequena e atômica.
        tts = None
        tts_raw = data.get("tts_config_json")
        if isinstance(tts_raw, str) and tts_raw.strip():
            try:
                tts = json.loads(tts_raw)
                _fz_nations_log("config TTS tts_config_json recebida via heartbeat", level="info", echo=False)
            except Exception as e:
                _fz_nations_log(f"tts_config_json inválido; ignorando TTS: {e}; preview={tts_raw[:220]}", level="warn", echo=True)
                tts = None
        elif isinstance(data.get("tts_config_json"), dict):
            tts = data.get("tts_config_json")

        # Compatibilidade com formato antigo, mas só se vier como dict real.
        if tts is None:
            legacy = data.get("tts") or data.get("tts_config") or data.get("voices")
            if isinstance(legacy, dict):
                tts = legacy

        if isinstance(tts, dict):
            # Normaliza formato curto:
            # {provider, voice_id, voice_model/model, api_key, params, voices:{en-US: voice_id}}
            normalized = dict(tts)
            voices = normalized.get("voices")
            provider = normalized.get("provider") or normalized.get("voice_provider") or normalized.get("engine")
            api_key = normalized.get("api_key") or normalized.get("elevenlabs_api_key") or normalized.get("xi_api_key")
            model = normalized.get("voice_model") or normalized.get("model") or normalized.get("model_id")
            params = normalized.get("params") if isinstance(normalized.get("params"), dict) else {}
            if isinstance(voices, dict):
                per_lang = {}
                for k, vid in voices.items():
                    lang = _fz_nations_norm_lang(k)
                    if not vid:
                        continue
                    prov_norm = str(provider or "elevenlabs").lower().strip()
                    item = {
                        "provider": prov_norm,
                        "voice_provider": prov_norm,
                        "enabled": True,
                    }
                    if prov_norm in ("elevenlabs", "eleven", "11labs"):
                        item.update({
                            "api_key": api_key,
                            "elevenlabs_api_key": api_key,
                            "voice_id": vid,
                            "model": model or "eleven_multilingual_v2",
                            "model_id": model or "eleven_multilingual_v2",
                        })
                    else:
                        # v51: se o painel trocar para local/Piper, nunca reaproveitar voice_id do ElevenLabs.
                        item.update({
                            "engine": "local",
                            "voice_id": "",
                            "api_key": "",
                            "elevenlabs_api_key": "",
                            "model": "local",
                            "model_id": "local",
                        })
                    if isinstance(params, dict):
                        item.update(params)
                    # também aceita params por idioma, se vier
                    lang_params = normalized.get(lang)
                    if isinstance(lang_params, dict):
                        item.update(lang_params)
                    per_lang[lang] = item
                if per_lang:
                    updates["tts"] = per_lang
                    updates["tts_config"] = per_lang
                    # fallback global
                    prov_norm_global = str(provider or "").lower().strip()
                    if provider: updates["voice_provider"] = provider
                    if prov_norm_global in ("elevenlabs", "eleven", "11labs"):
                        if api_key: updates["elevenlabs_api_key"] = api_key
                        if model: updates["elevenlabs_model"] = model
                        voice_id = per_lang.get("en-US", {}).get("voice_id") or normalized.get("voice_id")
                        if voice_id: updates["voice_id"] = voice_id
                    elif prov_norm_global:
                        # v51: local/Piper selecionado: limpar voice_id e não deixar ElevenLabs vazar.
                        updates["voice_id"] = ""
                        updates["elevenlabs_model"] = "local"
            else:
                updates["tts"] = normalized
                updates["tts_config"] = normalized
                prov_norm_global = str(provider or "").lower().strip()
                if provider: updates["voice_provider"] = provider
                if prov_norm_global in ("elevenlabs", "eleven", "11labs") or (not prov_norm_global and api_key and normalized.get("voice_id")):
                    if api_key: updates["elevenlabs_api_key"] = api_key
                    if model: updates["elevenlabs_model"] = model
                    if normalized.get("voice_id"): updates["voice_id"] = normalized.get("voice_id")
                elif prov_norm_global:
                    updates["voice_id"] = ""
                    updates["elevenlabs_model"] = "local"

        if updates:
            # v52: se o provider mudar, limpe a fila e invalide jobs antigos antes de salvar/usar.
            if isinstance(tts, dict):
                prov_candidate = tts.get("provider") or tts.get("voice_provider") or tts.get("engine")
                if prov_candidate:
                    _fz_nations_switch_tts_provider_if_needed(prov_candidate)
            _fz_nations_save_config(updates)
            if isinstance(tts, dict):
                prov = tts.get("provider") or tts.get("voice_provider") or tts.get("engine") or "tts"
                
                voices_map = tts.get("voices") if isinstance(tts.get("voices"), dict) else {}
                if str(prov).lower().strip() in ("local", "piper", "say", "macos", "system"):
                    vid = "local"
                else:
                    vid = tts.get("voice_id") or voices_map.get("en-US") or voices_map.get("en") or ""
                _fz_nations_log(f"config TTS atualizada via heartbeat • provider={prov} • voice={str(vid)[:10]}", level="info", echo=True)
            return True
    except Exception as e:
        _fz_nations_log(f"falha ao aplicar config TTS do heartbeat: {e}", level="warn", echo=True)
    return False

def _fz_nations_tts_config_for_lang(lang):
    cfg = _fz_nations_load_config()
    lang = _fz_nations_norm_lang(lang)
    tts = cfg.get("tts") or cfg.get("tts_config") or {}
    if isinstance(tts, dict):
        item = tts.get(lang) or tts.get(lang.lower()) or tts.get(lang.split("-")[0]) or {}
        if isinstance(item, dict):
            return item
    return {}


def _fz_nations_effective_tts_provider(lang="en-US"):
    """v53: lê o provider no momento exato de cada job.
    Isso impede que um worker/engine antigo de ElevenLabs continue sendo usado
    depois que o painel muda para Local/Piper.
    """
    try:
        cfg = _fz_nations_load_config()
        tc = _fz_nations_tts_config_for_lang(lang)
        provider = (
            nations_runtime.get("tts_provider_current")
            or tc.get("provider")
            or tc.get("voice_provider")
            or tc.get("engine")
            or cfg.get("voice_provider")
            or cfg.get("voice_engine")
            or "local"
        )
        p = str(provider or "local").lower().strip()
        if p in ("eleven", "11labs"):
            return "elevenlabs"
        if p in ("piper", "say", "macos", "system"):
            return "local"
        if p not in ("elevenlabs", "local"):
            has_eleven = bool((tc.get("api_key") or tc.get("elevenlabs_api_key") or cfg.get("elevenlabs_api_key"))
                              and (tc.get("voice_id") or cfg.get("voice_id")))
            return "elevenlabs" if has_eleven else "local"
        return p
    except Exception:
        return "local"

def _fz_nations_elevenlabs_tts_mp3(texto, lang="en-US"):
    """v48: ElevenLabs real quando provider/voice/api_key vierem do painel."""
    try:
        cfg = _fz_nations_load_config()
        tc = _fz_nations_tts_config_for_lang(lang)
        provider = _fz_nations_effective_tts_provider(lang)
        # v53: provider local/Piper/say é decisão explícita do painel e deve impedir ElevenLabs,
        # mesmo se api_key/voice_id antigos ainda existirem no config ou em jobs antigos.
        if provider in ("local", "piper", "say", "macos", "system"):
            _fz_nations_log(f"[tts] provider=local/piper • idioma={lang}", level="info", echo=True)
            return None
        api_key = str(tc.get("api_key") or tc.get("elevenlabs_api_key") or cfg.get("elevenlabs_api_key") or cfg.get("xi_api_key") or "").strip()
        voice_id = str(tc.get("voice_id") or cfg.get("voice_id") or "").strip()
        if provider not in ("elevenlabs", "eleven", "11labs") and not (api_key and voice_id):
            return None
        if not api_key or not voice_id:
            _fz_nations_log("ElevenLabs configurado sem api_key/voice_id; TTS bloqueado", level="warn", echo=True)
            return None
        model = str(tc.get("model") or tc.get("model_id") or cfg.get("elevenlabs_model") or "eleven_multilingual_v2")
        payload = {
            "text": str(texto or "").strip(),
            "model_id": model,
            "voice_settings": {
                "stability": float(tc.get("stability", cfg.get("stability", 0.45)) or 0.45),
                "similarity_boost": float(tc.get("similarity", tc.get("similarity_boost", cfg.get("similarity_boost", 0.8))) or 0.8),
                "style": float(tc.get("style", cfg.get("style", 0.0)) or 0.0),
                "use_speaker_boost": bool(tc.get("speaker_boost", tc.get("use_speaker_boost", True))),
            }
        }
        speed = tc.get("speed", cfg.get("speed"))
        if speed is not None:
            try: payload["voice_settings"]["speed"] = float(speed)
            except Exception: pass
        url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}/stream?output_format=mp3_44100_64"
        headers = {"xi-api-key": api_key, "Content-Type":"application/json", "Accept":"audio/mpeg", "User-Agent":"FrameZeroNations/0.1.52"}
        _fz_nations_log(f"[tts] provider=elevenlabs • idioma={lang} • voice={voice_id[:8]} • model={model}", level="info", echo=True)
        if requests is not None:
            r = requests.post(url, headers=headers, json=payload, timeout=35)
            if r.status_code >= 400:
                _fz_nations_log(f"ElevenLabs HTTP {r.status_code}: {r.text[:260]}", level="warn", echo=True)
                return None
            data = r.content or b""
        else:
            raw = json.dumps(payload).encode("utf-8")
            req = _fz_nations_urlrequest.Request(url, data=raw, headers=headers, method="POST")
            with _fz_nations_urlrequest.urlopen(req, timeout=35) as resp:
                data = resp.read()
        if len(data) > 200:
            _fz_nations_log(f"[tts] áudio recebido do ElevenLabs ({len(data)} bytes)", level="info", echo=True)
            return data
        _fz_nations_log("ElevenLabs retornou áudio vazio/curto", level="warn", echo=True)
        return None
    except Exception as e:
        _fz_nations_log(f"ElevenLabs falhou: {e}", level="warn", echo=True)
        return None

def _fz_nations_tts_text_for_lang(texto, lang):
    """v48: traduz antes do TTS para todos os idiomas.
    Se a tradução falhar ou retornar texto original, bloqueia TTS.
    """
    texto = str(texto or '').strip()
    lang = _fz_nations_norm_lang(lang)
    if not texto:
        return ""
    source_lang = _fz_nations_norm_lang(_fz_nations_load_config().get("source_language") or "pt-BR")
    _fz_nations_log(f"texto original {source_lang}: {texto[:120]}", level="info", echo=True)
    if lang == source_lang:
        return texto
    translated = _fz_nations_translate_via_gateway(texto, lang, source_lang)
    if not translated or translated.strip().lower() == texto.strip().lower():
        _fz_nations_log(f"tradução inválida/ausente para {lang}; TTS bloqueado para evitar português com voz estrangeira", level="warn", echo=True)
        return ""
    _fz_nations_log(f"TTS recebeu {lang}: {translated[:120]}", level="info", echo=True)
    return translated

def _fz_nations_tts_voice_for_lang(lang):
    cfg = _fz_nations_load_config()
    gender = str(cfg.get('voice_gender') or 'auto').lower()
    if lang == 'en-US':
        if gender == 'male':
            return 'Daniel'
        return 'Samantha'
    return 'Samantha'

def _fz_nations_say_tts_mp3(texto, lang='en-US'):
    try:
        texto = str(texto or '').strip()
        if not texto:
            return None
        if len(texto) > 260:
            texto = texto[:260]
        say = shutil.which('say') or '/usr/bin/say'
        ffmpeg = _fz_nations_ffmpeg_path()
        if not Path(say).exists() or not ffmpeg:
            now = time.time()
            if now - float(nations_runtime.get('last_tts_missing_tool_at') or 0) > 20:
                nations_runtime['last_tts_missing_tool_at'] = now
                _fz_nations_log('TTS inglês aguardando: precisa do comando say e ffmpeg', level='warn', echo=True)
            return None
        voice = _fz_nations_tts_voice_for_lang(lang)
        with tempfile.TemporaryDirectory(prefix='fz_nations_tts_') as td:
            aiff = str(Path(td) / 'tts.aiff')
            cmd_say = [say, '-v', voice, '-o', aiff, texto]
            r = subprocess.run(cmd_say, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
            if r.returncode != 0 or not Path(aiff).exists():
                err = (r.stderr or b'').decode('utf-8','ignore')[:160]
                _fz_nations_log(f'TTS say falhou: {err}', level='warn', echo=True)
                return None
            cmd_ff = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-y', '-i', aiff, '-ac', '1', '-ar', '24000', '-codec:a', 'libmp3lame', '-b:a', '48k', '-f', 'mp3', 'pipe:1']
            p = subprocess.run(cmd_ff, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
            if p.returncode != 0:
                err = (p.stderr or b'').decode('utf-8','ignore')[:160]
                _fz_nations_log(f'TTS ffmpeg falhou: {err}', level='warn', echo=True)
                return None
            data = p.stdout or b''
            return data if len(data) > 200 else None
    except Exception as e:
        now = time.time()
        if now - float(nations_runtime.get('last_tts_error_at') or 0) > 10:
            nations_runtime['last_tts_error_at'] = now
            _fz_nations_log(f'TTS inglês erro: {e}', level='warn', echo=True)
        return None

def _fz_nations_tts_worker():
    _fz_nations_log('tts worker v54 iniciado • provider runtime + idiomas opcionais', echo=True)
    while True:
        try:
            item = NATIONS_TTS_QUEUE.get(timeout=1.0)
        except Exception:
            continue
        try:
            lang = _fz_nations_norm_lang(item.get('lang') or 'en-US')
            job_generation = int(item.get('provider_generation') or 0)
            if job_generation != _fz_nations_tts_generation():
                _fz_nations_log(f'tts job descartado por troca de provider • {lang}', level='warn', echo=True)
                continue
            source_text = str(item.get('source_text') or item.get('text') or '').strip()
            texto_tts = _fz_nations_tts_text_for_lang(source_text, lang)
            if not texto_tts:
                continue
            if job_generation != _fz_nations_tts_generation():
                _fz_nations_log(f'tts job cancelado antes do provider • {lang}', level='warn', echo=True)
                continue
            provider_now = _fz_nations_effective_tts_provider(lang)
            _fz_nations_log(f"[tts] provider efetivo por job={provider_now} • idioma={lang}", level="info", echo=True)
            if provider_now in ("local", "piper", "say", "macos", "system"):
                mp3 = _fz_nations_say_tts_mp3(texto_tts, lang)
            else:
                mp3 = _fz_nations_elevenlabs_tts_mp3(texto_tts, lang)
            if job_generation != _fz_nations_tts_generation():
                _fz_nations_log(f'audio TTS descartado após troca de provider • {lang}', level='warn', echo=True)
                continue
            if mp3:
                ok = _fz_nations_post_audio_ingest(mp3, lang=lang, audio_type='translated', mime='audio/mpeg', text=texto_tts, source_text=source_text)
                nations_runtime['last_tts_lang'] = lang
                nations_runtime['last_tts_at'] = time.time()
                nations_runtime['tts_chunks_sent'] = int(nations_runtime.get('tts_chunks_sent') or 0) + (1 if ok else 0)
                if ok:
                    _fz_nations_log(f'audio traduzido enviado • {lang} • {len(mp3)} bytes', echo=True)
        except Exception as e:
            _fz_nations_log(f'tts worker erro: {e}', level='warn', echo=True)

def _fz_nations_heartbeat_body():
    cfg = _fz_nations_load_config()
    running = bool(nations_runtime.get("running"))
    active = cfg.get("active_languages") or ["en-US"]
    if isinstance(active, str):
        active = [active]
    body = {
        "device_id": cfg.get("device_id"),
        "name": cfg.get("device_name") or _fz_nations_socket.gethostname(),
        "status": "translating" if running else "online",
        "os": _fz_nations_os_name(),
        "os_version": _fz_nations_os_version(),
        "core_version": NATIONS_VERSION,
        "cpu": _fz_nations_cpu_percent(),
        "ram": _fz_nations_ram_mb(),
        "gpu": "Apple Silicon/Metal" if _fz_nations_os_name() == "Darwin" else "",
        "uptime_seconds": int(time.time() - NATIONS_STARTED_AT),
        "church_id": cfg.get("church_id"),
        "user_id": cfg.get("user_id"),
        "church_slug": cfg.get("church_slug"),
        "languages_live": active if running else [],
        "translation": {"languages": active if running else []},
        "logs": list(NATIONS_LOGS[-8:]) or [{"level":"info", "message": f"[BRIDGE] Core online • CPU {_fz_nations_cpu_percent()}%"}],
        "transcription_ingest": {
            "ok": bool(nations_runtime.get("last_ingest_ok")),
            "last_at": nations_runtime.get("last_ingest_at"),
            "last_status": nations_runtime.get("last_ingest_status"),
            "last_error": nations_runtime.get("last_ingest_error", ""),
        },
        "audio_ingest": {
            "ok": bool(nations_runtime.get("last_audio_ingest_ok")),
            "last_at": nations_runtime.get("last_audio_ingest_at"),
            "last_lang": nations_runtime.get("last_audio_ingest_lang"),
            "last_type": nations_runtime.get("last_audio_ingest_type"),
            "last_error": nations_runtime.get("last_audio_ingest_error", ""),
            "chunks_sent": int(nations_runtime.get("audio_chunks_sent") or 0),
        },
        "tts_installed": _fz_nations_installed_tts_languages(),
        "installed_languages": _fz_nations_installed_tts_languages(),
        "voice_languages": _fz_nations_installed_tts_languages(),
        "language_packages": [{"code": c, "installed": True, "engine": "piper"} for c in _fz_nations_installed_tts_languages()],
        "voice_packages": [{"code": c, "installed": True, "engine": "piper"} for c in _fz_nations_installed_tts_languages()],
        "nations_status": _fz_nations_status_payload(),
    }
    # Envia token quando existir. Sem token/user/church completos o servidor retorna 400.
    if cfg.get("pairing_token") or cfg.get("token"):
        body["token"] = cfg.get("pairing_token") or cfg.get("token")
    if cfg.get("email") or cfg.get("user_email"):
        body["email"] = cfg.get("email") or cfg.get("user_email")
    return body

def _fz_nations_post_heartbeat_once():
    cfg = _fz_nations_load_config()
    if not _fz_nations_is_enabled(cfg):
        nations_runtime["last_heartbeat_ok"] = False
        nations_runtime["last_heartbeat_error"] = "nations_disabled"
        return False, "nations_disabled"
    if not nations_runtime.get("running"):
        nations_runtime["last_heartbeat_ok"] = False
        nations_runtime["last_heartbeat_error"] = "nations_stopped"
        return False, "nations_stopped"
    if not _fz_nations_has_remote_identity(cfg):
        nations_runtime["last_heartbeat_ok"] = False
        nations_runtime["last_heartbeat_error"] = "nations_unpaired"
        return False, "nations_unpaired"
    url = cfg.get("heartbeat_url") or "https://nations.framezeroai.com.br/api/public/device-heartbeat"
    body = _fz_nations_heartbeat_body()
    has_church_payload = bool(body.get("church_id") or body.get("church_slug") or body.get("token"))
    has_user_payload = bool(body.get("user_id") or body.get("email") or body.get("user_email") or body.get("token"))
    if not (has_church_payload and has_user_payload):
        nations_runtime["last_heartbeat_ok"] = False
        nations_runtime["last_heartbeat_error"] = "nations_identity_incomplete"
        return False, "nations_identity_incomplete"
    raw = json.dumps(body, ensure_ascii=False).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        # Cloudflare Bot Fight Mode pode bloquear python-urllib/requests.
        # Usamos UA de browser para o endpoint público do Core.
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36 FrameZeroCore/0.1.50",
    }
    secret = cfg.get("bridge_secret") or os.environ.get("NATIONS_BRIDGE_SECRET") or NATIONS_BRIDGE_SECRET_DEFAULT
    if secret:
        headers["x-bridge-secret"] = str(secret)
    req = _fz_nations_urlrequest.Request(url, data=raw, headers=headers, method="POST")
    try:
        with _fz_nations_urlrequest.urlopen(req, timeout=30) as resp:
            txt = resp.read(1024 * 1024).decode("utf-8", "ignore")
            nations_runtime["last_heartbeat_at"] = time.time()
            nations_runtime["last_heartbeat_ok"] = True
            nations_runtime["last_heartbeat_status"] = int(getattr(resp, "status", 200))
            nations_runtime["last_heartbeat_error"] = ""
            _fz_nations_apply_heartbeat_config(txt)
            return True, txt
    except _fz_nations_urlerror.HTTPError as e:
        txt = e.read(1024 * 1024).decode("utf-8", "ignore")
        nations_runtime["last_heartbeat_ok"] = False
        nations_runtime["last_heartbeat_status"] = int(e.code)
        nations_runtime["last_heartbeat_error"] = txt
        if e.code == 401:
            _fz_nations_log("device-heartbeat 401; usando x-bridge-secret e aguardando token/bridge atualizado", level="warn")
        else:
            _fz_nations_log(f"device-heartbeat HTTP {e.code}: {txt[:160]}", level="warn")
        return False, txt
    except Exception as e:
        nations_runtime["last_heartbeat_ok"] = False
        nations_runtime["last_heartbeat_error"] = str(e)
        _fz_nations_log(f"device-heartbeat pendente: {e}", level="warn", echo=False)
        return False, str(e)

def _fz_nations_heartbeat_loop():
    time.sleep(2.0)
    while True:
        try:
            ok, _ = _fz_nations_post_heartbeat_once()
            if ok:
                # Não spammar terminal a cada 10s; logs do site recebem no body.
                pass
        except Exception as e:
            print(f"[nations] heartbeat loop erro: {e}")
        time.sleep(10.0)

try:
    _fz_nations_load_config()
    if _fz_nations_is_enabled():
        print(f"[nations] módulo carregado • versão {NATIONS_VERSION}")
        print(f"[nations] servidor ativo: {Path(__file__).resolve()}")
        threading.Thread(target=_fz_nations_heartbeat_loop, daemon=True).start()
        threading.Thread(target=_fz_nations_audio_worker, daemon=True).start()
        threading.Thread(target=_fz_nations_tts_worker, daemon=True).start()
        print("[nations] device heartbeat ativo • endpoint=https://nations.framezeroai.com.br/api/public/device-heartbeat")
        print("[nations] audio-ingest ativo • original=pt-BR • translated=todos idiomas • v50")
    else:
        # Nations instalado no arquivo, mas desligado na instalação somente Clips.
        pass
except Exception as _fz_nations_init_e:
    print(f"[nations] falha ao iniciar v42: {_fz_nations_init_e}")
# ----------------------------- FIM FRAMEZERO NATIONS CONSOLIDATED CORE V42 -----------------------------

def enviar(payload):
    try:
        if _fz_nations_is_enabled():
            _fz_nations_on_payload(payload)
    except Exception:
        pass
    if loop_principal is None: return
    msg = json.dumps(payload, ensure_ascii=False)
    for ws in list(clientes):
        asyncio.run_coroutine_threadsafe(_envia(ws,msg), loop_principal)

async def _envia(ws,msg):
    try: await ws.send(msg)
    except Exception: clientes.discard(ws)

async def handler(ws):
    global fonte_audio, preview_ativo, vertical_ativo, texto_desde_ia, texto_contexto_ia, pendencia_transcricao, ultima_ia
    clientes.add(ws)
    # manda estado inicial: chave, gravando, dispositivos de audio e o atual
    disp_atual = config_usuario.get("dispositivo_audio", CONFIG["dispositivo_audio"])
    await ws.send(json.dumps({"tipo":"status","gravando":gravando,
        "transcricao_ativa":bool(config_usuario.get("transcricao_ativa", CONFIG.get("transcricao_ativa", True))),
        "tem_chave":bool(config_usuario.get("openai_key")),
        "obs_conectado":obs_conectado}, ensure_ascii=False))
    await ws.send(json.dumps({"tipo":"dispositivos",
        "lista":listar_dispositivos_entrada(),
        "atual":disp_atual,
        "fonte":fonte_audio,
        "plugin_conectado":plugin_conectado,
        "blackhole_instalado": False,
        "sounddevice_ok": SOUNDDEVICE_OK,
        "sounddevice_erro": SOUNDDEVICE_ERROR}, ensure_ascii=False))
    await ws.send(json.dumps({"tipo":"audio_status", **audio_status_atual}, ensure_ascii=False))
    await ws.send(json.dumps({"tipo":"vps_status", **vps_status_atual}, ensure_ascii=False))
    try:
        await ws.send(json.dumps(_fz_nations_status_payload(), ensure_ascii=False))
    except Exception as e:
        print(f"[nations] falha ao enviar status inicial: {e}")
    await ws.send(json.dumps({"tipo":"config_extra",
        "language_profiles":perfis_idioma_para_painel(),
        "language_profile":perfil_id_atual(),
        "source_language":whisper_language_atual(),
        "output_language":output_language_atual(),
        "global_language_mode":config_usuario.get("global_language_mode", CONFIG.get("global_language_mode", "standard")),
        "live_translation_enabled":bool(config_usuario.get("live_translation_enabled", CONFIG.get("live_translation_enabled", False))),
        "live_translation_provider":config_usuario.get("live_translation_provider", CONFIG.get("live_translation_provider", "gemini")),
        "live_translation_target":config_usuario.get("live_translation_target", CONFIG.get("live_translation_target", "en")),
        "phrase_ai_enabled":bool(config_usuario.get("phrase_ai_enabled", CONFIG.get("phrase_ai_enabled", False))),
        "phrase_ai_provider":config_usuario.get("phrase_ai_provider", CONFIG.get("phrase_ai_provider", "gemini")),
        "proporcao":config_usuario.get("proporcao_corte", CONFIG["proporcao_corte"]),
        "vertical_ativo":vertical_ativo,
        "vertical_cena":config_usuario.get("vertical_cena", CONFIG["vertical_cena"]),
        "transcricao_modo":"local",
        "whisper_local_perfil":config_usuario.get("whisper_local_perfil", CONFIG.get("whisper_local_perfil", "leve")),
        "whisper_local_usuario_tem_gpu":config_usuario.get("whisper_local_usuario_tem_gpu", CONFIG.get("whisper_local_usuario_tem_gpu", False)),
        "whisper_vps_base_url":"",
        "whisper_vps_token":"",
        "transcription_engine":config_usuario.get("transcription_engine", "mlx-whisper"),
        "transcricao_motor":config_usuario.get("transcricao_motor", "padrao"),
        "transcricao_ativa":bool(config_usuario.get("transcricao_ativa", CONFIG.get("transcricao_ativa", True))),
        "openai_api_key":config_usuario.get("openai_api_key", config_usuario.get("openai_key", "")),
        "openai_realtime_model":config_usuario.get("openai_realtime_model", "gpt-realtime-whisper"),
        "openai_realtime_delay":config_usuario.get("openai_realtime_delay", "high"),
        "gemini_api_key":config_usuario.get("gemini_api_key", ""),
        "gemini_enabled":bool(config_usuario.get("gemini_enabled", False)),
        "gemini_model":config_usuario.get("gemini_model", "gemini-2.5-flash-lite"),
        "gemini_tutorial_url":config_usuario.get("gemini_tutorial_url", CONFIG.get("gemini_tutorial_url", "https://ai.google.dev/gemini-api/docs/api-key")),
        "corte_seguro":config_usuario.get("corte_seguro", True),
        "agrupar_assunto":config_usuario.get("agrupar_assunto", True),
        "duracao_corte_min":config_usuario.get("duracao_corte_min", CONFIG.get("duracao_corte_min", 15)),
        "duracao_corte_max":config_usuario.get("duracao_corte_max", CONFIG.get("duracao_corte_max", 45)),
        "corte_exato_automatico":config_usuario.get("corte_exato_automatico", CONFIG.get("corte_exato_automatico", True)),
        "tipo_conteudo":config_usuario.get("tipo_conteudo", CONFIG.get("tipo_conteudo", "pregacao")),
        "detectar_musica_pregacao":config_usuario.get("detectar_musica_pregacao", CONFIG.get("detectar_musica_pregacao", False)),
        "musica_usar_letra_online":config_usuario.get("musica_usar_letra_online", CONFIG.get("musica_usar_letra_online", True)),
        "ollama_internet_conectado":config_usuario.get("ollama_internet_conectado", CONFIG.get("ollama_internet_conectado", True)),
        "musica_confianca_minima_letra":config_usuario.get("musica_confianca_minima_letra", CONFIG.get("musica_confianca_minima_letra", 0.82))} , ensure_ascii=False))
    for l in linhas: await ws.send(json.dumps(l, ensure_ascii=False))
    for c in cortes: await ws.send(json.dumps(c, ensure_ascii=False))
    try:
        async for raw in ws:
            try: req = json.loads(raw)
            except Exception: continue
            if await _fz_nations_handle_ws(ws, req):
                continue
            acao = req.get("acao") or req.get("tipo") or req.get("action") or req.get("tipo") or req.get("action")
            if acao == "salvar_chave":
                chave = (req.get("chave") or "").strip()
                config_usuario["openai_key"] = chave
                config_usuario["openai_api_key"] = chave
                salvar_config_usuario({"openai_key": chave, "openai_api_key": chave})
                ok = bool(chave)
                await ws.send(json.dumps({"tipo":"chave_salva","tem_chave":ok}, ensure_ascii=False))
                print(f"[chave] {'salva' if ok else 'removida'}")
            elif acao == "listar_dispositivos":
                await ws.send(json.dumps({"tipo":"dispositivos",
                    "lista":listar_dispositivos_entrada(),
                    "atual":config_usuario.get("dispositivo_audio", None),
                    "blackhole_instalado": False,
                    "sounddevice_ok": SOUNDDEVICE_OK,
                    "sounddevice_erro": SOUNDDEVICE_ERROR}, ensure_ascii=False))
            elif acao == "escolher_dispositivo":
                d = req.get("dispositivo")  # None (padrao) ou indice inteiro
                d = None if d in (None, "", "padrao") else int(d)
                # escolher um dispositivo automaticamente volta a fonte pra "dispositivo"
                fonte_audio = "dispositivo"
                config_usuario["fonte_audio"] = "dispositivo"
                salvar_config_usuario({"fonte_audio": "dispositivo"})
                ok, nome = abrir_audio(d)
                if ok:
                    config_usuario["dispositivo_audio"] = d
                    salvar_config_usuario({"dispositivo_audio": d})
                await ws.send(json.dumps({"tipo":"dispositivo_ok","ok":ok,
                    "nome":nome,"atual":d,"fonte":"dispositivo"}, ensure_ascii=False))
            elif acao == "usar_blackhole_obs":
                await ws.send(json.dumps({"tipo":"blackhole_ok","ok":False,
                    "msg":"BlackHole nao disponivel no Windows."}, ensure_ascii=False))
            elif acao == "usar_plugin_mixer":
                # legado: passa a usar o audio que vem do plugin obs-audio-to-websocket, se existir.
                fonte_audio = "plugin"
                config_usuario["fonte_audio"] = "plugin"
                salvar_config_usuario({"fonte_audio": "plugin"})
                # fecha o stream local do microfone, ja que nao sera usado
                if stream_audio is not None:
                    try: stream_audio.stop(); stream_audio.close()
                    except Exception: pass
                await ws.send(json.dumps({"tipo":"fonte_plugin_ok",
                    "conectado":plugin_conectado}, ensure_ascii=False))
                print("[audio] fonte = plugin do mixer do OBS")
            elif acao == "toggle_transcricao":
                atual = bool(config_usuario.get("transcricao_ativa", CONFIG.get("transcricao_ativa", True)))
                novo = bool(req.get("ativa")) if "ativa" in req else (not atual)
                config_usuario["transcricao_ativa"] = novo
                salvar_config_usuario({"transcricao_ativa": novo})
                if not novo:
                    texto_desde_ia = []
                    texto_contexto_ia = []
                    pendencia_transcricao = ""
                else:
                    ultima_ia = time.time()
                enviar({"tipo":"transcricao_toggle","ativa":novo,"gravando":gravando,
                        "motivo":"transcrição reativada" if novo else "transcrição desativada"})
                print(f"[transcricao] {'reativada' if novo else 'desativada'} pelo painel")
            elif acao == "clipar_agora":
                titulo = (req.get("titulo") or "momento-manual").strip()
                salvar_clipe(titulo=titulo, motivo="manual")
            elif acao == "salvar_senha_obs":
                s = (req.get("senha") or "").strip()
                p = req.get("porta")
                try: p = int(p) if p else CONFIG["obs_porta"]
                except Exception: p = CONFIG["obs_porta"]
                config_usuario["obs_senha"] = s
                config_usuario["obs_porta"] = p
                salvar_config_usuario({"obs_senha": s, "obs_porta": p})
                ok = iniciar_obs(senha_manual=s, porta_manual=p) if s else False
                await ws.send(json.dumps({"tipo":"obs_status","conectado":bool(ok),
                    "manual":True}, ensure_ascii=False))
                print(f"[obs] senha do painel: {'conectou' if ok else 'falhou'}")
            elif acao == "salvar_transcricao_config":
                # v79: seletor Padrao/Turbo. Padrao usa MLX local; Turbo usa OpenAI Realtime.
                modo_painel = str(req.get("transcricao") or req.get("modo_transcricao") or req.get("transcription_mode") or req.get("modo") or "local").lower().strip()
                motor = str(req.get("transcricao_motor") or req.get("motor_transcricao") or req.get("engine_modo") or req.get("modo_motor") or config_usuario.get("transcricao_motor", "padrao")).lower().strip()
                if motor not in ("padrao", "turbo"):
                    motor = "padrao"
                perfil = str(req.get("whisper_local_perfil") or config_usuario.get("whisper_local_perfil", CONFIG.get("whisper_local_perfil", "leve"))).lower().strip()
                if perfil not in ("leve", "pro"):
                    perfil = "leve"
                updates = {
                    "transcricao_modo": "local",
                    "transcricao_modo_painel": modo_painel,
                    "transcricao_motor": motor,
                    "motor_transcricao": motor,
                    "transcricao_ativa": bool(config_usuario.get("transcricao_ativa", CONFIG.get("transcricao_ativa", True))),
                    "openai_realtime_model": req.get("openai_realtime_model", "gpt-realtime-whisper"),
                    "openai_realtime_delay": req.get("openai_realtime_delay", "high"),
                    "openai_realtime_commit_segundos": float(req.get("openai_realtime_commit_segundos", 12.0) or 12.0),
                    "gemini_enabled": bool(req.get("gemini_enabled", config_usuario.get("gemini_enabled", False))),
                    # IMPORTANTE: nao apagar a chave Gemini salva quando o painel envia payload parcial
                    # ou quando o campo vem vazio durante conexao/reconfiguracao.
                    "gemini_api_key": (
                        str(req.get("gemini_api_key") or "").strip()
                        if str(req.get("gemini_api_key") or "").strip()
                        else str(config_usuario.get("gemini_api_key", "") or "").strip()
                    ),
                    "gemini_model": req.get("gemini_model", config_usuario.get("gemini_model", "gemini-2.5-flash-lite")),
                    "gemini_intervalo_seg": float(req.get("gemini_intervalo_seg", config_usuario.get("gemini_intervalo_seg", 60.0)) or 60.0),
                    "gemini_janela_contexto_seg": float(req.get("gemini_janela_contexto_seg", config_usuario.get("gemini_janela_contexto_seg", 180.0)) or 180.0),
                    "gemini_min_chars": int(req.get("gemini_min_chars", config_usuario.get("gemini_min_chars", 1200)) or 1200),
                    "gemini_max_chars": int(req.get("gemini_max_chars", config_usuario.get("gemini_max_chars", 9000)) or 9000),
                    "bloco_segundos_corte_seguro": float(req.get("bloco_segundos_corte_seguro", 15.0) or 15.0),
                    "overlap_segundos_corte_seguro": float(req.get("overlap_segundos_corte_seguro", 5.0) or 5.0),
                    "corte_seguro": True,
                    "agrupar_assunto": True,
                    "vps_enviar_audio_ao_vivo": False,
                    "hibrido_processa_local_refina_vps": False,
                    "hibrido_envia_audio_para_vps": False,
                    "hibrido_envia_texto_para_vps": False,
                    "vps_fallback_local": False,
                    "vps_analisar_com_ia_local": False,
                    "whisper_vps_url": "",
                    "whisper_vps_base_url": "",
                    "whisper_vps_endpoint": "",
                    "whisper_vps_analyze_endpoint": "",
                    "transcription_engine": "mlx-whisper",
                    "local_asr_engine": "mlx-whisper",
                    "forcar_ptbr_local": perfil_id_atual().startswith("pt"),
                    "idioma_whisper_local": whisper_language_atual(),
                    "whisper_local_language": whisper_language_atual(),
                    "whisper_local_task": "transcribe",
                    "correcao_contextual_ao_vivo": True,
                    "prompt_transcricao": "",
                    "whisper_local_perfil": perfil,
                    "whisper_local_usuario_tem_gpu": False,
                    "whisper_local_modelo_leve": "mlx-community/whisper-large-v3-turbo",
                    "whisper_local_modelo_pro": "mlx-community/whisper-large-v3",
                }
                chave_turbo = (req.get("openai_api_key") or req.get("openai_key") or req.get("chave_openai") or "").strip()
                if chave_turbo:
                    updates["openai_api_key"] = chave_turbo
                    updates["openai_key"] = chave_turbo
                config_usuario.update(updates)
                salvar_config_usuario(updates)
                enviar({"tipo":"config_ok", **updates})
                print(f"[config] motor={motor} padrao=mlx turbo=openai-realtime modelo={modelo_mlx_atual()} painel_pediu={modo_painel}")
            elif acao == "salvar_whisper_local_config":
                perfil = str(req.get("perfil") or req.get("whisper_local_perfil") or "leve").lower().strip()
                if perfil not in ("leve", "pro"):
                    perfil = "leve"
                tem_gpu = bool(req.get("tem_gpu", req.get("whisper_local_usuario_tem_gpu", False)))
                updates = {
                    "whisper_local_perfil": perfil,
                    "whisper_local_usuario_tem_gpu": tem_gpu,
                    "whisper_local_modelo_leve": "mlx-community/whisper-large-v3-turbo",
                    "whisper_local_modelo_pro": "mlx-community/whisper-large-v3",
                    "modelo_ao_vivo": "small",
                }
                config_usuario.update(updates)
                salvar_config_usuario(updates)
                enviar({"tipo":"whisper_local_config_ok", **updates})
                print(f"[config] whisper_local perfil={perfil} gpu={tem_gpu} modelo={updates['modelo_ao_vivo']}")
            elif acao == "salvar_global_language_config":
                perfil = str(req.get("language_profile") or req.get("idioma") or "pt-BR").strip()
                if perfil not in LANGUAGE_PROFILES:
                    perfil = "pt-BR"
                modo_global = str(req.get("global_language_mode") or req.get("modo_global") or "standard").lower().strip()
                if modo_global not in ("standard", "ai_boost"):
                    modo_global = "standard"
                prof = LANGUAGE_PROFILES[perfil]
                updates = {
                    "language_profile": perfil,
                    "global_language_mode": modo_global,
                    "source_language": prof.get("whisper_language", "pt"),
                    "output_language": prof.get("output_language", perfil),
                    "whisper_local_language": prof.get("whisper_language", "pt"),
                    "idioma_whisper_local": prof.get("whisper_language", "pt"),
                    "forcar_ptbr_local": perfil.startswith("pt"),
                    "contexto_transcricao": prof.get("context", "Christian sermon"),
                    "prompt_transcricao": "",
                    "transcricao_modo": "local",
                }
                config_usuario.update(updates)
                salvar_config_usuario(updates)
                enviar({"tipo":"global_language_ok", **updates, "language_profiles":perfis_idioma_para_painel()})
                print(f"[global] idioma={perfil} whisper={updates['source_language']} modo={modo_global}")
            elif acao == "salvar_ai_boost_config":
                modo_global = "ai_boost" if bool(req.get("enabled", req.get("ai_boost_enabled", True))) else "standard"
                provider = str(req.get("provider") or req.get("live_translation_provider") or config_usuario.get("live_translation_provider", "gemini")).lower().strip()
                if provider not in ("gemini", "openai"):
                    provider = "gemini"
                target = str(req.get("target_language") or req.get("live_translation_target") or config_usuario.get("live_translation_target", "en")).strip() or "en"
                updates = {
                    "global_language_mode": modo_global,
                    "live_translation_enabled": bool(req.get("live_translation_enabled", False)),
                    "live_translation_provider": provider,
                    "live_translation_target": target,
                    "phrase_ai_enabled": bool(req.get("phrase_ai_enabled", False)),
                    "phrase_ai_provider": provider,
                }
                config_usuario.update(updates)
                salvar_config_usuario(updates)
                enviar({"tipo":"ai_boost_ok", **updates})
                print(f"[global-ai] modo={modo_global} provider={provider} traducao={updates['live_translation_enabled']} frase_ai={updates['phrase_ai_enabled']} target={target}")
            elif acao == "salvar_tipo_conteudo":
                tipo_conteudo = str(req.get("tipo_conteudo") or req.get("content_type") or "pregacao").lower().strip()
                if tipo_conteudo not in ("pregacao", "musica"):
                    tipo_conteudo = "pregacao"
                updates = {"tipo_conteudo": tipo_conteudo, "detectar_musica_pregacao": False}
                config_usuario.update(updates)
                salvar_config_usuario(updates)
                enviar({"tipo":"tipo_conteudo_ok", **updates})
                print(f"[config] tipo_conteudo={tipo_conteudo}")
            elif acao == "salvar_refino_letra_online":
                ativo = bool(req.get("ativo", True))
                conf = req.get("confianca_minima", config_usuario.get("musica_confianca_minima_letra", CONFIG.get("musica_confianca_minima_letra", 0.82)))
                try:
                    conf = float(conf)
                except Exception:
                    conf = 0.82
                conf = max(0.50, min(0.98, conf))
                updates = {
                    "ollama_internet_conectado": True,
                    "musica_usar_letra_online": ativo,
                    "musica_refino_online": ativo,
                    "musica_busca_letra_online": ativo,
                    "musica_nao_substituir_sem_confianca": True,
                    "musica_confianca_minima_letra": conf,
                    "musica_preservar_louvor_espontaneo": True,
                    "lyrics_reference_source": "web_via_ollama_vps",
                    "lyrics_reference_policy": "internet_sugere_audio_manda"
                }
                config_usuario.update(updates)
                salvar_config_usuario(updates)
                enviar({"tipo":"refino_letra_online_ok", **updates})
                print(f"[config] refino_letra_online={ativo} conf={conf}")
            elif acao == "salvar_gemini_config":
                # A chave da Google/Gemini deve permanecer salva mesmo quando o usuario
                # desliga o Gemini ou quando o painel reconecta e manda um payload sem chave.
                chave_recebida = req.get("gemini_api_key", req.get("chave_gemini", None))
                chave_atual = str(config_usuario.get("gemini_api_key", "") or "").strip()
                if chave_recebida is None:
                    chave = chave_atual
                else:
                    chave_nova = str(chave_recebida or "").strip()
                    chave = "" if bool(req.get("gemini_clear_key", False)) else (chave_nova or chave_atual)
                ativo = bool(req.get("gemini_enabled", config_usuario.get("gemini_enabled", bool(chave))))
                updates = {
                    "gemini_enabled": ativo,
                    "gemini_api_key": chave,
                    "gemini_model": req.get("gemini_model", config_usuario.get("gemini_model", "gemini-2.5-flash-lite")),
                    "gemini_intervalo_seg": float(req.get("gemini_intervalo_seg", config_usuario.get("gemini_intervalo_seg", 60.0)) or 60.0),
                    "gemini_janela_contexto_seg": float(req.get("gemini_janela_contexto_seg", config_usuario.get("gemini_janela_contexto_seg", 180.0)) or 180.0),
                    "gemini_min_chars": int(req.get("gemini_min_chars", config_usuario.get("gemini_min_chars", 1200)) or 1200),
                    "gemini_max_chars": int(req.get("gemini_max_chars", config_usuario.get("gemini_max_chars", 9000)) or 9000),
                    "gemini_tutorial_url": "https://ai.google.dev/gemini-api/docs/api-key",
                }
                config_usuario.update(updates)
                salvar_config_usuario(updates)
                enviar({"tipo":"gemini_config_ok", **updates})
                print(f"[gemini] enabled={ativo} model={updates['gemini_model']} intervalo={updates['gemini_intervalo_seg']}s")
            elif acao == "salvar_corte_config":
                modo = str(req.get("corte_modo", req.get("modo_corte", "standard"))).lower().strip()
                if modo not in ("fast", "standard"):
                    modo = "standard"
                if modo == "fast":
                    updates = {
                        "corte_modo": "fast",
                        "limiar_corte": int(req.get("limiar_corte", 60)),
                        "cooldown_corte_seg": int(req.get("cooldown_corte_segundos", req.get("cooldown_corte_seg", 18))),
                        "intervalo_ia_seg": float(req.get("janela_analise_segundos", 8)),
                        "duracao_corte_min": 15,
                        "duracao_corte_max": 45,
                        "margem_antes_corte": 8,
                        "margem_depois_corte": 6,
                        "corte_seguro_agrupar_assunto": False,
                    }
                else:
                    # Corte Seguro: menos cortes, mais contexto, sem score inflado e sem picotar assunto.
                    updates = {
                        "corte_modo": "standard",
                        "limiar_corte": max(60, int(req.get("limiar_corte", 60))),
                        "cooldown_corte_seg": max(55, int(req.get("cooldown_corte_segundos", req.get("cooldown_corte_seg", 60)))),
                        "intervalo_ia_seg": max(15.0, float(req.get("janela_analise_segundos", 30))),
                        "duracao_corte_min": 15,
                        "duracao_corte_max": 60,
                        "margem_antes_corte": 12,
                        "margem_depois_corte": 10,
                        "corte_seguro_agrupar_assunto": True,
                    }
                config_usuario.update(updates)
                salvar_config_usuario(updates)
                enviar({"tipo":"config_ok", **updates})
                print(f"[config] modo corte={modo} limiar={updates['limiar_corte']} cooldown={updates['cooldown_corte_seg']} intervalo={updates['intervalo_ia_seg']} dur={updates['duracao_corte_min']}-{updates['duracao_corte_max']}")
            elif acao == "salvar_duracao_cortes":
                try:
                    mn = int(req.get("min", 15))
                    mx = int(req.get("max", 45))
                except Exception:
                    mn, mx = 15, 45
                mn = max(5, min(300, mn))
                mx = max(5, min(300, mx))
                if mx < mn:
                    mx = mn
                # Margens proporcionais para o clipe automático e cortes finais.
                antes = max(3, min(20, int(mn * 0.65)))
                depois = max(3, min(20, int(mn * 0.45)))
                updates = {"duracao_corte_min": mn, "duracao_corte_max": mx,
                           "margem_antes_corte": antes, "margem_depois_corte": depois}
                config_usuario.update(updates)
                salvar_config_usuario(updates)
                enviar({"tipo":"duracao_ok", **updates})
                print(f"[config] duracao cortes min={mn}s max={mx}s")
            elif acao == "preview":
                await ws.send(json.dumps({"tipo":"preview_status","ativo":False,"msg":"Preview do corte removido"}, ensure_ascii=False))
            elif acao == "vertical_mode":
                ligar = bool(req.get("ligar"))
                ok, msg = configurar_cena_vertical(ligar)
                await ws.send(json.dumps({"tipo":"vertical_status","ok":ok,
                    "ligado":vertical_ativo,"msg":msg,
                    "cena":config_usuario.get("vertical_cena", CONFIG["vertical_cena"])} , ensure_ascii=False))
            elif acao == "tracking":
                ligar = bool(req.get("ligar"))
                ok, msg = ligar_tracking(ligar)
                config_usuario["tracking"] = ligar if ok else config_usuario.get("tracking", False)
                if ok: salvar_config_usuario({"tracking": ligar})
                await ws.send(json.dumps({"tipo":"tracking_status","ok":ok,
                    "ligado":(ligar if ok else False),"msg":msg}, ensure_ascii=False))
            elif acao == "escolher_proporcao":
                p = req.get("proporcao", "9:16")
                if p in ("9:16","1:1","16:9","original"):
                    config_usuario["proporcao_corte"] = p
                    salvar_config_usuario({"proporcao_corte": p})
                    await ws.send(json.dumps({"tipo":"proporcao_ok","proporcao":p}, ensure_ascii=False))
                    print(f"[proporcao] cortes em {p}")
            elif acao == "recomecar":
                resetar_sessao()
            elif acao == "gerar_cortes":
                threading.Thread(target=gerar_cortes_precisos, daemon=True).start()
            elif acao == "gerar_capitulos":
                def _caps():
                    caps = gerar_capitulos_ia()
                    enviar({"tipo":"capitulos","lista":caps})
                threading.Thread(target=_caps, daemon=True).start()
            elif acao == "exportar_srt":
                await ws.send(json.dumps({"tipo":"arquivo_srt","conteudo":gerar_srt()}, ensure_ascii=False))
            elif acao == "exportar_txt":
                await ws.send(json.dumps({"tipo":"arquivo_txt","conteudo":gerar_txt()}, ensure_ascii=False))
    finally:
        clientes.discard(ws)

# ----------------------------- CORTES PRECISOS (pos-culto) -----------------------------

def caminho_ffmpeg():
    """Acha o ffmpeg: primeiro no PATH do sistema, depois na pasta do projeto
    (onde o instalador Windows pode ter colocado)."""
    no_path = shutil.which("ffmpeg")
    if no_path:
        return no_path
    local = PASTA / "ffmpeg" / "bin" / ("ffmpeg.exe" if os.name == "nt" else "ffmpeg")
    if local.exists():
        return str(local)
    return None

def caminho_ffprobe():
    """Acha o ffprobe para ler a duração/timecode real dos arquivos do OBS."""
    no_path = shutil.which("ffprobe")
    if no_path:
        return no_path
    local = PASTA / "ffmpeg" / "bin" / ("ffprobe.exe" if os.name == "nt" else "ffprobe")
    if local.exists():
        return str(local)
    return None

def duracao_video_seg(caminho):
    """Retorna duração real do arquivo em segundos usando ffprobe.
    Isso é essencial para recortar Replay Buffer: o arquivo bruto pode ter 120s,
    mas o corte final precisa respeitar o timecode do SRT/transcrição.
    """
    ffprobe = caminho_ffprobe()
    if not ffprobe or not caminho or not os.path.exists(caminho):
        return None
    try:
        import subprocess
        r = subprocess.run([ffprobe, "-v", "error", "-show_entries", "format=duration",
                            "-of", "default=noprint_wrappers=1:nokey=1", caminho],
                           capture_output=True, text=True, timeout=30)
        if r.returncode == 0:
            return float((r.stdout or "").strip())
    except Exception:
        pass
    return None

def filtro_proporcao(prop):
    """
    Devolve o filtro -vf do ffmpeg pra reenquadrar o clipe na proporcao pedida.
    Faz crop central a partir de um video 1920x1080. 'original' nao reenquadra.
      9:16  -> 1080x1920 (Reels/Shorts/TikTok), crop central na largura
      1:1   -> 1080x1080 (feed quadrado), crop central
      16:9  -> mantem widescreen (so garante 1920x1080)
    """
    prop = str(prop or "original").replace("x", ":")
    if prop == "9:16":
        # recorta a faixa central vertical e escala pra 1080x1920
        return "crop=ih*9/16:ih:(iw-ih*9/16)/2:0,scale=1080:1920"
    if prop == "1:1":
        return "crop=ih:ih:(iw-ih)/2:0,scale=1080:1080"
    if prop == "16:9":
        return "scale=1920:1080"
    return ""  # original: sem reframe

def versoes_corte_config():
    """Versões que o FrameZero deve entregar automaticamente para cada corte."""
    if bool(config_usuario.get("gerar_versoes_automaticas", CONFIG.get("gerar_versoes_automaticas", True))):
        bruto = config_usuario.get("versoes_corte_automaticas", CONFIG.get("versoes_corte_automaticas", ["16x9", "9x16"]))
        if isinstance(bruto, str):
            bruto = [x.strip() for x in bruto.split(",") if x.strip()]
        saida = []
        for p in bruto or []:
            p = str(p).replace("x", ":")
            if p in ("16:9", "9:16", "1:1", "original") and p not in saida:
                saida.append(p)
        return saida or ["16:9", "9:16"]
    p = str(config_usuario.get("proporcao_corte", CONFIG.get("proporcao_corte", "original"))).replace("x", ":")
    return [p if p in ("16:9", "9:16", "1:1", "original") else "original"]

def pasta_formato_corte(pasta_corte, prop):
    """v81j: mantém todas as versões dentro da mesma pasta do título, sem subpastas 16x9/9x16."""
    os.makedirs(pasta_corte, exist_ok=True)
    return pasta_corte

def executar_ffmpeg_corte(entrada, saida, inicio=None, duracao=None, prop="original", timeout=300):
    ffmpeg = caminho_ffmpeg()
    if not ffmpeg:
        return False
    try:
        import subprocess
        cmd = [ffmpeg, "-y"]
        if inicio is not None:
            cmd += ["-ss", f"{float(inicio):.2f}"]
        cmd += ["-i", entrada]
        if duracao is not None:
            cmd += ["-t", f"{float(duracao):.2f}"]
        vf = filtro_proporcao(prop)
        if vf:
            cmd += ["-vf", vf]
        cmd += ["-c:v", "libx264", "-c:a", "aac", "-preset", "veryfast", "-movflags", "+faststart", saida]
        r = subprocess.run(cmd, capture_output=True, timeout=timeout)
        ok = (r.returncode == 0 and os.path.exists(saida) and os.path.getsize(saida) > 0)
        if not ok:
            err = (r.stderr or b"").decode("utf-8", "ignore")[-400:]
            print(f"[ffmpeg] falhou gerando {saida}: {err}")
        return ok
    except Exception as e:
        print(f"[ffmpeg] erro gerando {saida}: {e}")
        return False

def gerar_versoes_do_corte(entrada, pasta_corte, c, inicio=None, duracao=None, timeout=300):
    """Gera automaticamente 16x9 e 9x16 na mesma pasta do título, com o título no nome do arquivo."""
    videos = {}
    os.makedirs(pasta_corte, exist_ok=True)
    for prop in versoes_corte_config():
        prop_label = str(prop).replace(":", "x")
        saida = os.path.join(pasta_corte, nome_video_corte(c, prop_label))
        if executar_ffmpeg_corte(entrada, saida, inicio=inicio, duracao=duracao, prop=prop, timeout=timeout):
            videos[prop_label] = saida
    return videos


def gerar_cortes_fallback_local(max_cortes=12):
    """Quando nenhum momento foi marcado ao vivo, cria candidatos a partir da transcrição.
    Isso evita o erro 'Nenhum momento para gerar' no fim do culto.
    Não dispara replay buffer; só prepara a lista para o corte preciso da gravação completa.
    """
    candidatos = []
    if not linhas:
        return []
    # janelas de 1, 2 e 3 linhas para pegar frases completas.
    for i in range(len(linhas)):
        for janela in (1, 2, 3):
            bloco = linhas[i:i+janela]
            if not bloco:
                continue
            texto = " ".join((x.get("texto") or "").strip() for x in bloco).strip()
            if len(texto.split()) < 5:
                continue
            s, raz, emocao, funcao = score_heuristico(texto)
            if any(x.get("pico_voz") for x in bloco):
                s = min(100, s + 12)
                raz = (raz or []) + ["pico de voz/presença"]
                if emocao == "fé":
                    emocao = "presença"
            # guarda tudo com score razoável; se nada bater, a gente usa os melhores abaixo.
            candidatos.append({
                "tipo":"corte",
                "texto":texto,
                "score":int(s),
                "titulo":titulo_local(texto, emocao, funcao),
                "razao":", ".join(raz) if raz else "gerado no fim pela análise local",
                "emocao":emocao,
                "funcao":funcao,
                "origem":"fallback_local",
                "tempo":round(float(bloco[0].get("inicio", 0)), 1),
                "timestamp":fmt(float(bloco[0].get("inicio", 0))),
            })
    candidatos.sort(key=lambda c: c["score"], reverse=True)
    escolhidos = []
    vistos = []
    for c in candidatos:
        normal = _norm(c["texto"])[:120]
        if not normal:
            continue
        # evita cortes muito próximos ou texto praticamente repetido.
        if any(abs(c["tempo"] - e["tempo"]) < 35 for e in escolhidos):
            continue
        if any(normal in v or v in normal for v in vistos):
            continue
        escolhidos.append(c); vistos.append(normal)
        if len(escolhidos) >= max_cortes:
            break
    return escolhidos


def texto_linhas(bloco):
    return " ".join((x.get("texto") or "").strip() for x in bloco).strip()

def segundos_linha_inicio(l):
    try:
        return float(l.get("inicio", 0) or 0)
    except Exception:
        return 0.0

def segundos_linha_fim(l):
    try:
        return float(l.get("fim", l.get("inicio", 0)) or 0)
    except Exception:
        return segundos_linha_inicio(l)


# ----------------------------- FECHAMENTO DE CONTEXTO DO CORTE -----------------------------

_TERMINADORES_FALA = re.compile(r"[.!?…]$|(\bam[eé]m\b|\bentendeu\b|\bgl[oó]ria a deus\b|\baleluia\b)$", re.I)
_INICIO_NOVA_IDEIA = re.compile(r"^(agora|ent[aã]o|e ent[aã]o|mas|s[oó] que|por[eé]m|quando|voc[eê]|voce|olha|escuta|presta aten[cç][aã]o|nessa noite|hoje)\b", re.I)
_FINAL_INCOMPLETO = re.compile(
    r"(\b(e|mas|porque|por que|que|quando|ent[aã]o|s[oó] que|pra|para|com|de|da|do|das|dos|em|no|na|nos|nas|pelo|pela|pelos|pelas|voc[eê]|voce|ela|ele|eu|n[oã]s|essa|esse|isso|aquela|aquele|est[aá]|estava|ser[aá]|foi)\s*)$|[,:;]$|\.{3}$|…$",
    re.I,
)

def _txt_linha(i):
    try:
        return (linhas[i].get("texto") or "").strip()
    except Exception:
        return ""

def linha_tem_fechamento(i):
    """True quando a linha termina como fechamento natural de fala/ideia."""
    t = _txt_linha(i)
    if not t:
        return False
    if _TERMINADORES_FALA.search(t.strip()):
        return True
    # Algumas transcrições não trazem pontuação; aceitamos fechamentos típicos de pregação.
    if re.search(r"\b(deus|senhor|jesus|esp[ií]rito santo|prop[oó]sito|promessa|dire[cç][aã]o|rumo|vit[oó]ria|milagre)\s*$", t, re.I):
        return True
    return False

def texto_parece_incompleto(txt):
    """Detecta legenda/corte terminando no meio da ideia."""
    t = re.sub(r"\s+", " ", str(txt or "")).strip()
    if not t:
        return True
    if _TERMINADORES_FALA.search(t):
        return False
    if _FINAL_INCOMPLETO.search(t):
        return True
    ult = t.split()[-1].lower().strip(".,!?;:…")
    return ult in {"que","quando","porque","mas","então","pra","para","com","de","da","do","em","pela","pelo","você","voce","está","esta"}


_HISTORIA_PREGA = re.compile(
    r"\b(era|havia|tinha|estava|estavam|aconteceu|acontecia|chegou|chegaram|foi|foram|andou|vinha|veio|saiu|entrou|passou|encontrou|disse|perguntou|respondeu|homem|mulher|filho|filha|pai|m[aã]e|casa|cidade|deserto|barco|mar|tempestade|disc[ií]pulo|disc[ií]pulos|abra[aã]o|sara|agar|ismael|no[eé]|davi|jos[eé]|mois[eé]s|pedro|paulo|jesus)\b",
    re.I,
)
_PALAVRA_DIRECIONADA = re.compile(
    r"\b(voc[eê]|voce|sua|seu|teu|tua|hoje|agora|nesta noite|nessa noite|essa palavra|a palavra|receba|escuta|olha|presta aten[cç][aã]o|entenda|aprenda|guarde isso|isso significa|isso quer dizer|deus est[aá]|o senhor est[aá]|deus vai|deus quer|deus pode|deus n[aã]o|o senhor vai|o senhor quer|o senhor n[aã]o|o senhor pode|a sua vida|na sua casa|na sua fam[ií]lia|no seu minist[eé]rio|no seu chamado|no seu prop[oó]sito|voc[eê] precisa|voc[eê] n[aã]o pode|n[aã]o pare|n[aã]o desista|levanta|volta|creia|confia|confie|posicione|se posiciona)\b",
    re.I,
)
_FECHAMENTO_DIRECIONADO = re.compile(
    r"\b(am[eé]m|receba|gl[oó]ria a deus|aleluia|em nome de jesus|na sua vida|na sua casa|na sua fam[ií]lia|no seu minist[eé]rio|no seu chamado|no seu prop[oó]sito|deus vai fazer|o senhor vai fazer|deus est[aá] fazendo|o senhor est[aá] fazendo|n[aã]o acabou|vai acontecer|essa palavra [eé] pra voc[eê]|isso [eé] pra voc[eê])\b[.!?…]*$",
    re.I,
)
_INICIO_MEIO_HISTORIA = re.compile(r"^(ele|ela|eles|elas|aquele|aquela|isso|essa|esse|e|a[ií]|ent[aã]o|mas)\b", re.I)

def bloco_tem_historia(bloco):
    txt = texto_linhas(bloco)
    return bool(_HISTORIA_PREGA.search(txt))

def bloco_tem_palavra_direcionada(bloco):
    txt = texto_linhas(bloco)
    return bool(_PALAVRA_DIRECIONADA.search(txt))

def linha_tem_palavra_direcionada(i):
    return bool(_PALAVRA_DIRECIONADA.search(_txt_linha(i)))

def bloco_tem_fechamento_direcionado(bloco):
    txt = texto_linhas(bloco)
    return bool(_FECHAMENTO_DIRECIONADO.search(txt)) or (bloco_tem_palavra_direcionada(bloco) and not texto_parece_incompleto(txt))

def historia_sem_aplicacao(bloco):
    if not bool(config_usuario.get("historia_precisa_aplicacao", CONFIG.get("historia_precisa_aplicacao", True))):
        return False
    return bloco_tem_historia(bloco) and not bloco_tem_palavra_direcionada(bloco)

def ajustar_para_palavra_direcionada(a, b, idx_pico=None, dur_max=None):
    """Quando o trecho é história, tenta incluir a aplicação/palavra direcionada.

    Isso evita corte bonito visualmente mas sem sentido: a história começa, cria tensão,
    e o vídeo acaba antes da mensagem para o público.
    """
    if not bool(config_usuario.get("modo_contexto_pregacao", CONFIG.get("modo_contexto_pregacao", True))):
        return a, b, False
    if not linhas:
        return a, b, False
    dur_min, mx_cfg = duracao_cortes_config()
    dur_max = float(dur_max or mx_cfg)
    a = max(0, int(a)); b = min(len(linhas)-1, int(b))
    idx_pico = b if idx_pico is None else int(idx_pico)
    idx_pico = max(a, min(idx_pico, len(linhas)-1))

    def dur(aa, bb):
        return segundos_linha_fim(linhas[bb]) - segundos_linha_inicio(linhas[aa])
    def caberia(aa, bb):
        return dur(aa, bb) <= dur_max + 0.02

    bloco = linhas[a:b+1]
    if not bloco_tem_historia(bloco) or bloco_tem_palavra_direcionada(bloco):
        return a, b, False

    limite = min(len(linhas)-1, b + int(config_usuario.get("max_linhas_busca_aplicacao", CONFIG.get("max_linhas_busca_aplicacao", 18))))
    melhor = None
    viu_aplicacao = False
    for nb in range(b + 1, limite + 1):
        if linha_tem_palavra_direcionada(nb):
            viu_aplicacao = True
        bloco_tmp = linhas[a:nb+1]
        if not viu_aplicacao and not bloco_tem_palavra_direcionada(bloco_tmp):
            continue
        # depois que achou aplicação, tenta parar em fechamento natural.
        if not (linha_tem_fechamento(nb) or bloco_tem_fechamento_direcionado(bloco_tmp)) and nb < limite:
            continue
        aa = a
        while aa < idx_pico and not caberia(aa, nb):
            aa += 1
        if aa <= idx_pico <= nb and caberia(aa, nb):
            bloco_final = linhas[aa:nb+1]
            if bloco_tem_palavra_direcionada(bloco_final):
                melhor = (aa, nb, False)
                if bloco_tem_fechamento_direcionado(bloco_final):
                    return aa, nb, False
    if melhor:
        return melhor
    return a, b, True

def ajustar_fim_para_fechamento(a, b, idx_pico=None, dur_max=None):
    """Ajusta a janela para não terminar no meio da conclusão do contexto.

    Primeiro tenta estender o fim até fechamento natural.
    Se passar do máximo configurado, move o início para frente e preserva o pico.
    """
    if not linhas:
        return a, b, False
    dur_min, mx_cfg = duracao_cortes_config()
    dur_max = float(dur_max or mx_cfg)
    a = max(0, int(a)); b = min(len(linhas)-1, int(b))
    idx_pico = b if idx_pico is None else int(idx_pico)
    idx_pico = max(a, min(idx_pico, len(linhas)-1))

    def dur(aa, bb):
        return segundos_linha_fim(linhas[bb]) - segundos_linha_inicio(linhas[aa])

    def caberia(aa, bb):
        return dur(aa, bb) <= dur_max + 0.02

    if linha_tem_fechamento(b) and caberia(a, b):
        return a, b, False

    melhor = (a, b, texto_parece_incompleto(texto_linhas(linhas[a:b+1])))
    limite_busca = min(len(linhas)-1, b + 10)
    for nb in range(b + 1, limite_busca + 1):
        fecha = linha_tem_fechamento(nb)
        proxima = _txt_linha(nb + 1) if nb + 1 < len(linhas) else ""
        inicio_nova = bool(_INICIO_NOVA_IDEIA.search(proxima)) if proxima else False

        # Só considera parada boa quando fechou a frase/ideia ou a próxima linha começa nova ideia.
        if not fecha and not inicio_nova and nb < limite_busca:
            continue

        aa = a
        while aa < idx_pico and not caberia(aa, nb):
            aa += 1

        if caberia(aa, nb) and aa <= idx_pico <= nb:
            incompleto = not (fecha or inicio_nova)
            melhor = (aa, nb, incompleto)
            if not incompleto:
                return aa, nb, False

    aa, bb, inc = melhor
    while bb + 1 < len(linhas) and caberia(aa, bb + 1):
        bb += 1
        if linha_tem_fechamento(bb):
            return aa, bb, False

    inc = texto_parece_incompleto(texto_linhas(linhas[aa:bb+1]))
    return aa, bb, inc

def indice_linha_mais_proxima(t):
    if not linhas:
        return None
    try:
        alvo = float(t or 0)
    except Exception:
        alvo = 0.0
    melhor_i, melhor_d = 0, 10**9
    for i, l in enumerate(linhas):
        ini = segundos_linha_inicio(l); fim = segundos_linha_fim(l)
        centro = (ini + fim) / 2.0
        d = abs(centro - alvo)
        if d < melhor_d:
            melhor_i, melhor_d = i, d
    return melhor_i

def janela_score_edicao(bloco, corte_ref=None):
    """Pontua uma janela de linhas para achar onde o corte deve começar e terminar.
    A ideia é entregar menos trabalho na pós: pegar gancho + desenvolvimento + virada,
    respeitando duração mínima/máxima escolhida pelo usuário.
    """
    txt = texto_linhas(bloco)
    if not txt:
        return 0, [], "fé", "impacto"
    s, raz, emocao, funcao = score_heuristico(txt)
    ref = _norm((corte_ref or {}).get("texto", ""))[:80]
    norm = _norm(txt)
    if ref and (ref in norm or norm[:80] in ref):
        s += 10; raz = (raz or []) + ["contém o pico detectado"]
    if re.search(r"\?", txt):
        s += 6
    if re.search(r"\b(mas|então|até que|de repente|só que|porém|quando)\b", txt.lower()):
        s += 7; raz = (raz or []) + ["virada narrativa"]
    if re.search(r"\b(você|voce|hoje|agora|escuta|entenda|olha|presta atenção)\b", txt.lower()):
        s += 5
    if any(x.get("pico_voz") for x in bloco):
        s += 10; raz = (raz or []) + ["pico de voz/presença"]
        if emocao == "fé":
            emocao = "presença"
    if bool(config_usuario.get("modo_contexto_pregacao", CONFIG.get("modo_contexto_pregacao", True))):
        tem_hist = bloco_tem_historia(bloco)
        tem_dir = bloco_tem_palavra_direcionada(bloco)
        if tem_dir:
            s += 16
            raz = (raz or []) + ["palavra direcionada/aplicação"]
            funcao = "palavra direcionada" if funcao in ("história", "ensino", "impacto") else funcao
        if tem_hist and tem_dir:
            s += 8
            raz = (raz or []) + ["história com aplicação"]
        elif tem_hist and not tem_dir and bool(config_usuario.get("historia_precisa_aplicacao", CONFIG.get("historia_precisa_aplicacao", True))):
            s -= 24
            raz = (raz or []) + ["história sem aplicação penalizada"]
        primeiro = (bloco[0].get("texto") or "").strip()
        if _INICIO_MEIO_HISTORIA.search(primeiro) and tem_hist and not tem_dir:
            s -= 10
            raz = (raz or []) + ["começo no meio da história"]
        if tem_hist and not bloco_tem_fechamento_direcionado(bloco):
            s -= 8
    if len(txt.split()) < 18:
        s -= 12
    if bool(config_usuario.get("finalizacao_contexto_corte", CONFIG.get("finalizacao_contexto_corte", True))) and texto_parece_incompleto(txt):
        s -= 22
        raz = (raz or []) + ["fim incompleto penalizado"]
    return max(0, min(int(s), 100)), raz[:5] if raz else [], emocao, funcao

def calcular_janela_corte_ideal(corte_ref, dur_min=None, dur_max=None):
    """Define minutagem exata do corte usando as linhas transcritas.

    Em vez de cortar apenas uma margem fixa antes/depois do pico, ele testa várias
    janelas ao redor do momento detectado e escolhe a melhor janela com score viral.
    Retorna início/fim em segundos da gravação, texto final do corte e metadados.
    """
    if not linhas:
        t = float(corte_ref.get("tempo", 0) or 0)
        return {"inicio": max(0, t), "fim": max(0, t) + 15, "duracao": 15,
                "texto_final": corte_ref.get("texto", ""), "score_janela": corte_ref.get("score", 0),
                "razoes_janela": [], "metodo": "fallback_sem_linhas"}
    dur_min = int(dur_min or config_usuario.get("duracao_corte_min", CONFIG.get("duracao_corte_min", 15)))
    dur_max = int(dur_max or config_usuario.get("duracao_corte_max", CONFIG.get("duracao_corte_max", 45)))
    dur_min = max(5, dur_min)
    dur_max = max(dur_min, dur_max)
    pico = float(corte_ref.get("tempo", 0) or 0)
    busca = float(config_usuario.get("corte_exato_busca_seg", CONFIG.get("corte_exato_busca_seg", 90)))
    idx = indice_linha_mais_proxima(pico)
    if idx is None:
        idx = 0
    indices_validos = []
    for i,l in enumerate(linhas):
        if abs(segundos_linha_inicio(l) - pico) <= busca:
            indices_validos.append(i)
    if not indices_validos:
        indices_validos = list(range(max(0, idx-8), min(len(linhas), idx+9)))
    min_i, max_i = min(indices_validos), max(indices_validos)
    candidatos = []
    for a in range(max(0, idx-10, min_i), min(idx+1, max_i+1)):
        for b in range(max(a, idx), min(len(linhas)-1, idx+14, max_i)+1):
            ini = segundos_linha_inicio(linhas[a])
            fim = segundos_linha_fim(linhas[b])
            dur = max(0.1, fim - ini)
            if dur < dur_min or dur > dur_max:
                continue
            aa, bb, incompleto_ctx = (a, b, False)
            if bool(config_usuario.get("finalizacao_contexto_corte", CONFIG.get("finalizacao_contexto_corte", True))):
                aa, bb, incompleto_ctx = ajustar_fim_para_fechamento(a, b, idx_pico=idx, dur_max=dur_max)
            aa, bb, incompleto_hist = ajustar_para_palavra_direcionada(aa, bb, idx_pico=idx, dur_max=dur_max)
            incompleto_ctx = incompleto_ctx or incompleto_hist
            ini = segundos_linha_inicio(linhas[aa])
            fim = segundos_linha_fim(linhas[bb])
            dur = fim - ini
            if dur < dur_min or dur > dur_max:
                continue
            bloco = linhas[aa:bb+1]
            txt = texto_linhas(bloco)
            if len(txt.split()) < 12:
                continue
            s, raz, emo, func = janela_score_edicao(bloco, corte_ref)
            if incompleto_ctx:
                s -= 28
                raz = (raz or []) + ["contexto/palavra direcionada incompleta"]
            bonus = 0
            primeiro = (bloco[0].get("texto") or "").strip().lower()
            ultimo = (bloco[-1].get("texto") or "").strip()
            if re.match(r"^(você|voce|quando|por que|sabe|escuta|olha|então|e então|agora|aí|ai)\b", primeiro):
                bonus += 4
            if re.search(r"[.!?…]$", ultimo):
                bonus += 3
            if ini <= pico <= fim:
                bonus += 8
            if pico - ini < 3 and dur > dur_min + 5:
                bonus -= 5
            candidatos.append((s+bonus, ini, fim, aa, bb, txt, raz, emo, func))
    if not candidatos:
        margem_antes = int(config_usuario.get("margem_antes_corte", CONFIG.get("margem_antes_corte", 10)))
        ini = max(0, pico - margem_antes)
        fim = ini + min(max(dur_min, margem_antes + int(config_usuario.get("margem_depois_corte", CONFIG.get("margem_depois_corte", 8)))), dur_max)
        bloco = [l for l in linhas if segundos_linha_fim(l) >= ini and segundos_linha_inicio(l) <= fim]
        txt = texto_linhas(bloco) or corte_ref.get("texto", "")
        s, raz, emo, func = janela_score_edicao(bloco, corte_ref) if bloco else (int(corte_ref.get("score",0) or 0), [], corte_ref.get("emocao",""), corte_ref.get("funcao",""))
        return {"inicio": round(ini,2), "fim": round(fim,2), "duracao": round(fim-ini,2),
                "texto_final": txt, "score_janela": s, "razoes_janela": raz,
                "emocao_janela": emo, "funcao_janela": func, "metodo": "fallback_margem"}
    candidatos.sort(key=lambda x: x[0], reverse=True)
    score_j, ini, fim, a, b, txt, raz, emo, func = candidatos[0]
    return {"inicio": round(ini,2), "fim": round(fim,2), "duracao": round(fim-ini,2),
            "linha_inicio": a, "linha_fim": b, "texto_final": txt,
            "score_janela": int(max(0, min(score_j, 100))), "razoes_janela": raz,
            "emocao_janela": emo, "funcao_janela": func, "metodo": "janela_viral_emocional"}

def janela_por_timecode_srt(corte_ref, prefer_ini=None, prefer_fim=None):
    """Escolhe início/fim usando as linhas da transcrição como se fossem o SRT oficial.

    A regra é: o corte só começa e termina em timecodes de fala transcrita
    (linha['inicio'] e linha['fim']). Isso evita exportar 2 minutos de Replay Buffer
    quando o usuário configurou 15s a 45s.
    """
    if not bool(config_usuario.get("usar_srt_como_timecode", CONFIG.get("usar_srt_como_timecode", True))):
        return None
    if not linhas:
        return None
    dur_min, dur_max = duracao_cortes_config()
    try:
        pico = float(corte_ref.get("tempo", corte_ref.get("fim_exato", 0)) or 0)
    except Exception:
        pico = 0.0
    idx = indice_linha_mais_proxima(pico)
    if idx is None:
        return None

    # Limita busca ao entorno do pico para evitar pegar história inteira.
    busca = float(config_usuario.get("corte_exato_busca_seg", CONFIG.get("corte_exato_busca_seg", 90)))
    candidatos = []
    min_i = max(0, idx - 16)
    max_i = min(len(linhas) - 1, idx + 16)
    for a in range(min_i, idx + 1):
        for b in range(max(a, idx), max_i + 1):
            ini = segundos_linha_inicio(linhas[a])
            fim = segundos_linha_fim(linhas[b])
            if abs(ini - pico) > busca and abs(fim - pico) > busca:
                continue
            dur = fim - ini
            if dur < dur_min or dur > dur_max:
                continue
            aa, bb, incompleto_ctx = (a, b, False)
            if bool(config_usuario.get("finalizacao_contexto_corte", CONFIG.get("finalizacao_contexto_corte", True))):
                aa, bb, incompleto_ctx = ajustar_fim_para_fechamento(a, b, idx_pico=idx, dur_max=dur_max)
            aa, bb, incompleto_hist = ajustar_para_palavra_direcionada(aa, bb, idx_pico=idx, dur_max=dur_max)
            incompleto_ctx = incompleto_ctx or incompleto_hist
            ini = segundos_linha_inicio(linhas[aa])
            fim = segundos_linha_fim(linhas[bb])
            dur = fim - ini
            if dur < dur_min or dur > dur_max:
                continue
            bloco = linhas[aa:bb+1]
            txt = texto_linhas(bloco)
            if len(txt.split()) < 8:
                continue
            s, raz, emo, func = janela_score_edicao(bloco, corte_ref)
            if incompleto_ctx:
                s -= 28
                raz = (raz or []) + ["contexto/palavra direcionada incompleta"]
            # preferência por janelas próximas da sugestão da IA/detector, quando houver
            dist_bonus = 0
            if prefer_ini is not None and prefer_fim is not None:
                try:
                    dist = abs(float(prefer_ini)-ini) + abs(float(prefer_fim)-fim)
                    dist_bonus = max(-12, 8 - dist/5)
                except Exception:
                    dist_bonus = 0
            # o pico precisa estar dentro, de preferência com contexto antes e depois
            if ini <= pico <= fim:
                s += 10
                if pico - ini < 2 and dur > dur_min + 5:
                    s -= 6
                if fim - pico < 2 and dur > dur_min + 5:
                    s -= 4
            candidatos.append((s + dist_bonus, ini, fim, aa, bb, txt, raz, emo, func))
    if not candidatos:
        # fallback: começa/finaliza no SRT mais próximo e respeita max.
        a = max(0, idx - 2)
        b = idx
        while b + 1 < len(linhas) and segundos_linha_fim(linhas[b]) - segundos_linha_inicio(linhas[a]) < dur_min:
            b += 1
        while b + 1 < len(linhas) and segundos_linha_fim(linhas[b+1]) - segundos_linha_inicio(linhas[a]) <= dur_max:
            # expande só se a próxima linha ainda mantém o corte dentro do máximo
            b += 1
            if segundos_linha_fim(linhas[b]) - pico >= max(6, dur_min * 0.35):
                break
        if bool(config_usuario.get("finalizacao_contexto_corte", CONFIG.get("finalizacao_contexto_corte", True))):
            a, b, _inc_ctx = ajustar_fim_para_fechamento(a, b, idx_pico=idx, dur_max=dur_max)
        a, b, _inc_hist = ajustar_para_palavra_direcionada(a, b, idx_pico=idx, dur_max=dur_max)
        ini = segundos_linha_inicio(linhas[a]); fim = segundos_linha_fim(linhas[b])
        ini, fim, dur = normalizar_janela_corte(ini, fim, pico=pico)
        bloco = [l for l in linhas if segundos_linha_fim(l) >= ini and segundos_linha_inicio(l) <= fim]
        txt = texto_linhas(bloco) or corte_ref.get("texto", "")
        return {"inicio": round(ini,2), "fim": round(fim,2), "duracao": round(fim-ini,2),
                "linha_inicio": a, "linha_fim": b, "texto_final": txt,
                "score_janela": corte_ref.get("score", 0), "razoes_janela": ["timecode do SRT/transcrição"],
                "emocao_janela": corte_ref.get("emocao", ""), "funcao_janela": corte_ref.get("funcao", ""),
                "metodo": "srt_timecode_fallback"}
    candidatos.sort(key=lambda x: x[0], reverse=True)
    score_j, ini, fim, a, b, txt, raz, emo, func = candidatos[0]
    return {"inicio": round(ini,2), "fim": round(fim,2), "duracao": round(fim-ini,2),
            "linha_inicio": a, "linha_fim": b, "texto_final": txt,
            "score_janela": int(max(0, min(score_j, 100))),
            "razoes_janela": (raz or []) + ["timecode do SRT/transcrição"],
            "emocao_janela": emo, "funcao_janela": func, "metodo": "srt_timecode"}

def enriquecer_corte_com_janela(corte_ref):
    try:
        janela_base = calcular_janela_corte_ideal(corte_ref)
        janela_srt = janela_por_timecode_srt(corte_ref, janela_base.get("inicio"), janela_base.get("fim"))
        janela = janela_srt or janela_base
        corte_ref.update({
            "inicio_exato": janela.get("inicio"),
            "fim_exato": janela.get("fim"),
            "duracao_exata": janela.get("duracao"),
            "inicio_exato_fmt": fmt(float(janela.get("inicio", 0) or 0)),
            "fim_exato_fmt": fmt(float(janela.get("fim", 0) or 0)),
            "texto_final_corte": janela.get("texto_final") or corte_ref.get("texto", ""),
            "score_janela": janela.get("score_janela"),
            "metodo_minutagem": janela.get("metodo"),
            "timecode_base": "srt/transcricao" if str(janela.get("metodo", "")).startswith("srt") else "janela_transcricao",
            "razoes_janela": janela.get("razoes_janela", []),
        })
        if janela.get("score_janela", 0) > int(corte_ref.get("score", 0) or 0):
            corte_ref["score"] = janela.get("score_janela")
        if janela.get("emocao_janela") and not corte_ref.get("emocao"):
            corte_ref["emocao"] = janela.get("emocao_janela")
        if janela.get("funcao_janela") and not corte_ref.get("funcao"):
            corte_ref["funcao"] = janela.get("funcao_janela")
    except Exception as e:
        print(f"[corte-exato] falhou ao enriquecer corte: {e}")
    return corte_ref

def salvar_mapa_cortes(pasta_cortes, itens):
    if not itens:
        return
    try:
        import csv
        csv_path = os.path.join(pasta_cortes, "mapa-dos-cortes.csv")
        txt_path = os.path.join(pasta_cortes, "mapa-dos-cortes.txt")
        campos = ["n", "titulo", "score", "inicio", "fim", "duracao", "timestamp", "emocao", "funcao", "pasta", "video_16x9", "video_9x16"]
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=campos)
            w.writeheader()
            for i, it in enumerate(itens, 1):
                c = it.get("corte", {})
                w.writerow({
                    "n": i,
                    "titulo": c.get("titulo", ""),
                    "score": c.get("score", ""),
                    "inicio": fmt(float(c.get("inicio_exato", c.get("tempo", 0)) or 0)),
                    "fim": fmt(float(c.get("fim_exato", 0) or 0)),
                    "duracao": c.get("duracao_exata", ""),
                    "timestamp": c.get("timestamp", ""),
                    "emocao": c.get("emocao", ""),
                    "funcao": c.get("funcao", ""),
                    "pasta": os.path.basename(it.get("pasta", "")),
                    "video_16x9": os.path.relpath((it.get("videos") or {}).get("16x9", ""), it.get("pasta", "")) if (it.get("videos") or {}).get("16x9") else "",
                    "video_9x16": os.path.relpath((it.get("videos") or {}).get("9x16", ""), it.get("pasta", "")) if (it.get("videos") or {}).get("9x16") else "",
                })
        linhas_txt = ["MAPA DOS CORTES — FRAMEZERO", ""]
        for i, it in enumerate(itens, 1):
            c = it.get("corte", {})
            linhas_txt.append(f"{i:02d}. {c.get('titulo','Momento')} — Score {c.get('score',0)}/100")
            linhas_txt.append(f"    Início: {fmt(float(c.get('inicio_exato', c.get('tempo', 0)) or 0))} | Fim: {fmt(float(c.get('fim_exato', 0) or 0))} | Duração: {c.get('duracao_exata','')}s")
            linhas_txt.append(f"    Emoção: {c.get('emocao','')} | Função: {c.get('funcao','')}")
            linhas_txt.append(f"    Pasta: {os.path.basename(it.get('pasta',''))}")
            vids = it.get('videos') or {}
            if vids.get('16x9'):
                linhas_txt.append(f"    16x9: {os.path.relpath(vids.get('16x9'), it.get('pasta',''))}")
            if vids.get('9x16'):
                linhas_txt.append(f"    9x16: {os.path.relpath(vids.get('9x16'), it.get('pasta',''))}")
            linhas_txt.append("")
        mapa_texto = "\n".join(linhas_txt)
        Path(txt_path).write_text(mapa_texto, encoding="utf-8")
        Path(os.path.join(pasta_cortes, "indice-dos-cortes.txt")).write_text(mapa_texto, encoding="utf-8")

        frases_gerais = []
        versiculos_gerais = []
        for it in itens:
            c = it.get("corte", {})
            for frase in extrair_frases_de_impacto(c):
                if frase not in frases_gerais:
                    frases_gerais.append(frase)
            for ref in extrair_versiculos(c):
                if ref not in versiculos_gerais:
                    versiculos_gerais.append(ref)

        linhas_frases = ["FRASES DE IMPACTO DA PREGAÇÃO", ""]
        if frases_gerais:
            linhas_frases += [f"{i:02d}. {frase}" for i, frase in enumerate(frases_gerais, 1)]
        else:
            linhas_frases.append("Nenhuma frase de impacto detectada nos cortes finais.")
        Path(os.path.join(pasta_cortes, "frases-de-impacto-da-pregacao.txt")).write_text("\n".join(linhas_frases) + "\n", encoding="utf-8")

        linhas_versiculos = ["VERSÍCULOS / REFERÊNCIAS BÍBLICAS DA PREGAÇÃO", ""]
        if versiculos_gerais:
            linhas_versiculos += [f"{i:02d}. {ref}" for i, ref in enumerate(versiculos_gerais, 1)]
        else:
            linhas_versiculos.append("Nenhum versículo detectado nos cortes finais.")
        Path(os.path.join(pasta_cortes, "versiculos-da-pregacao.txt")).write_text("\n".join(linhas_versiculos) + "\n", encoding="utf-8")
    except Exception as e:
        print(f"[cortes] falhou ao salvar mapa geral: {e}")

def resetar_sessao():
    """Limpa tudo que foi capturado no painel/servidor e recomeça a sessão.
    Se o OBS estiver gravando/transmitindo, zera o contador do FrameZero a partir de agora.
    """
    global inicio_gravacao, gravacao_completa, linhas, cortes, texto_desde_ia, texto_contexto_ia, ultima_ia, ultimos_cortes_locais, pasta_cortes_ao_vivo, pasta_cortes_finais, volume_historico, volume_picos
    linhas = []
    cortes = []
    texto_desde_ia = []
    texto_contexto_ia = []
    ultimos_cortes_locais = []
    volume_historico = []
    volume_picos = {}
    ultima_ia = time.time()
    gravacao_completa = None
    pasta_cortes_ao_vivo = None
    pasta_cortes_finais = None
    if gravando:
        inicio_gravacao = time.time()
        if obs_req:
            garantir_replay_buffer(silencioso=True)
    else:
        inicio_gravacao = None
    enviar({"tipo":"reset_ok","gravando":gravando,"motivo":"Sessão reiniciada"})
    enviar({"tipo":"status","gravando":gravando,"transcricao_ativa":bool(config_usuario.get("transcricao_ativa", CONFIG.get("transcricao_ativa", True))),"motivo":"reiniciado" if gravando else "pausado"})
    print("[reset] sessão limpa pelo painel")

def gerar_cortes_precisos():
    """
    Depois do culto: pega a gravacao completa do OBS e corta cada momento
    marcado no ponto exato, em mp4, ja nomeado, com .srt do lado.
    Roda numa thread pra nao travar o servidor.
    """
    if not gravacao_completa or not os.path.exists(gravacao_completa):
        enviar({"tipo":"aviso","texto":"Gravacao completa nao encontrada. Verifique se o OBS terminou de salvar."})
        return
    if not cortes:
        novos = gerar_cortes_fallback_local()
        if novos:
            cortes.extend(novos)
            for c in novos:
                enviar(c)
            enviar({"tipo":"aviso","texto":f"Nenhum momento estava marcado. Gerei {len(novos)} cortes pela análise local da transcrição."})
        else:
            enviar({"tipo":"aviso","texto":"Nenhum momento marcado e transcrição insuficiente para gerar cortes."})
            return
    ffmpeg = caminho_ffmpeg()
    if ffmpeg is None:
        enviar({"tipo":"aviso","texto":"FFmpeg nao encontrado. Reinstale com o instalador."})
        return

    pasta_base = os.path.dirname(gravacao_completa)
    pasta_cortes = pasta_principal(pasta_base, "final")

    total = len(cortes)
    enviar({"tipo":"cortes_inicio","total":total})
    print(f"[cortes] gerando {total} cortes de {gravacao_completa}")

    # Duração vem SEMPRE do painel/config. Nunca usa Replay Buffer como duração do corte.
    margem_antes = int(config_usuario.get("margem_antes_corte", CONFIG.get("margem_antes_corte", 10)))
    margem_depois = int(config_usuario.get("margem_depois_corte", CONFIG.get("margem_depois_corte", 8)))
    dur_min, dur_max = duracao_cortes_config()

    feitos = 0
    mapa_itens = []
    for c in cortes:
        # janela exata do corte: gancho + pico + conclusão, respeitando duração min/max.
        if bool(config_usuario.get("corte_exato_automatico", CONFIG.get("corte_exato_automatico", True))):
            c = enriquecer_corte_com_janela(c)
        if c.get("inicio_exato") is not None and c.get("fim_exato") is not None:
            # Já vem alinhado ao SRT/transcrição quando possível; normaliza só para respeitar min/max.
            ini, fim, dur = normalizar_janela_corte(c.get("inicio_exato"), c.get("fim_exato"), pico=c.get("tempo"))
        else:
            ini, fim, dur = normalizar_janela_corte(max(0, float(c["tempo"]) - margem_antes), float(c["tempo"]) + margem_depois, pico=c.get("tempo"))
        c["inicio_exato"] = round(ini, 2)
        c["fim_exato"] = round(fim, 2)
        c["duracao_exata"] = round(dur, 2)
        c["inicio_exato_fmt"] = fmt(ini)
        c["fim_exato_fmt"] = fmt(fim)
        pasta_corte = pasta_do_corte(pasta_cortes, c)

        try:
            videos_gerados = gerar_versoes_do_corte(gravacao_completa, pasta_corte, c, inicio=ini, duracao=dur, timeout=420)
            if not videos_gerados:
                print(f"[cortes] ffmpeg não gerou nenhuma versão para '{c.get('titulo','momento')}'")
                continue
            saida = videos_gerados.get("9x16") or videos_gerados.get("16x9") or next(iter(videos_gerados.values()))
            # srt + pacote social do corte
            srt = gerar_srt_corte_preciso(ini, ini + dur)
            salvar_arquivos_corte(pasta_corte, c, video_path=saida, srt_text=srt, videos=videos_gerados)
            mapa_itens.append({"corte": dict(c), "pasta": pasta_corte, "video": saida, "videos": videos_gerados})
            feitos += 1
            enviar({"tipo":"corte_pronto","nome":os.path.basename(pasta_corte),
                    "feitos":feitos,"total":total,
                    "inicio":fmt(ini),"fim":fmt(ini+dur),"duracao":round(dur,2),"score":c.get("score",0)})
            print(f"[cortes] {feitos}/{total} {os.path.basename(pasta_corte)} | {fmt(ini)} até {fmt(ini+dur)} ({dur:.1f}s) | versões: {', '.join(videos_gerados.keys())}")
        except Exception as e:
            print(f"[cortes] falhou em '{c.get('titulo','momento')}': {e}")

    salvar_mapa_cortes(pasta_cortes, mapa_itens)
    enviar({"tipo":"cortes_fim","feitos":feitos,"total":total,"pasta":pasta_cortes})
    print(f"[cortes] concluido: {feitos}/{total} em {pasta_cortes}")

def gerar_srt_corte_preciso(ini_clipe, fim_clipe):
    """SRT so das falas dentro do corte preciso, timecode reiniciado em 00:00:00."""
    out=[]; i=1
    for l in linhas:
        if l["fim"] < ini_clipe or l["inicio"] > fim_clipe:
            continue
        a = max(0, l["inicio"] - ini_clipe)
        b = max(a + 0.5, l["fim"] - ini_clipe)
        i = adicionar_cues_srt(out, i, a, b, l["texto"])
    if not out:
        out = ["1","00:00:00,000 --> 00:00:02,000","(sem fala neste trecho)",""]
    return "\n".join(out)

# ----------------------------- EXPORT -----------------------------

def gerar_srt_trecho(inicio_corte, fim_corte, segundos_buffer):
    """
    Gera um .srt so das falas dentro do clipe, com o timecode REINICIADO em
    00:00:00 no comeco do clipe. O clipe comeca em (fim_corte - segundos_buffer)
    porque o Replay Buffer guarda os segundos anteriores ao disparo.
    """
    inicio_clipe = max(0, fim_corte - segundos_buffer)
    fim_clipe = fim_corte + 4  # pequena margem depois do gatilho
    out = []
    i = 1
    for l in linhas:
        # a linha precisa cair dentro da janela do clipe
        if l["fim"] < inicio_clipe or l["inicio"] > fim_clipe:
            continue
        ini_rel = max(0, l["inicio"] - inicio_clipe)
        fim_rel = max(ini_rel + 0.5, l["fim"] - inicio_clipe)
        i = adicionar_cues_srt(out, i, ini_rel, fim_rel, l["texto"])
    if not out:
        out = ["1", "00:00:00,000 --> 00:00:02,000", "(sem fala transcrita neste trecho)", ""]
    return "\n".join(out)


def gerar_txt():
    return "\n".join(f"[{l['timestamp']}] {l['texto']}" for l in linhas)

def gerar_srt():
    out=[]
    i = 1
    for l in linhas:
        i = adicionar_cues_srt(out, i, l["inicio"], l["fim"], l["texto"])
    return "\n".join(out)

# ----------------------------- MAIN -----------------------------

async def handler_plugin_audio(ws):
    """Recebe o audio do plugin obs-audio-to-websocket (mixer do OBS).
    O plugin e o cliente; este servidor escuta na porta 8889, rota /audio."""
    global plugin_conectado
    plugin_conectado = True
    print("[plugin] obs-audio-to-websocket conectado")
    enviar({"tipo":"plugin_status","conectado":True})
    try:
        async for msg in ws:
            if isinstance(msg, (bytes, bytearray)):
                # so usa o audio do plugin se a fonte escolhida for "plugin"
                if fonte_audio != "plugin":
                    continue
                audio, sr = parse_audio_plugin(bytes(msg))
                if audio is None:
                    continue
                audio16k = reamostrar(audio, sr, CONFIG["sample_rate"])
                # injeta na mesma fila que o ASR consome (formato [N,1])
                arr16 = audio16k.reshape(-1, 1)
                fila_audio.put(arr16)
                try:
                    _fz_nations_audio_hook(arr16, CONFIG.get("sample_rate", 16000))
                except Exception:
                    pass
            else:
                # mensagem de controle JSON (start/stop) - so loga
                pass
    finally:
        plugin_conectado = False
        print("[plugin] desconectado")
        enviar({"tipo":"plugin_status","conectado":False})



def nations_bootstrap():
    """Bootstrap seguro do Nations. Mantido para compatibilidade com o main() do Core."""
    try:
        cfg = _fz_nations_load_config()
        if not _fz_nations_is_enabled(cfg):
            return cfg
        _fz_nations_log("bootstrap pronto • aguardando painel/pareamento", echo=False)
        return cfg
    except Exception as e:
        print(f"[nations] bootstrap erro: {e}")
        return {}

async def main():
    global loop_principal
    loop_principal = asyncio.get_running_loop()
    try:
        nations_bootstrap()
    except Exception as e:
        print(f"[nations] bootstrap falhou: {e}")
    iniciar_obs()

    # Modo vertical desativado por padrao.
    # O Aitum pode estar instalado, mas o FrameZero nao cria/forca cena vertical automaticamente.
    try:
        if bool(config_usuario.get("vertical_ativo", CONFIG["vertical_ativo"])):
            configurar_cena_vertical(True)
    except Exception as e:
        print(f"[vertical] auto-start falhou: {e}")

    disp = config_usuario.get("dispositivo_audio", CONFIG["dispositivo_audio"])
    global fonte_audio
    fonte_audio = config_usuario.get("fonte_audio", "dispositivo")

    if fonte_audio == "dispositivo":
        ok_audio, nome_audio = abrir_audio(disp)
        if not ok_audio and disp is not None:
            print("[audio] fallback: tentando dispositivo padrão do sistema")
            abrir_audio(None)
    else:
        print("[audio] fonte = plugin do OBS (aguardando conexao do plugin)")
    threading.Thread(target=worker_analise_cortes, daemon=True).start()
    threading.Thread(target=loop_transcricao, daemon=True).start()

    # servidor do painel + servidor do plugin de audio, juntos
    async with websockets.serve(handler,"localhost",CONFIG["porta_painel"]), \
               websockets.serve(handler_plugin_audio,"localhost",CONFIG["porta_plugin_audio"]):
        print("="*60)
        print(f"[painel] {config_usuario.get('painel_url', CONFIG.get('painel_url', 'https://clips.framezeroai.com.br/obs'))}")
        print(f"[painel-ws] ws://localhost:{CONFIG['porta_painel']}")
        print(f"[plugin] ws://localhost:{CONFIG['porta_plugin_audio']}{CONFIG['rota_plugin_audio']} (audio do mixer, opcional)")
        print("="*60)
        await asyncio.Future()

def listar():
    if sd is None:
        print(f"sounddevice/PortAudio indisponivel: {SOUNDDEVICE_ERROR}")
    else:
        print(sd.query_devices())

if __name__ == "__main__":
    import sys
    if len(sys.argv)>1 and sys.argv[1]=="--dispositivos":
        listar()
    else:
        try: asyncio.run(main())
        except KeyboardInterrupt: print("\n[fim]")





