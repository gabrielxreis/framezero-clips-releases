param(
  [Parameter(Mandatory=$true)][string]$CatalogPath,
  [Parameter(Mandatory=$true)][string]$NationsDir,
  [Parameter(Mandatory=$true)][string]$Code
)
$ErrorActionPreference = 'Stop'
try {
  $catalog = Get-Content -LiteralPath $CatalogPath -Raw | ConvertFrom-Json
  $prop = $catalog.PSObject.Properties | Where-Object { $_.Name -eq $Code } | Select-Object -First 1
  if(-not $prop){ Write-Host "[AVISO] $Code nao existe no catalogo"; exit 0 }
  $item = $prop.Value
  $base = 'https://huggingface.co/rhasspy/piper-voices/resolve/main'
  $voice = [string]$item.voice
  $stem = [string]$item.url_path
  if([string]::IsNullOrWhiteSpace($voice) -or [string]::IsNullOrWhiteSpace($stem)){
    Write-Host "[AVISO] $Code sem dados de voz no catalogo"; exit 0
  }
  $dest = Join-Path (Join-Path $NationsDir 'voices') $Code
  New-Item -Force -ItemType Directory -Path $dest | Out-Null
  foreach($suf in @('.onnx','.onnx.json')){
    $url = $base + '/' + $stem + $suf
    if($suf -eq '.onnx.json') { $fileName = $voice + '.onnx.json' } else { $fileName = $voice + '.onnx' }
    $file = Join-Path $dest $fileName
    try {
      Write-Host "Baixando $Code $fileName"
      Invoke-WebRequest -Uri $url -OutFile $file -UseBasicParsing -TimeoutSec 180
    } catch {
      Write-Host "[AVISO] $Code falhou, pulando"
      exit 0
    }
  }
  Write-Host "[OK] $Code instalado"
  exit 0
} catch {
  Write-Host "[AVISO] $Code falhou, pulando"
  Write-Host $_.Exception.Message
  exit 0
}
