@echo off
setlocal EnableExtensions EnableDelayedExpansion
title FrameZero Nations v55 - v1.0.16
color 0A

set "SCRIPT_DIR=%~dp0"
set "PAYLOAD_SERVER=%SCRIPT_DIR%payload\servidor.py"
set "CATALOG=%SCRIPT_DIR%payload\voices_catalog.json"
set "TARGET=%APPDATA%\obs-studio\FrameZero\app\servidor.py"

cls
echo ============================================================
echo                  FRAMEZERO NATIONS v55
echo  Feito por Gabriel Reis ^| @gabrielxreis_ ^| @framezeroai
echo ============================================================
echo.

echo Validando payload...
if not exist "%PAYLOAD_SERVER%" (
  echo [ERRO] payload\servidor.py nao encontrado.
  pause
  exit /b 1
)

where python >nul 2>&1
if errorlevel 1 (
  where py >nul 2>&1
  if errorlevel 1 (
    echo [ERRO] Python nao encontrado. Instale o FrameZero Clips primeiro.
    pause
    exit /b 1
  )
  set "PY=py"
) else set "PY=python"

%PY% -m py_compile "%PAYLOAD_SERVER%" > "%TEMP%\fz_nations_compile.log" 2>&1
if errorlevel 1 (
  echo [ERRO] servidor.py do Nations invalido.
  type "%TEMP%\fz_nations_compile.log"
  pause
  exit /b 1
)


if /i "%FRAMEZERO_NATIONS_CORE_ONLY%"=="1" (
  echo.
  echo Instalando FrameZero Nations Core automaticamente...
  call :INSTALL_CORE
  exit /b %ERRORLEVEL%
)

if /i "%FRAMEZERO_NATIONS_LANGS_ONLY%"=="1" (
  echo.
  echo Baixando idiomas do Nations em segundo plano...
  call :DOWNLOAD_ALL
  echo.
  echo [OK] Idiomas do Nations processados.
  exit /b 0
)

if /i "%FRAMEZERO_NATIONS_AUTO_INSTALL%"=="1" (
  echo.
  echo Instalando FrameZero Nations automaticamente...
  call :INSTALL_CORE
  if errorlevel 1 exit /b %ERRORLEVEL%
  echo.
  echo Baixando todos os idiomas do Nations automaticamente...
  call :DOWNLOAD_ALL
  echo.
  echo [OK] FrameZero Nations instalado com idiomas.
  exit /b 0
)

:MENU
echo.
echo 1^) Instalar/Atualizar FrameZero Nations v55
echo 2^) Baixar TODOS os idiomas TTS ^(best-effort^)
echo 3^) Baixar UM idioma TTS
echo 4^) Ver status
echo 5^) Desinstalar somente Nations
echo 6^) Sair
echo.
set /p OP="Escolha uma opcao: "
if "%OP%"=="1" call :INSTALL_CORE & goto MENU
if "%OP%"=="2" call :DOWNLOAD_ALL & goto MENU
if "%OP%"=="3" call :DOWNLOAD_ONE & goto MENU
if "%OP%"=="4" call :STATUS & goto MENU
if "%OP%"=="5" call :UNINSTALL_NATIONS & goto MENU
if "%OP%"=="6" exit /b 0
echo Opcao invalida.
goto MENU

:CHECK_TARGET
if not exist "%TARGET%" (
  echo [ERRO] Nao encontrei o FrameZero Clips em:
  echo %TARGET%
  echo Instale o FrameZero Clips primeiro e rode de novo.
  exit /b 1
)
exit /b 0

:INSTALL_CORE
call :CHECK_TARGET || exit /b 1
set "ROOT=%APPDATA%\obs-studio\FrameZero"
set "APPDIR=%ROOT%\app"
set "NDIR=%ROOT%\nations"
set "BKDIR=%APPDIR%\backups_nations"
mkdir "%BKDIR%" "%NDIR%\voices" "%NDIR%\models" "%NDIR%\cache" "%NDIR%\logs" "%NDIR%\downloads" >nul 2>&1
for /f %%A in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmmss"') do set "TS=%%A"
copy /Y "%TARGET%" "%BKDIR%\servidor.py.before-nations-v55-%TS%.bak" >nul
copy /Y "%PAYLOAD_SERVER%" "%TARGET%" >nul
copy /Y "%CATALOG%" "%NDIR%\voices_catalog.json" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$cfg='%NDIR%\nations_config.json'; $all=@('pt-BR','pt-PT','en-US','es-ES','fr-FR','de-DE','it-IT','nl-NL','pl-PL','ru-RU','uk-UA','ar-SA','zh-CN','hi-IN','ja-JP','ko-KR','id-ID','vi-VN','tl-PH','sw-KE'); $o=[ordered]@{source_language='pt-BR'; active_languages=@('en-US'); available_languages=$all; voice_languages=$all; language_manager='v55'; official_installer='v55'; voice_engine='piper'; voice_profile='intelligent'}; $o | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 $cfg"
echo.
echo [OK] FrameZero Nations v55 instalado/atualizado.
echo Backup criado em: %BKDIR%
exit /b 0

:DOWNLOAD_ALL
call :CHECK_TARGET || exit /b 1
for %%L in (pt-BR pt-PT en-US es-ES fr-FR de-DE it-IT nl-NL pl-PL ru-RU uk-UA ar-SA zh-CN hi-IN ja-JP ko-KR id-ID vi-VN tl-PH sw-KE) do call :DOWNLOAD_LANG %%L
exit /b 0

:DOWNLOAD_ONE
call :CHECK_TARGET || exit /b 1
set /p CODE="Codigo do idioma ^(ex: en-US, es-ES, fr-FR, ja-JP^): "
if "%CODE%"=="" exit /b 0
call :DOWNLOAD_LANG %CODE%
exit /b 0

:DOWNLOAD_LANG
set "CODE=%~1"
set "NDIR=%APPDATA%\obs-studio\FrameZero\nations"
mkdir "%NDIR%\voices\%CODE%" >nul 2>&1
set "DL_PS=%SCRIPT_DIR%payload\download_nations_lang.ps1"
if not exist "%DL_PS%" (
  echo [ERRO] payload\download_nations_lang.ps1 nao encontrado.
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%DL_PS%" -CatalogPath "%CATALOG%" -NationsDir "%NDIR%" -Code "%CODE%"
if errorlevel 1 echo [AVISO] %CODE% falhou, pulando.
exit /b 0

:STATUS
set "CFG=%APPDATA%\obs-studio\FrameZero\nations\nations_config.json"
echo.
echo FrameZero: %APPDATA%\obs-studio\FrameZero
if exist "%CFG%" type "%CFG%" else echo Sem config Nations.
exit /b 0

:UNINSTALL_NATIONS
call :CHECK_TARGET || exit /b 1
cls
echo ============================================================
echo        DESINSTALAR SOMENTE FRAMEZERO NATIONS
echo ============================================================
echo Esta opcao preserva FrameZero Clips, OBS, cortes e gravacoes.
echo.
set /p CONFIRM="Tem certeza? (s/n): "
if /i not "%CONFIRM%"=="s" echo Cancelado. & exit /b 0
set "ROOT=%APPDATA%\obs-studio\FrameZero"
set "APPDIR=%ROOT%\app"
set "BKDIR=%APPDIR%\backups_nations"
set "RESTORED=0"
if exist "%BKDIR%" (
  for /f "delims=" %%B in ('dir /b /o-d "%BKDIR%\servidor.py.before-nations-*.bak" 2^>nul') do (
    if "!RESTORED!"=="0" (
      copy /Y "%BKDIR%\%%B" "%TARGET%" >nul
      set "RESTORED=1"
      echo [OK] servidor.py restaurado: %%B
    )
  )
)
if exist "%ROOT%\nations" (
  for /f %%A in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmmss"') do set "TS=%%A"
  move "%ROOT%\nations" "%ROOT%\nations.uninstalled-!TS!" >nul
  echo [OK] Pasta Nations removida/arquivada.
) else echo [INFO] Pasta Nations nao encontrada.
exit /b 0
